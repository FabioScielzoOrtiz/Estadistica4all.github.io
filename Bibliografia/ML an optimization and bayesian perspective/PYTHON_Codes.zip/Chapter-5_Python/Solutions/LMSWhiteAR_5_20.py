# -----------------------------------------------------------------
# Exercise 5.20.
# This function generates the model and data for white noise
# as well as an AR process, and runs the LMS algorithm.
# Python3 required packages: numpy, matplotlib, scipy
# -----------------------------------------------------------------

import numpy as np
from matplotlib import pyplot as plt
from scipy.signal import lfilter
import sys
import os
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_5.help import py_convmtx

def LMS():

    plt.figure()
    L = 10  # Dimension of the unknown vector
    N = 2500  # Number of Data
    theta = np.random.randn(L,1)  # Unknown parameter

    IterNo = 100
    wtot = np.zeros((N,IterNo))
    MSE1 = np.zeros((N,IterNo))
    MSE2 = np.zeros((N,IterNo))
    noisevar = 0.01
    X = np.random.randn(L,N)
    inputvec = lambda n: X[:, n].copy()  # @(n) X(:, n); # Input process(white)

    noise = np.random.randn(N, 1) * np.sqrt(noisevar)

    y = np.zeros((N, 1))
    y[0:N] = np.dot(X[:, 0:N].conj().T, theta)
    y = y + noise

    for It in range(0, IterNo):
        xcorrel = np.random.randn(N + L - 1)  # , 1)
        xcorrel = xcorrel / np.std(xcorrel)

        X = py_convmtx(xcorrel, L)
        X = np.delete(X, (range(0, L)), axis=1)
        inputvec = lambda n: np.array([X[:, n].copy()]).conj().T

        noise = np.random.randn(N, 1) * np.sqrt(noisevar)

        y = np.zeros((N, 1))
        y[0:N] = np.dot(X[:, 0:N].conj().T, theta)
        y = y + noise

        w = np.zeros((L, 1))
        mu = 0.01  # Step size for the LMS
        for i in range(0, N):
            e = y[i] - np.dot(w.conj().T, inputvec(i))
            w = w + mu * e * inputvec(i)
            MSE1[i, It] = e ** 2

    MSE2 = np.zeros((N, IterNo))

    for It in range(0, IterNo):
        xcorrel = np.random.randn(N+L-1)  # ,1);
        xcorrel = lfilter([1], [1, 0.85], xcorrel, axis=0)  # AR process
        xcorrel = xcorrel/np.std(xcorrel)

        X = py_convmtx(xcorrel, L)  #';
        X = np.delete(X, (range(0, L)), axis=1)

        inputvec = lambda n: np.array([X[:, n].copy()]).conj().T
        noise = np.random.randn(N, 1) * np.sqrt(noisevar)

        y = np.zeros((N, 1))
        y[0:N] = np.dot(X[:, 0:N].conj().T, theta)
        y = y + noise

        w = np.zeros((L, 1))
        mu = 0.01  # Small stepsize. Choose a large stepsize to obtain a divergence scenario
        for i in range(0, N):
            e = y[i] - np.dot(w.conj().T, inputvec(i))
            w = w + mu * e * inputvec(i)
            MSE2[i, It] = e ** 2

    MSEav1 = sum(MSE1.conj().T) / IterNo
    MSEav2 = sum(MSE2.conj().T) / IterNo

    plt.plot(10 * np.log10(MSEav1), 'r', lw=0.5)
    plt.plot(10 * np.log10(MSEav2), 'k', lw=0.5)

    plt.show()

if __name__ == '__main__':
    LMS()

