# -----------------------------------------------------------------
# Exercise 5.21.
# This function generates the model
# and runs the LMS and the TDLMS algorithms
# for the AR process input scenario.
# Python3 required packages: numpy, matplotlib, scipy
# -----------------------------------------------------------------

import numpy as np
from matplotlib import pyplot as plt
from scipy.signal import lfilter
import sys
import os
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_5.help import py_convmtx, py_dctmtx


def TDLMS():
    L = 10  # Dimension of the unknown vector
    N = 1500  # Number of Data
    theta = np.random.randn(L, 1)  # Unknown parameter
    w = np.zeros((L, 1))  # Unknown parameter

    IterNo = 100

    MSE1 = np.zeros((N, IterNo))
    MSE2 = np.zeros((N, IterNo))
    noisevar = 0.01
    correlcoeff=0.85

    delta = 0.01
    beta = 0.5
    T = py_dctmtx(L)  # DCT matrix to be used for the TDLMS

    for It in range(0, IterNo):
        xcorrel = np.random.randn(N + L - 1)  # ,1);
        xcorrel = lfilter([1], [1, correlcoeff], xcorrel, axis=0)  # AR process
        xcorrel = xcorrel / np.std(xcorrel)

        X = py_convmtx(xcorrel, L)
        X = np.delete(X, (range(0, L-1)), axis=1)

        inputvec = lambda n: np.array([X[:, n].copy()]).conj().T
        noise = np.random.randn(N, 1) * np.sqrt(noisevar)

        y = np.zeros((N, 1))
        y[0:N] = np.dot(X[:, 0:N].conj().T, theta)
        y = y + noise

        w = np.zeros((L, 1))
        mu = 0.01
        for i in range(0, N):
            e = y[i] - np.dot(w.conj().T, inputvec(i))
            w = w + mu * e * inputvec(i)
            MSE1[i, It] = e ** 2

        w = np.zeros((L, 1))
        mu = 0.01
        sigmasquare = delta * np.ones((L, 1))
        Dinv = np.eye(L)
        for i in range(0, N):
            intran = np.dot(T.conj().T, inputvec(i))
            e = y[i] - np.dot(w.conj().T, intran)
            w = w + mu * e * np.dot(Dinv, intran)  # Compute the updated estimate
            sigmasquare = beta * sigmasquare + (1-beta) * np.abs(intran) ** 2  # Update the weights used in the TDLMS
            Dinv = np.diagflat(1/sigmasquare)
            MSE2[i, It] = e ** 2

    MSEav1 = sum(MSE1.conj().T) / IterNo
    MSEav2 = sum(MSE2.conj().T) / IterNo

    plt.plot(10 * np.log10(MSEav1), 'r', lw=0.5)
    plt.plot(10 * np.log10(MSEav2), 'g', lw=0.5)

    plt.show()


if __name__ == '__main__':
    TDLMS()
