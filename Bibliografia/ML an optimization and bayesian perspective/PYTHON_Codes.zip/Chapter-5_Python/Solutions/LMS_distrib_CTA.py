import numpy as np
from inspect import signature
import sys
import os
sys.path.append(os.getcwd())
sys.path.append('../')

from PYTHON_5.help import LMS_param_struct


def LMS_distrib_sparse_CTA(inputvec, y, data, errfun):

    if not isinstance(data, LMS_param_struct):
        print('error')
        return [[], []]

    L = data.L

    N = data.N
    mu = data.mu
    if not callable(mu):
        temp_mu = mu
        mu = lambda i: temp_mu
    nodes = data.nodes
    gamma = data.gamma
    h = data.h
    C = np.array(data.C)

    if hasattr(data, 'normalized'):
        normalized = data.normalized
    else:
        normalized = 0

    x = []
    if hasattr(data, 'initial_estimate'):
        for inod in range(0, nodes):
            x.append(data.initial_estimate)
    else:
        for inod in range(0, nodes):
            x.append(np.zeros(shape=(L, 1)))
    x = np.array(x)

    a2v = np.zeros(shape=(1, nodes))

    err = []
    for inod in range(0, nodes):
        err.append(np.zeros(shape=(1, N)))
    err = np.array(err)

    # transforms the input data to a function handle

    if not callable(inputvec):
        if len(inputvec == (N+L-1)):
            inputseq = inputvec
            inputvec = lambda n: inputseq[L+n-1:n:-1]
        elif len(inputvec.shape) >= 2 and inputvec.shape[1] > 1:
            inputmatrix = inputvec
            inputvec = lambda n: inputmatrix[:, n]

    y_n = []
    for inod in range(0, nodes):
        y_n.append([])
    y_n = np.array(y_n)

    epsil = 0.1
    gradf = lambda x: (1.0/(epsil+np.abs(x)))*np.sign(x)
    f = lambda x: np.sum(np.abs(x)/(epsil+np.abs(x)))
    gradfmat = np.zeros(shape=(1, nodes))
    fmat = np.zeros(shape=(1, nodes))

    for i in range(0, N):
        # if i%1000 == 0:
        #     print(str(i))
        x_c = np.zeros(shape=(nodes, L, 1))

        if gamma == 0:
            for inod in range(0, nodes):
                gradfmat[0, inod] = np.linalg.norm(gradf(x[inod]))**2
                fmat[0, inod] = f(x[inod])

        for inod in range(0, nodes):  # Combination stage
            neighb = np.array(np.array(C[:, inod]).flatten().nonzero())
            neighb = np.reshape(neighb, newshape=(neighb.shape[1], 1))

            x_c[inod, :, :] = 0
            for ii in range(0, len(neighb)):
                x_c[inod] = x_c[inod] + C[neighb[ii], inod]*x[neighb[ii]]

        for inod in range(0, nodes):
            a_n = inputvec(inod, i)
            a_n = np.reshape(a_n, newshape=(a_n.shape[0], 1))

            er = y[inod][i] - np.dot(a_n.conj().transpose(), x_c[inod])

            if normalized:  # adaptation stage.IF normalized is true the stepsize is normalized.
                x[inod] = x_c[inod] + (mu(i) / np.linalg.norm(a_n)**2) * a_n * er
            else:

                x[inod] = x_c[inod] + mu(i) * a_n * er

        if len(signature(errfun).parameters) == 2:

            for inod in range(0, nodes):
                err[inod][0][i] = errfun(i, x[inod])
        else:

            for inod in range(0, nodes):
                err[inod][0][i] = errfun(x[inod])

    return [err, x]
