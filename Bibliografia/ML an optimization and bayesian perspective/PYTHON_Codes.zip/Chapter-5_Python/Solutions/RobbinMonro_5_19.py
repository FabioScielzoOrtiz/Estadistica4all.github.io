# -----------------------------------------------------------------
# Exercise 5.19
# Plot the mean value of the obtained estimate  and the
# corresponding variance
# applying the Robins-Monro algorithm.
# Python3 required packages: numpy, matplotlib
# -----------------------------------------------------------------

import numpy as np
from matplotlib import pyplot as plt


def RobbinMonro_5_19():
    L = 2  # Dimension of the unknown vector
    N = 500  # Number of Data
    theta = np.random.randn(L, 1)  # Unknown parameter
    w = np.zeros((L, 1))  # Initial Estimate

    IterNo = 1000
    wtot = np.zeros((N, IterNo))
    noisevar = 0.1
    X = np.random.randn(L, N)  # Input
    inputvec = lambda n: X[:, n].copy()

    noise = np.random.randn(N, 1) * np.sqrt(noisevar)  # Noise process

    y = np.zeros((N, 1))
    y[0:N] = np.dot(X[:, 0:N].conj().T, theta)
    y = y + noise

    for It in range(0, IterNo):  # It=1:IterNo
        X = np.random.randn(L, N)
        inputvec = lambda n: X[:, n].copy()

        noise = np.random.randn(N, 1) * np.sqrt(noisevar)

        y = np.zeros((N, 1))
        y[0:N] = np.dot(X[:, 0:N].conj().T, theta)
        y = y + noise
        w = np.zeros((L, 1))
        for i in range(0, N):
            mu = 1 / (i+1)  # Step size

            e = y[i] - np.dot(w.conj().T, inputvec(i))  # Error computation
            w = w + mu * e * inputvec(i)
            wtot[i][It] = w[0][0]

    theta1 = theta[0] * np.ones((N, 1))
    plt. plot(theta1, color='red')
    meanw = np.mean(wtot.conj().T, axis=0)
    plt.plot(meanw, color='k', linestyle='solid')

    for i in range(0, N):
        if i % 10 == 0 and i > 30:
            plt.errorbar(i, meanw[i], yerr=np.std(wtot[i, :], axis=0), capsize=3)

    plt.show()


if __name__ == '__main__':
    RobbinMonro_5_19()

