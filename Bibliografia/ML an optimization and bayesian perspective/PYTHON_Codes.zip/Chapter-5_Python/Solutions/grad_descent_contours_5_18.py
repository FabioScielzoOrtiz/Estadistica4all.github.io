# -----------------------------------------------------------------
#  Exercise 5.18
#  This function plots the convergence path together with the
#  isovalue contours  of the  covariance matrix Sigma.
#  Python3 required packages: math, numpy, matplotlib
# -----------------------------------------------------------------

import math
import numpy as np
from matplotlib import pyplot as plt


def grad_descent(x0):

    # termination tolerance
    tol = 1e-8

    # maximum number of allowed iterations
    maxiter = 1000

    # minimum allowed perturbation
    dxmin = 1e-8

    # initialize gradient norm, optimization vector, iteration counter, perturbation
    gnorm = math.inf
    x = x0
    niter = 0
    dx = math.inf

    # Define the covariance matrix;
    Sigma = np.array([[1, 0], [0, 0.1]])
    p = np.array([[0.05], [0.03]])

    # Set the optimum stepsize;
    alpha = 2 / (0.1 + 1)

    # f = @(x1, x2) (p(1) - Sigma(1, 1) * x1) ^ 2 + (p(2) - Sigma(2, 2) * x2) ^ 2
    # f = lambda x1, x2: (p[0] - Sigma[0][0] * x1) ^ 2 + (p[1] - Sigma[1][1] * x2) ^ 2

    plt.set_cmap('gray')

    [X, Y] = np.meshgrid(np.arange(-3, 3.2, 0.2), np.arange(-3, 3.2, 0.2))
    zz = (p[0] - Sigma[0][0] * X) ** 2 + (p[1] - Sigma[1][1] * Y) ** 2
    sx = len(np.arange(-3, 3.2, 0.2))  # sx = length(-3:.2: 3);

    # [c, f] = plt.contour(X, Y, zz, 20)
    plt.contour(X, Y, zz, 20)

    while gnorm >= tol and niter <= maxiter and dx >= dxmin:
        # calculate gradient:
        g = grad(x, Sigma, p)
        gnorm = np.linalg.norm(g)

        # take step:
        xnew = x - alpha * g
        # check step
        if not np.all(np.isfinite(xnew)):
            print('Number of iterations: %s' % niter)
            print('x is inf or NaN')

        plt.plot([x[0], xnew[0]], [x[1], xnew[1]], color='red', linestyle='solid', marker='o', lw=1, ms=3)
        # update termination metrics
        niter += 1
        dx = np.linalg.norm(xnew - x)
        x = xnew

    print('niter= %d' % niter)
    xopt = x
    niter -= 1

    plt.show()


def grad(x, Sigma, p):
    g = np.dot(Sigma, x) - p
    return g


if __name__ == '__main__':

    import sys
    if len(sys.argv) == 1:
        # define starting point
        x_0 = np.array([[-2], [-1]])
        grad_descent(x_0)
    elif len(sys.argv) == 2:
        # if a single input argument is provided, it is a user-defined starting point.
        x_0 = sys.argv[1]
        grad_descent(x_0)
    else:
        print('Incorrect number of input arguments.')


