# -----------------------------------------------------------------
# Exercise 5.22
# This function generates the model  and runs the LMS, the NLMS
# and the APA algorithm for two different choices of the parameter q.
# Python3 required packages: numpy, matplotlib
# -----------------------------------------------------------------

import numpy as np
from matplotlib import pyplot as plt
import sys
import os
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_5.help import py_convmtx

def APA():
    plt.figure()
    L = 60  # Dimension of the unknown vector
    N = 3500  # Number of Data
    theta = np.random.randn(L, 1)  # Unknown parameter
    w = np.zeros((L, 1))  # Estimate Vector

    IterNo = 100
    MSE1 = np.zeros((N, IterNo))
    MSE2 = np.zeros((N, IterNo))
    MSE3 = np.zeros((N, IterNo))
    MSE4 = np.zeros((N, IterNo))


    noisevar = 0.01
    X = np.random.randn(L, N)
    inputvec = lambda n: np.array([X[:, n].copy()])  # .conj().T

    noise = np.random.randn(N, 1)*np.sqrt(noisevar)

    y = np.zeros((N,1))
    y[0:N] = np.dot(X[:, 0:N].conj().T, theta)
    y = y + noise

    for It in range(0, IterNo):
        xc = np.random.randn(N+L-1)  #,1)
        xc = xc/np.std(xc)

        X = py_convmtx(xc, L)
        X = np.delete(X, (range(0, L - 1)), axis=1)

        inputvec = lambda n: np.array([X[:, n].copy()]).conj().T
        noise = np.random.randn(N, 1) * np.sqrt(noisevar)

        y = np.zeros((N, 1))
        y[0:N] = np.dot(X[:, 0:N].conj().T, theta)
        y = y + noise
        w = np.zeros((L, 1))
        mu = 0.1
        delta = 0.001
        q = 30
        for i in range(0, N):
            if i > q:
                qq = range(i, i - q, -1)  # qq=i:-1:i-q+1;

                yvec = y[qq]
                Xq = inputvec(qq)
                Xq = np.reshape(Xq, newshape=(Xq.shape[0], Xq.shape[1]))
                e = yvec - np.dot(Xq, w)
                eins = y[i] - np.dot(w.conj().T, inputvec(i))
                w = w + mu * np.dot(np.dot(Xq.conj().T, np.linalg.inv(delta*np.eye(q)+np.dot(Xq, Xq.conj().T))), e)
                MSE1[i, It] = eins ** 2

        w = np.zeros((L, 1))
        q = 10
        for i in range(0, N):
            if i > q:
                qq = range(i, i - q, -1)  # qq=i:-1:i-q+1;

                yvec = y[qq]
                Xq = inputvec(qq)
                Xq = np.reshape(Xq, newshape=(Xq.shape[0], Xq.shape[1]))

                e = yvec - np.dot(Xq, w)
                eins = y[i] - np.dot(w.conj().T, inputvec(i))
                w = w + mu * np.dot(np.dot(Xq.conj().T, np.linalg.inv(delta * np.eye(q) + np.dot(Xq, Xq.conj().T))), e)
                MSE2[i, It] = eins ** 2


        w = np.zeros((L,1))
        delta = 0.001
        mu = 0.35
        for i in range(0, N):

            #  mu=1;%/(i^0.5);
            e = y[i] - np.dot(w.conj().T, inputvec(i))
            mun = mu/(delta+np.dot(inputvec(i).conj().T, inputvec(i)))
            w = w + mun * e * inputvec(i)
            MSE4[i, It] = e ** 2

        w = np.zeros((L, 1))
        mu = 0.025
        for i in range(0, N):

            #  mu=1;%/(i^0.5);
            e = y[i] - np.dot(w.conj().T, inputvec(i))
            w = w + mu * e * inputvec(i)
            MSE3[i, It] = e ** 2

    MSEav1 = sum(MSE1.conj().T) / IterNo
    MSEav2 = sum(MSE2.conj().T) / IterNo
    MSEav3 = sum(MSE3.conj().T) / IterNo
    MSEav4 = sum(MSE4.conj().T) / IterNo

    plt.plot(10 * np.log10(MSEav1), 'r', lw=0.5)
    plt.plot(10 * np.log10(MSEav2), 'g', lw=0.5)
    plt.plot(10 * np.log10(MSEav3), 'b', lw=0.5)
    plt.plot(10 * np.log10(MSEav4), 'k', lw=0.5)

    plt.show()




if __name__ == '__main__':
    APA()


