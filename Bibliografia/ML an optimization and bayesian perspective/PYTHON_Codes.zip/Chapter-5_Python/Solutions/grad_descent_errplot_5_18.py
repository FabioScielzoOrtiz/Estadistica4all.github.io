# -----------------------------------------------------------------
# Exercise 5.18
# This function computes the error curves
# for the  Sigma=[1 0;0 0.1] covariance scenario.
# Two curves are presented, the first one
# corresponding to the optimum step-size \mu_o
# and the second one corresponding to \mu_o/2.
# Python3 required packages: math, numpy, matplotlib
# -----------------------------------------------------------------

import math
import numpy as np
from matplotlib import pyplot as plt


def grad_descent(x0):

    # termination tolerance
    tol = 1e-8
    # maximum number of allowed iterations
    maxiter = 200
    # minimum allowed perturbation
    dxmin = 1e-8
    # initialize gradient norm, optimization vector, iteration counter, perturbation
    gnorm = math.inf
    x = x0
    niter = 0
    dx = math.inf
    # Define the covariance matrix. For the second part of the exercise set this covariance to Sigma=[1 0;0 1]
    Sigma = np.array([[1, 0], [0, 0.1]])
    p = np.array([[0.05], [0.03]])

    # Compute the optimum stepsize;
    alpha = 2 / (0.1 + 1)

    # opt = double(inv(Sigma) * p);

    opt = np.dot(np.linalg.inv(Sigma), p)

    # f = @(x1, x2) (p(1) - Sigma(1, 1) * x1) ^ 2 + (p(2) - Sigma(2, 2) * x2) ^ 2
    # f = lambda x1, x2: (p[0] - Sigma[0][0] * x1) ^ 2 + (p[1] - Sigma[1][1] * x2) ^ 2

    plt.set_cmap('gray')

    err = np.zeros((maxiter, 1))
    [X, Y] = np.meshgrid(np.arange(-3, 3.2, 0.2), np.arange(-3, 3.2, 0.2))

    # gradient descent algorithm:
    while niter < maxiter:  # <= maxiter:
        # calculate  gradient:
        err[niter] = np.linalg.norm(x - opt) ** 2
        g = grad(x, Sigma, p)
        xnew = x - alpha * g

        if not np.all(np.isfinite(xnew)):
            print('Number of iterations: %s' % niter)
            print('x is inf or NaN')

        # update termination metrics
        niter += 1
        dx = np.linalg.norm(xnew - x)
        x = xnew

    xopt = x
    niter -= 1
    plt.plot(err, color='blue', linestyle='solid')

    # Define the covariance matrix. For the second part of the exercise set this covariance to Sigma=[1 0;0 1]
    Sigma = np.array([[1, 0], [0, 0.1]])
    p = np.array([[0.05], [0.03]])
    # opt = double(inv(Sigma) * p);
    opt = np.dot(np.linalg.inv(Sigma), p)

    # termination tolerance
    tol = 1e-8
    # maximum number of allowed iterations
    maxiter = 200
    # minimum allowed perturbation
    dxmin = 1e-8

    # initialize gradient norm, optimization vector, iteration counter, perturbation
    gnorm = math.inf
    x = x0
    niter = 0
    dx = math.inf

    # opt = np.dot(np.linalg.inv(Sigma), p)

    # Compute the optimum stepsize;
    alpha = 1 / (0.1 + 1)

    # f = @(x1, x2) (p(1) - Sigma(1, 1) * x1) ^ 2 + (p(2) - Sigma(2, 2) * x2) ^ 2
    # f = lambda x1, x2: (p[0] - Sigma[0][0] * x1) ^ 2 + (p[1] - Sigma[1][1] * x2) ^ 2

    plt.set_cmap('gray')

    err = np.zeros((maxiter, 1))
    [X, Y] = np.meshgrid(np.arange(-3, 3.2, 0.2), np.arange(-3, 3.2, 0.2))
    zz = (p[0] - Sigma[0][0] * X) ** 2 + (p[1] - Sigma[1][1] * Y) ** 2
    sx = len(np.arange(-3, 3.2, 0.2))  # sx = length(-3:.2: 3);

    # gradient descent algorithm:
    while niter < maxiter:  # = maxiter:
        # calculate  gradient:
        err[niter] = np.linalg.norm(x - opt) ** 2
        g = grad(x, Sigma, p)
        gnorm = np.linalg.norm(g)
        xnew = x - alpha * g

        if not np.all(np.isfinite(xnew)):
            print('Number of iterations: %s' % niter)
            print('x is inf or NaN')

        # update termination metrics
        niter += 1
        dx = np.linalg.norm(xnew - x)
        x = xnew

    xopt = x
    niter -= 1
    plt.plot(err, color='red', linestyle='solid')

    plt.show()


def grad(x, Sigma, p):
    g = np.dot(Sigma, x) - p
    return g


if __name__ == '__main__':

    import sys
    if len(sys.argv) == 1:
        # define starting point
        x_0 = np.array([[-2], [-1]])
        grad_descent(x_0)
    elif len(sys.argv) == 2:
        # if a single input argument is provided, it is a user-defined starting point.
        x_0 = sys.argv[1]
        grad_descent(x_0)
    else:
        print('Incorrect number of input arguments.')


