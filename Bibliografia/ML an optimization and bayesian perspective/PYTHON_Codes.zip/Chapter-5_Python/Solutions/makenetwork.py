import numpy as np
import sys
import os
import networkx as nx


sys.path.append(os.getcwd())
from PYTHON_5.help import py_dmperm
sys.path.append('../')


def makenetwork(nodes=None, connections=None, ruleweights=None,trials=1, visualize=0):
    """
    Builds a network with ``nodes'' nodes and ``connections'' connections.
    ruleweights: 'Metropolis', 'uniform', 'noncoperation'
    tryconnectivity: Runs many realizations in order to get a connected
    network. However, it can still fail to do so.
    visualize = 1 to plot the graph.

    Returns:
    matrix N, with ones and zeros in connected nonconnected edges
    matrix C, with metropolis rule entries
    logical connected: True for connected -- False for non connected
    """

    Lowtriangular = np.tril(np.ones(shape=(nodes, nodes)), -1)
    Lowtriangpos = np.array(Lowtriangular.ravel().nonzero()).conj().transpose()

    if connections > Lowtriangpos.shape[0]:
        connections = Lowtriangpos.shape[0]

    connected = False
    tr = 1
    N = np.zeros(shape=(nodes, nodes))

    while (not connected) and tr <= trials:
        if tr % 1000 == 0:
            print('This is the %s try to find a connected' % str(tr))

        N = np.zeros(shape=(nodes * nodes, 1))

        K = np.random.choice(a=Lowtriangpos.shape[0], size=connections, replace=False)
        N[Lowtriangpos[K]] = 1
        N = np.reshape(N, newshape=(nodes, nodes))

        N = N + N.conj().transpose() + np.eye(nodes)  # make it symmetric with full diagonal

        N[N != 0] = 1

        [p, q, r, s, cc, rr] = py_dmperm(N, 0)
        if len(r) == 3:
            connected = True

        tr = tr + 1

    A = np.zeros(shape=N.shape)
    N_k = N.sum(axis=0)

    if ruleweights == 'metropolis':
        for jj in range(0, nodes):
            for ii in range(0, nodes):
                if N[ii, jj] != 0 and ii != jj:
                    A[ii, jj] = 1 / max([N_k[ii], N_k[jj]])

            A[jj, jj] = 1 - (A[:, jj].sum(axis=0)-A[jj, jj])

    elif ruleweights == 'uniform':
        for jj in range(0, nodes):
            A[:, jj] = N[:, jj] / N_k[jj]
    elif ruleweights == 'noncoperation':
        A = np.eye(nodes)

    if visualize:
        xy = np.vstack((np.r_[np.random.permutation(nodes)], np.r_[np.random.permutation(nodes)])).conj().transpose()
        G = nx.from_numpy_matrix(np.array(xy))
        nx.draw(G, with_labels=False)
    return [N, A, connected]
