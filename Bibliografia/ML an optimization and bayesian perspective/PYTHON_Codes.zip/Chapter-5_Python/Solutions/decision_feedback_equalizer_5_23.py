# -----------------------------------------------------------------
#  Exercise 5.23
#  Decision Feedback Equalization
#  Python3 required packages: numpy, matplotlib
# -----------------------------------------------------------------

import os
import sys
import numpy as np
from matplotlib import pyplot as plt
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_5.help import py_awgn

def decision_feedback_equalizer_5_23():
    rseed = 1
    np.random.seed(rseed)
    N_T = 500

    N = 10000  # The length of the data sequence
    L = 31
    Lb = 10
    Lf = 21

    # the impulse responses of the linear channel
    h = np.array([0.04, -0.05, 0.07, -0.21, 0.72, 0.36, 0.21, 0.03, 0.07], ndmin=2).conj().T
    # print(h.shape)

    Lh = h.shape[0]  # length(h);
    mse = np.zeros((N, 1))
    u = np.zeros((N, 1))

    N0 = 250 # After N0 samples we assume convergence
    errors = 0

    # Run N_T experiments
    for i in range(0, N_T):

        # Generate a set of 10000 random �1 values (BPSK)
        s = np.sign(2*np.random.rand(N ,1)-1)
        #Direct this sequence into a linear channel
        for n in range(0, N):
            u[n] = np.dot(s[range(n, max(1, n - Lh + 1) - 1, -1)].conj().T, h[range(0, min(Lh, n))])
            # u(n) = s(n:-1:max(1,n-Lh+1))'*h(1:min(Lh,n));

        # add noise
        u = py_awgn(u, 11)

        # Adaptive Decision Feedback Equalizer
        # Estimate the original signal (s)
        # from u (the output of the linear channel)
        w = np.zeros((Lf+Lb,1))
        e = np.zeros((N,1))
        d = np.zeros((N,1))
        mu = 0.025
        # filter
        for n in range(Lf+Lb-1, N):  # n=Lf+Lb:N
            if n <= N0:
                v_n = np.array(np.concatenate((u[range(n, n-Lf, -1)], s[range(n-Lf, n-Lf-Lb, -1)]), axis=0 ))
                d_hat = np.dot(w.conj().T, v_n)
                d[n] = s[n-Lf+1]
            else:
                v_n = np.array(np.concatenate((u[range(n, n-Lf, -1)], d[range(n-1, n-Lb-1, -1)]), axis=0))
                d_hat = np.dot(w.conj().T, v_n)
                d[n] = np.sign(d_hat)
                if d[n] != s[n-Lf+1]:
                    errors = errors + 1

            e[n] = d[n] - d_hat
            w = w + mu * v_n * e[n]
            e[n] = d_hat - s[n-Lf+1]

        # end DFE

        # compute the mean square error over all experiments
        mse = mse + e ** 2  # e.^2

    # plot results
    mse = mse/N_T
    plt.plot(10 * np.log10(mse), 'r', lw=0.5)

    plt.xlabel('n')
    plt.ylabel('MSE')
    percentage = errors/(N-N0)/N_T
    print('Errors: %.4f' % (percentage*100))

    plt.show()


if __name__ == '__main__':
    decision_feedback_equalizer_5_23()

