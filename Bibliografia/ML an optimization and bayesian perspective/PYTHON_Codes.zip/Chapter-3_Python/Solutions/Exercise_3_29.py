import numpy as np
import matplotlib.pyplot as plt


def generate_ground(x):
    ground=0.1+0.6*x+0.5*x**2-0.8*x**3+0.2*x**4+0.3*x**5
    return ground

def betahistory(order):
    N=10
    x=np.linspace(-1,0.8,num=N)
    noise = np.sqrt(0.3)*np.random.standard_normal(N)
    ground=generate_ground(x)
    y=ground+noise
    if order==2:
        X=np.array([np.ones(N),x,x**2]).T
    elif order==8:
        X=np.array([np.ones(N),x,x**2,x**3,x**4,x**5,x**6,x**7,x**8]).T
    Y=np.array([y]).T
    beta=np.dot(np.linalg.inv(np.dot(X.T,X)),np.dot(X.T,Y))
    savebeta=beta
    for i in range(999):
        noise = np.sqrt(0.3)*np.random.standard_normal(N)
        y=ground+noise
        Y=np.array([y]).T
        beta=np.dot(np.linalg.inv(np.dot(X.T,X)),np.dot(X.T,Y))
        savebeta=np.concatenate((savebeta,beta),axis=1)
    beta=np.mean(savebeta,axis=1)
    return beta, savebeta

def plot1000(order,x_plot,beta):
    # plot depending on the order
    if order==2:
        y_plot=np.dot(np.array([np.ones(1000),x_plot,x_plot**2]).T,beta)
    elif order==8:
        y_plot=np.dot(np.array([np.ones(1000),x_plot,x_plot**2,x_plot**3,x_plot**4,x_plot**5,x_plot**6,x_plot**7,x_plot**8]).T,beta)
    return y_plot

beta2, beta2history=betahistory(2)
beta8, beta8history=betahistory(8)


# Plot Results
x_plot=np.linspace(-1,0.8,num=1000)
y_plot2=plot1000(2,x_plot,beta2)
y_plot8=plot1000(8,x_plot,beta8)
plt.figure(1)
plt.plot(x_plot,y_plot2,'b',x_plot,generate_ground(x_plot),'r',x_plot,y_plot8,'y')
plt.xlabel('x')
plt.ylabel('y')
plt.figure(2)
for i in range(10):
    plt.plot(x_plot,plot1000(2,x_plot,beta2history[:,i]))
#plt.plot(x_plot,generate_ground(x_plot),'r')
plt.xlabel('x')
plt.ylabel('y')
plt.figure(3)
for i in range(10):
    plt.plot(x_plot,plot1000(8,x_plot,beta8history[:,i]))
#plt.plot(x_plot,generate_ground(x_plot),'r')
plt.xlabel('x')
plt.ylabel('y')
plt.show()