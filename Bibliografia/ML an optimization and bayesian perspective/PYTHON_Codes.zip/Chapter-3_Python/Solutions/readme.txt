1) Developed using Python 3.5.2: https://www.python.org/downloads/release/python-352/

2) Use the pip3 package installer: https://pypi.org/project/pip/

3) For the exercises that require TensorFlow, see installation guide: https://www.tensorflow.org/install

4) To install all the required packages for a chapter, open a terminal under the chapter's directory and type:

    pip3 install -r requirements.txt

    There may be more than 1 "requirement.txt" files for a chapter.

5) To run a script of an exercise (e.g. example.py), open a terminal under the chapter's directory and type:

    python3 ./example.py