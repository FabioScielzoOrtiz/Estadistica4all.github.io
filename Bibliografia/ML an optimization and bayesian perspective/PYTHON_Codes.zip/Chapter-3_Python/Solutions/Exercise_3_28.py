# -----------------------------------------------------------------
#  Exercise 3.28
#  Fitting a plane using LS
#  Python3 required packages: numpy, scipy, math
# -----------------------------------------------------------------

#  Example 3.1 - Fitting a plane using LS
#  This scripts generate a random distribution of points over
#  a plane and fits its corresponding plane using LS.
#
#   Model -
#   y = θo + θ1*x1 + θ2*x2 + η    with   η ~ N(0,σ)
#                                       x1 ~ U[0,10]
#   θ = [0.25 -0.25 0.25]               x2 ~ U[0,10]

import numpy as np
from scipy.io import savemat
import math

Num = 50
th = np.array([[0.25, -0.25, 0.25]])  # parameters of the plane

sig1 = 1  # Noise variance of the 1st exmaple
sig2 = math.sqrt(10) # Noise variance of the 2nd example

np.random.seed(10)  # Random seed (for the random generation)

# Generate a cloud of points
X = np.zeros(shape=(3, Num), dtype=np.float32)
X[0, :] = 10*np.random.rand(1, Num)  # ~ U[0,10]
X[1, :] = 10*np.random.rand(1, Num)
X[2, :] = np.ones(shape=(1, Num))  # Constant

y = np.dot(th, X)

# Add noise to the origial points
y1 = y + sig1*np.random.randn(y.shape[0], y.shape[1])  # Example 1
y2 = y + sig2*np.random.randn(y.shape[0], y.shape[1])  # Example 2

# Apply LS solution Eq(3.17)
LS1 = np.dot(np.dot(np.linalg.inv(np.dot(X, X.conj().T)), X), y1.conj().T)
LS2 = np.dot(np.dot(np.linalg.inv(np.dot(X, X.conj().T)), X), y2.conj().T)

print('LS1:')
print(LS1)
print('LS2')
print(LS2)
# === Save Results ===
# - Points -
Z = np.zeros(shape=(Num, 4), dtype=np.float32)
Z[:, 0] = X[0, :].conj().T  # Coordinates
Z[:, 1] = X[1, :].conj().T  # Coordinates
Z[:, 2] = y1.conj().T[:, 0]      # Example 1
Z[:, 3] = y2.conj().T[:, 0]      # Example 2

savemat('Res.mat', {'Z': Z, 'LS1': LS1, 'LS2': LS2})
