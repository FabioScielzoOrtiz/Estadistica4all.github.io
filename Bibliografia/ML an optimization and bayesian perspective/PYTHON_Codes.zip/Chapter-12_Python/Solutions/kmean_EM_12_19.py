# -----------------------------------------------------------------
#  Exercise 12.19
#  Gaussian mixture models: k-means and EM comparison
#  Use kmeans function
# Python3 required packages: numpy,  matplotlib
# -----------------------------------------------------------------
import numpy as np
import matplotlib.pyplot as plt
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_12.k_means import k_means
from PYTHON_12.error_ellipse2 import plot_cov_ellipse

def kmean_EM_12_18():

    # data points
    N1 = 100
    N2 = 20 # or (100)
    N = N1 + N2

    # #classes (try different numbers)
    K = 2

    # data dimension
    l = 2

    np.random.seed(0)
    # generate samples out of two Gaussians
    mu = np.array([ [.9, -1.2], [1.02, -1.3]])
    Sigma1 = np.array([[.5, .081], [.081, .7]])
    Sigma2 = np.array([[.4 ,.02], [.02, .3]])
    x1 = np.random.multivariate_normal(mu[:, 0], Sigma1, N1)
    x2 = np.random.multivariate_normal(mu[:, 1], Sigma2, N2)

    # set marker color
    marker_color = np.array([[1, 0, 0], [0, 0, 0], [.5, .5, .5]])

    # plot generated data
    plt.figure()

    plt.plot(x1[:, 0], x1[:, 1], '.',markersize=10, c=marker_color[1, :])
    plt.plot(x2[:, 0], x2[:, 1], '.',markersize=10, c=marker_color[0, :])
    plt.axis('equal')


    # data matrix
    X = np.hstack((x1.conj().transpose(), x2.conj().transpose()))

    # kmeans algorithm
    theta = np.zeros(shape=(l, K))
    [theta, bel, L] = k_means(X, theta)

    # plot kmeans clustering
    plt.figure()
    for k in range(0, K):
        indices = np.argwhere(bel==k)
        plt.plot(X[0, indices], X[1, indices], '.', markersize=10, c=marker_color[k, :])
    plt.axis('equal')

    # EM algorithm
    # initialization
    NofIter = 500
    conf = .8
    Pk = (1/K)* np.ones(shape=(K, 1))
    mu = np.random.randn(l,K)
    Sigmak = np.repeat((np.random.rand(2) * np.eye(l, l))[:, :, np.newaxis], K, axis=2)
    Sigmak_inv = Sigmak
    gammakn = np.zeros(shape=(K,N))

    # plot initial estimates
    plt.figure()
    plt.plot(x1[:, 0], x1[:, 1], '.', markersize=10, c=marker_color[1, :])
    plt.plot(x2[:, 0], x2[:, 1], '.', markersize=10, c=marker_color[0, :])
    plt.axis('equal')


    for k in range(0,K):
        if Pk[k] != 0:
            plot_cov_ellipse(Sigmak[:, :, k], mu[:, k], conf=conf, style='r')

    # EM algorithm - main loop
    for i in range(0, NofIter):
        # E-step

        for k in range(0, K):
            Sigmak_inv[:, :, k] = np.linalg.inv(Sigmak[:, :, k])

        for k in range(0, K):
            for n in range(0, N):
                xm = np.array(X[:, n] - mu[:, k])
                xm = np.reshape(xm, newshape=(xm.shape[0], 1))

                gammakn[k, n] = Pk[k] * (
                        ((2 * np.pi) ** (- 0.5 * l)) * (np.linalg.det(Sigmak[:, :, k]) ** (- 0.5)) * np.exp(
                    -0.5 * np.dot(
                        np.dot(xm.conj().transpose(), Sigmak_inv[:, :, k]), xm)))

        gammakn = np.divide(gammakn, (np.kron(np.ones(shape=(K, 1)), np.sum(gammakn, axis=0))))

        # M-step
        Nk = np.sum(gammakn, axis=1)
        Nk = np.reshape(Nk, newshape=(Nk.shape[0], 1))

        for k in range(0, K):
            if Nk[k]:

                mu[:, k] = (1 / Nk[k]) * np.dot(X, gammakn[k, :].conj().transpose())
                tmp = 1e-5 * np.eye(l)
                for n in range(0, N):
                    xm = np.array(X[:, n] - mu[:, k])
                    xm = np.reshape(xm, newshape=(xm.shape[0], 1))

                    tmp = tmp + gammakn[k, n] * np.dot(xm, xm.conj().transpose())

                Sigmak[:, :, k] = np.array(1 / Nk[k] * tmp)

        Pk = Nk / N

        for k in range(0, K):
            Sigmak_inv[:, :, k] = np.linalg.inv(Sigmak[:, :, k])

    # plot final estimates
    plt.figure()
    # plt.box(True)
    plt.plot(x1[:, 0], x1[:, 1], '.', markersize=10, c=marker_color[1, :])
    plt.plot(x2[:, 0], x2[:, 1], '.', markersize=10, c=marker_color[0, :])
    for k in range(0,K):
        if Pk[k] != 0:
            plot_cov_ellipse(Sigmak[:, :, k], mu[:, k], conf=conf, style='r')
    plt.axis('equal')

    plt.show()

if __name__ == '__main__':
    kmean_EM_12_18()
