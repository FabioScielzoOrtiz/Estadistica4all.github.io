import numpy as np
import sys
from skimage.util import view_as_windows as viewW



def frange(x, y, jump):
    while x < y:
        yield x
        x += jump