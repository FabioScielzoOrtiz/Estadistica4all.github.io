# -----------------------------------------------------------------
#   Exercise 12.20
#   Mixture of experts

# Python3 required packages: numpy, math, matplotlib
# -----------------------------------------------------------------

import numpy as np
import math
import matplotlib.pyplot as plt


def MoE_12_19():
    np.random.seed(0)

    # max iterations
    Imax = 100

    # # of models
    K = 2

    # # of input points
    N = 50

    # Generate data
    x = np.linspace(-1, 1, N)

    idx = np.ones(shape=(N,), dtype=np.int)
    idx[x < -0.5] = 0

    idx[x > 0.5] = 0
    idx1 = idx == 0
    idx2 = idx == 1
    w = 0.01*np.random.randn(1, K)
    b = np.array([-1, 1])
    t = np.zeros(shape=(N,))
    for i in range(0,N):

        t[i] = x[i]*w[0, idx[i]]+b[idx[i]]

    t += 0.1*np.random.randn(N)
    x = np.reshape(x, newshape=(1, N))
    x = np.hstack((x.conj().transpose(), np.ones(shape=(N, 1))))

    # EM algorithm
    # initialization
    w_em = np.random.randn(2, K) - np.random.rand(2, K)
    gnk = (1/K) * np.ones(shape=(N, K)) + 0.02 * np.random.randn(N, K)
    pk = (1/K) * np.ones(shape=(K, 1))
    vita = 10
    i = 0
    figure_count = 1
    for i in range(1, Imax+1):

        # plot the results at specified iterations
        if i == 1 or i == 4 or i == 100:
            plt.figure(figure_count)
            figure_count += 1
            plt.plot(x[idx1, 0], t[idx1], 'ro', mfc='none')
            plt.plot(x[idx2, 0], t[idx2], 'ko', mfc='none')

            plt.plot(x[:, 0], x[:, 0]*w_em[0, 0] + w_em[1, 0], 'r-', lw=0.5)
            plt.plot(x[:, 0], x[:, 0]*w_em[1, 0] + w_em[1, 1], 'k-', lw=0.5)
            plt.box(on=True)

            plt.figure(figure_count)
            figure_count += 1
            plt.stem(x[:, 0].conj().transpose(), np.ones(shape=(N,)), 'k-', markerfmt=" ")
            # hold on;
            plt.stem(x[:, 0], gnk[:, 0], 'rx-', markerfmt=" ")
            plt.box(on=True)
            # hold off;

        # E-step
        for n in range(0, N):  # = 1 : N
            tmp = 0
            for j in range(0, K):
                tmp = tmp + pk[j] * math.sqrt(.5 / math.pi) * math.sqrt(vita) * np.exp(-0.5 * vita * (t[n] - np.dot(w_em[:, j].conj().transpose(), x[n, :].conj().transpose()))**2)

            for k in range(0, K):
                gnk[n, k] = pk[k] * math.sqrt(.5 / math.pi) * math.sqrt(vita) * np.exp(-0.5 * vita * (t[n] - np.dot(w_em[:, k].conj().transpose(), x[n, :].conj().transpose()))**2) / tmp

        pk = (1/N) * np.sum(gnk, axis=0)

        # M-step
        w_em_old = w_em
        for k in range(0, K):
            w_em[:, k] = np.linalg.solve(np.dot(np.dot(x.conj().transpose(), np.diag(gnk[:, k])), x),
                                         np.dot(np.dot(x.conj().transpose(), np.diag(gnk[:, k])), t.conj().transpose()))

        tmp = 0
        for n in range(0, N):
            for k in range(0, K):
                tmp = tmp + gnk[n, k] * (t[n] - np.dot(w_em[:, k].conj().transpose(), x[n, :].conj().transpose()))**2

        vita = N / tmp

    plt.show()


if __name__ == '__main__':
    MoE_12_19()
