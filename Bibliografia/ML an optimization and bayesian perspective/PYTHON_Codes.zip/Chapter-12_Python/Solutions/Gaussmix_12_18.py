# -----------------------------------------------------------------
#  Exercise 12.18
#  Gaussian mixture EM algorithm
#  Use error_ellipse function.

# Python3 required packages: numpy, math, matplotlib

# -----------------------------------------------------------------

import numpy as np
import matplotlib.pyplot as plt
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_12.error_ellipse2 import plot_cov_ellipse


def Gaussmix_12_17():

    np.random.seed(0)

    # number of samples
    N = 300

    # dimension
    l = 2

    # # of Gaussians
    K = 3

    # # EM iterations
    NofIter = 100

    # generate data points out of three Gaussians
    # 1st gaussian
    N1 = 100  # samples
    mu1 = np.array([10, 3])
    Sigma1 = 1 * np.eye(l)
    R1 = np.linalg.cholesky(Sigma1)
    x1 = np.kron(np.ones(shape=(N1, 1)), mu1) + np.dot(np.random.randn(N1,l), R1)

    # 2nd gaussian
    N2 = 100
    mu2 = np.array([1, 1])
    Sigma2 = 1.5 * np.eye(l)
    R2 = np.linalg.cholesky(Sigma2)
    x2 = np.kron(np.ones(shape=(N2, 1)), mu2) + np.dot(np.random.randn(N2,l), R2)

    # 3rd gaussian
    N3 = 100
    mu3 = np.array([5, 4])
    Sigma3 = 2 * np.eye(l)
    R3 = np.linalg.cholesky(Sigma3)
    x3 = np.kron(np.ones(shape=(N3, 1)), mu3) + np.dot(np.random.randn(N3,l), R3)

    # data point matrix
    X = np.concatenate((np.concatenate((x1,x2), axis=0), x3)).transpose()

    # Gaussian mixtures EM algorithm

    # initialization
    Pk = (1/K) * np.ones(shape=(K, 1)) # initial probabilities

    # starting mean, use a random mean
    muu = np.random.rand(l, K)
    # or  the true
    # mu = ([3 2 4; 5 .4 3] .* ones(l,K));
    # or use a far-off mean
    # mu = [10 11 13; 13 12 11] .* ones(l,K);
    mu = np.zeros(shape=(l, K, NofIter))
    for i in range(0, mu.shape[2]):
        mu[:, :, i] = muu


    # use an identity covariance matrix as a starting point
    Sigma = np.eye(l)
    Sigmak = np.repeat(Sigma[:, :, np.newaxis], 3, axis=2)

    Sigmak_inv = np.zeros(shape=Sigmak.shape)
    Sigmak_det = np.zeros(shape=(K, 1))
    gammakn = np.zeros(shape=(K, N))
    lg_lklhd = np.zeros(shape=(NofIter, 1))  # initialize log likelihood variable

    conf = 0.999
    # plot data and initial estimates
    ff = 1
    plt.figure(ff)
    ff += 1

    plt.gca().plot(x1[:, 0], x1[:, 1], '.k', x2[:, 0], x2[:, 1], '+k', x3[:, 0], x3[:, 1], '*k')
    plot_cov_ellipse(Sigma1, pos=mu1, conf=conf, style='k', ax=plt.gca())
    plt.gca().axis('equal')
    plot_cov_ellipse(cov=Sigma2, pos=mu2, conf=conf, style='k', ax=plt.gca())
    plt.gca().axis('equal')
    plot_cov_ellipse(cov=Sigma3, pos=mu3, conf=conf, style='k', ax=plt.gca())
    plt.gca().axis('equal')

    plot_cov_ellipse(cov=np.array(Sigmak[:, :, 0]), pos=mu[:, 0, 0], conf=conf, style='r', ax=plt.gca())
    plt.gca().axis('equal')
    plot_cov_ellipse(cov=np.array(Sigmak[:, :, 1]), pos=mu[:, 1, 0], conf=conf, style='r', ax=plt.gca())
    plt.gca().axis('equal')
    plot_cov_ellipse(cov=np.array(Sigmak[:, :, 2]), pos=mu[:, 2, 0], conf=conf, style='r', ax=plt.gca())
    plt.gca().axis('equal')

    # EM algorithm - main loop
    for i in range(0, NofIter):
        # E-step

        for k in range(0, K):
            Sigmak_inv[:, :, k] = np.linalg.inv(Sigmak[:, :, k])

        for k in range(0, K):
            for n in range(0, N):
                xm = X[:, n] - mu[:, k, 0]
                xm = np.reshape(xm, newshape=(xm.shape[0], 1))

                gammakn[k, n] = Pk[k] * (
                        ((2 * np.pi) ** (- 0.5 * l)) * (np.linalg.det(Sigmak[:, :, k]) ** (- 0.5)) * np.exp(-0.5 * np.dot(
                        np.dot(xm.conj().transpose(), Sigmak_inv[:, :, k]), xm)))

        gammakn = np.divide(gammakn ,(np.kron(np.ones(shape=(K, 1)), np.sum(gammakn,axis=0))))

        # M-step
        Nk = np.sum(gammakn, axis=1)
        Nk = np.reshape(Nk, newshape=(Nk.shape[0], 1))

        for k in range(0, K):
            if Nk[k]:

                mu[:, k, 0] = (1/Nk[k]) * np.dot(X, gammakn[k, :].conj().transpose())
                tmp = 1e-5 * np.eye(l)
                for n in range(0, N):
                    xm = X[:, n] - mu[:, k, 0]
                    xm = np.reshape(xm, newshape=(xm.shape[0], 1))

                    tmp = tmp + gammakn[k, n] * np.dot(xm,xm.conj().transpose())

                Sigmak[:, :, k] = 1/Nk[k] * tmp

        Pk = Nk / N

        for k in range(0, K):
            Sigmak_inv[:, :, k] = np.linalg.inv(Sigmak[:, :, k])

        # compute the log likelihood
        tmp1 = np.zeros(shape=(N, 1))
        for n in range(0, N):
            tmp2 = np.zeros(shape=(K, 1))
            for k in range(0, K):
                xm = X[:, n] - mu[:, k, 0]
                xm = np.reshape(xm, newshape=(xm.shape[0], 1))

                tmp2[k] = Pk[k]*(1/(2*np.pi) * (1/np.sqrt(np.linalg.det(Sigmak[:, :, k])))*np.exp(-.5 * np.dot(np.dot(xm.conj().transpose(), Sigmak_inv[:, :, k]), xm)))
            tmp1[n] = np.log(np.sum(tmp2))

        lg_lklhd[i] = np.sum(tmp1)

        # plot estimations at iterations 5 and 30
        if i+1 == 5 or i+1 == 50:

            plt.figure(ff)

            ff += 1
            plt.gca().plot(x1[:, 0], x1[:, 1], '.k', x2[:, 0], x2[:, 1], '+k', x3[:, 0], x3[:, 1], '*k')

            plot_cov_ellipse(cov=Sigma1, pos=mu1, conf=conf, style='k', ax=plt.gca())
            plt.gca().axis('equal')
            plot_cov_ellipse(cov=Sigma2, pos=mu2, conf=conf, style='k', ax=plt.gca())
            plt.gca().axis('equal')

            plot_cov_ellipse(cov=Sigma3,pos= mu3, conf=conf, style='k', ax=plt.gca())
            plt.gca().axis('equal')

            plot_cov_ellipse(cov=np.array(Sigmak[:, :, 0]), pos=mu[:, 0, 0], conf=conf, style='r', ax=plt.gca())
            plt.gca().axis('equal')

            plot_cov_ellipse(cov=np.array(Sigmak[:, :, 1]), pos=mu[:, 1, 0], conf=conf, style='r', ax=plt.gca())
            plt.gca().axis('equal')

            plot_cov_ellipse(cov=np.array(Sigmak[:, :, 2]), pos=mu[:, 2, 0], conf=conf, style='r', ax=plt.gca())
            plt.gca().axis('equal')


    plt.figure(ff)

    plt.gca().plot(lg_lklhd)
    plt.ylabel('Likelihood')
    plt.xlabel('Iterations')

    plt.show()


if __name__ == '__main__':
    Gaussmix_12_17()