# -----------------------------------------------------------------
#   Exercise 12.16
#   Linear prediction with Gaussian prior
#   Use matplotlib's errorbar function.

# Python3 required packages: numpy, math, matplotlib
# -----------------------------------------------------------------

import numpy as np
import math
import matplotlib.pyplot as plt
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_12.help import frange


def prediction_12_15():

    np.random.seed(0)
    # true signal curve

    x = np.array(list(frange(0, 2, 0.0001)))
    x = np.reshape(x, newshape=(x.shape[0], 1))
    y = 0.2 * np.ones(shape=(x.shape[0],1)) - x + 0.9 * x**2 + 0.7 * x**3 - 0.2 * x**5

    # plot the true curve
    # figure; plot(x,y,'b');

    # training samples (20 or 500)
    N = 20

    # sample interval [a b]
    a = 0
    b = 2

    # generate samples
    x1 = np.array(list(frange(a, b, b/N)))
    x1 = np.reshape(x1, newshape=(x1.shape[0], 1))

    # noise generation
    sigma_n = 0.05
    n = math.sqrt(sigma_n) * np.random.randn(N,1)

    # use the true theta
    theta_true = np.array([[0.2], [-1], [0.9], [0.7], [-0.2]])

    # or a random one
    theta_dstrbd = np.array([[-0.004], [-10.54], [0.465], [0.087], [-0.093]])
    l = theta_true.shape[0]

    # compute the measurement matrix
    Phi = np.ones(shape=(N, 1))
    Phi = np.concatenate((Phi, np.array(x1)), axis=1)
    Phi = np.concatenate((Phi, np.array(x1**2)), axis=1)
    Phi = np.concatenate((Phi, np.array(x1**3)), axis=1)
    Phi = np.concatenate((Phi, np.array(x1**5)), axis=1)

    # generate noisy observations using the linear model
    y1 = np.dot(Phi, theta_true) + n

    # set the parameters of Gaussian prior
    sigma_theta = 2
    mu_theta_prior = theta_true # or mu_theta_prior = theta_dstrbd;

    # compute the covariance matrix of the Gaussian posterior
    Sigma_theta_pos = np.linalg.inv((sigma_theta**-1) * np.eye(l) + (sigma_n**-1) * np.dot(Phi.conj().transpose(), Phi))
    # compute the posterior mean
    mu_theta_pos = mu_theta_prior + (sigma_n**-1) * np.dot(np.dot(Sigma_theta_pos, Phi.conj().transpose()), (y1 - np.dot(Phi, mu_theta_prior)))

    # linear prediction
    Np = 20

    # generate prediction samples
    x2 = (b-a) * np.random.rand(Np, 1)

    # compute prediction measurement matrix
    Phip = np.ones(shape=(Np, 1))
    Phip = np.concatenate((Phip, np.array(x2)), axis=1)
    Phip = np.concatenate((Phip, np.array(x2 ** 2)), axis=1)
    Phip = np.concatenate((Phip, np.array(x2 ** 3)), axis=1)
    Phip = np.concatenate((Phip, np.array(x2 ** 5)), axis=1)

    # compute the predicted mean and variance
    mu_y_pred = np.dot(Phip, mu_theta_pos)
    sigma_y_pred = np.diag(sigma_n + sigma_n * sigma_theta * np.dot(np.dot(Phip,np.linalg.inv(sigma_n * np.eye(l) + sigma_theta * np.dot(Phi.conj().transpose(), Phi)) ),
                           Phip.conj().transpose()))
    sigma_y_pred = np.reshape(sigma_y_pred, newshape=(sigma_y_pred.shape[0],1))

    # plot the predictions along the condifence intervals
    plt.figure(1)

    # set(gca,'FontSize',12,'FontName','Times');
    plt.autoscale(enable=True, axis='x', tight=True)
    plt.autoscale(enable=True, axis='y', tight=True)

    plt.plot(x, y, 'k')
    plt.plot(x2, mu_y_pred, 'kx')

    plt.errorbar(x2, mu_y_pred, sigma_y_pred, fmt='r.', capsize=5)

    plt.xlabel('x')
    plt.ylabel('y')
    plt.show()


if __name__ == '__main__':
    prediction_12_15()
