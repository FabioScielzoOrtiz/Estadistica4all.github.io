import numpy as np
from math import pi, cos, sin
import matplotlib.pyplot as plt
from scipy.stats import norm, chi2


def eigsorted(cov):
    vals, vecs = np.linalg.eigh(cov)
    order = vals.argsort()[::-1]
    return vals[order], vecs[:, order]

def plot_cov_ellipse(cov, pos, nstd=2, conf=0.8, ax=None, style='k'):

    if ax is None:
        ax = plt.gca()
    u = pos[0]  # x-position of the center
    v = pos[1]  # y-position of the center


    vals, vecs = eigsorted(cov)
    t_rot = np.arctan2(*vecs[:, 0][::-1])

    q = 2 * norm.cdf(conf) - 1
    r2 = chi2.ppf(q, 2)
    a, b = nstd*np.sqrt(vals*r2)

    t = np.linspace(0, 2 * pi, 101)
    Ell = np.array([a * np.cos(t), b * np.sin(t)])
    # u,v removed to keep the same center location
    R_rot = np.array([[cos(t_rot), -sin(t_rot)], [sin(t_rot), cos(t_rot)]])
    # 2-D rotation matrix

    Ell_rot = np.zeros((2, Ell.shape[1]))
    for i in range(Ell.shape[1]):
        Ell_rot[:, i] = np.dot(R_rot, Ell[:, i])

    ax.plot(u + Ell_rot[0, :], v + Ell_rot[1, :], style)  # rotated ellipse
