
import numpy as np

def k_means(X, theta):

##########################################################################
# FUNCTION
#  [theta,bel,J]=k_means(X,theta)
# This function implements the k-means algorithm, which requires
# as input the number of clusters underlying the data set. The algorithm
# starts with an initial estimation of the cluster representatives and
# iteratively tries to move them into regions that are "dense" in data
# vectors, so that a suitable cost function is minimized. This is
# achieved by performing (usually) a few passes on the data set. The
# algorithm terminates when the values of the cluster representatives
# remain unaltered between two successive iterations.
#
# INPUT ARGUMENTS:
#  X:       lxN matrix, each column of which corresponds to
#           an l-dimensional data vector.
#  theta:   a matrix, whose columns contain the l-dimensional (mean)
#           representatives of the clusters.
#
# OUTPUT ARGUMENTS:
#  theta:   a matrix, whose columns contain the final estimations of
#           the representatives of the clusters.
#  bel:     N-dimensional vector, whose i-th element contains the
#           cluster label for the i-th data vector.
#  J:       the value of the cost function (sum of squared Euclidean
#           distances of each data vector from its closest parameter
#           vector) that corresponds to the  estimated clustering.
#
# (c) 2010 S. Theodoridis, A. Pikrakis, K. Koutroumbas, D. Cavouras
##########################################################################

    [l,N] = X.shape
    [l,m] = theta.shape
    bel = None
    J = None
    e = 1
    iter = 0
    while(e != 0):
        iter = iter+1
        theta_old = np.array(theta)
        dist_all = None

        for j in range(0, m):

            dist = np.sum(((np.dot(np.ones(shape=(N, 1)),
                                  np.reshape(theta[:,j], newshape=(theta[:,j].shape[0],1)).conj().transpose())
                                  -X.conj().transpose())**2).conj().transpose(), axis=0)
            dist = np.reshape(dist, newshape=(1, dist.shape[0]))
            if dist_all is None:
                dist_all = np.array(dist)
            else:

                dist_all = np.concatenate((dist_all, np.array(dist)))

        q1 = np.min(dist_all, axis=0).conj().transpose()
        q1 = np.reshape(q1, newshape=(1, q1.shape[0]))

        bel = np.argmin(dist_all, axis=0).conj().transpose()
        bel = np.reshape(bel, newshape=(1, bel.shape[0]))
        J = np.sum(q1)

        for j in range(0, m):
            if np.sum(bel==j) != 0:

                theta[:, j] = np.sum(np.multiply(X.conj().transpose(),
                                                 np.dot((bel==j).conj().transpose(), np.ones(shape=(1, l)))), axis=0) / np.sum(bel==j)

        e = np.abs(theta-theta_old).sum()

    return [theta,bel,J]
