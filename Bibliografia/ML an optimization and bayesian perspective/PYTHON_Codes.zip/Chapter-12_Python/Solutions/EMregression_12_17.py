# -----------------------------------------------------------------
#   Exercise 12.17
#   EM linear regression

# Python3 required packages: numpy, math, matplotlib
# -----------------------------------------------------------------

import numpy as np
import math
import matplotlib.pyplot as plt

import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_12.help import frange


def EMregression_12_16():

    np.random.seed(0)

    # true signal curve

    x = np.array(list(frange(0, 2, 0.0001)))
    x = np.reshape(x, newshape=(x.shape[0], 1))
    y = 0.2 * np.ones(shape=(x.shape[0], 1)) - x + 0.9 * x ** 2 + 0.7 * x ** 3 - 0.2 * x ** 5

    # plot the true curve
    # plt.figure
    # plt.plot(x1,y1,'b')

    # training samples
    N = 500

    # linear coefficients
    K = 5

    # sample interval [a b]
    a = 0
    b = 2

    # generate samples
    x1 = np.array(list(frange(a, b, b / N)))
    x1 = np.reshape(x1, newshape=(x1.shape[0], 1))

    # noise generation
    sigma_eta = 0.05
    n = math.sqrt(sigma_eta) * np.random.randn(N, 1)

    # use true parameter theta
    theta_true = np.array([[0.2], [-1], [0.9], [0.7], [-0.2]])

    # compute the measurement matrix
    Phi = np.ones(shape=(N, 1))
    Phi = np.concatenate((Phi, np.array(x1)), axis=1)
    Phi = np.concatenate((Phi, np.array(x1 ** 2)), axis=1)
    Phi = np.concatenate((Phi, np.array(x1 ** 3)), axis=1)
    Phi = np.concatenate((Phi, np.array(x1 ** 5)), axis=1)
    Phi_gram = np.dot(Phi.conj().transpose(), Phi)

    # generate noisy observations using the linear model
    y1 = np.dot(Phi, theta_true) + n

    # EM algorithm
    # initializate parameters
    # experiment on different initializations
    EMiter = 20
    betaj = 1
    sigma_eta_EM = np.ones(shape=(EMiter, 1))
    alphaj = 1
    Phiy = np.dot(Phi.conj().transpose(), y1)
    mu_theta = np.array([])

    for i in range(0, EMiter):
        Sigma_theta = np.linalg.inv(betaj * Phi_gram + alphaj * np.eye(K))
        mu_theta = betaj * np.dot(Sigma_theta, Phiy)

        alphaj = K/(np.linalg.norm(mu_theta)**2 + np.trace(Sigma_theta))

        betaj = N / (np.linalg.norm(y1 - np.dot(Phi, mu_theta))**2 + np.trace(np.dot(Sigma_theta, Phi_gram)))
        sigma_eta_EM[i] = 1/betaj


    # perform prediction on new samples
    Np = 10

    # generate prediction samples
    x2 = (b-a) * np.random.rand(Np, 1)

    # compute prediction measurement matrix
    Phip = np.ones(shape=(Np, 1))
    Phip = np.concatenate((Phip, np.array(x2)), axis=1)
    Phip = np.concatenate((Phip, np.array(x2 ** 2)), axis=1)
    Phip = np.concatenate((Phip, np.array(x2 ** 3)), axis=1)
    Phip = np.concatenate((Phip, np.array(x2 ** 5)), axis=1)

    # compute the predicted mean and variance
    y_pred = np.dot(Phip, mu_theta)
    y_pred_var = np.diag(sigma_eta_EM[-1] + sigma_eta_EM[-1] * 1/alphaj * np.dot(np.dot(Phip, np.linalg.inv(sigma_eta_EM[-1] * np.eye(K) + 1/alphaj * Phi_gram)), Phip.conj().transpose()))

    # plot the predictions along the condifence intervals
    plt.figure(1)
    # plt.gca('FontSize',12,'FontName','Times')

    plt.autoscale(enable=True, axis='x', tight=True)
    plt.autoscale(enable=True, axis='y', tight=True)

    plt.plot(x, y, 'k')
    plt.plot(x2, y_pred, 'kx')

    plt.errorbar(x2, y_pred, y_pred_var, fmt='r.', capsize=5)

    plt.xlabel('x')
    plt.ylabel('y')
    plt.figure(2)
    plt.plot(range(0, EMiter), np.kron(np.ones(shape=(EMiter, 1)), sigma_eta), range(0, EMiter), sigma_eta_EM)
    plt.axis([0, EMiter, 0.048, 0.060])
    plt.ylabel('Noise variance')
    plt.xlabel('Iterations')

    plt.show()


if __name__ == '__main__':
    EMregression_12_16()
