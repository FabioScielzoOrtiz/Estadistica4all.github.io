# -----------------------------------------------------------------
#  Exercise 4.26
#  Noise cancelation
#  Python3 required packages: numpy, matplotlib
# -----------------------------------------------------------------

import numpy as np
from matplotlib import pyplot as plt


def noise_cancelation_4_26():
    rseed = 1
    np.random.seed(rseed)

    # create 5000 data samples of a simple sinusoidal signal
    N = 5000
    omega0 = 2 * 10 ** (-3) * np.pi
    s = np.ndarray((1, N), buffer=np.array([np.cos(omega0 * np.array(range(0, N)))])).transpose()

    # Create 5000 data samples of the AR proccesses  v_1 and v2
    v1 = np.zeros((N, 1))
    v2 = np.zeros((N, 1))
    d = np.zeros((N, 1))

    sigma = 0.05
    noise = sigma * np.random.randn(N, 1)
    a1 = 0.8
    a2 = 0.5

    v1[0] = 0
    v2[0] = 0

    for n in range(1, N):
        v1[n] = a1 * v1[n - 1] + noise[n]
        v2[n] = a2 * v2[n - 1] + noise[n]

    # Solve the Least Squares problem
    A = np.array([[sigma ** 2 / (1 - a2 ** 2), a2 * sigma ** 2 / (1 - a2 ** 2)],
                  [a2 * sigma ** 2 / (1 - a2 ** 2), sigma ** 2 / (1 - a2 ** 2)]])
    b = np.transpose(np.array([[sigma ** 2 / (1 - a1 * a2), a1 * sigma ** 2 / (1 - a1 * a2)]]))
    w = np.dot(np.linalg.inv(A), b)

    # Create the sequence of the "restored" signal
    d[0] = w[0] * v2[0]
    for n in range(1, N):
        d[n] = w[0] * v2[n] + w[1] * v2[n - 1]

    # plt.figure(1);
    # plt.subplot(1,2,1);
    # plt.plot(s+v1);
    # plt.subplot(1,2,2);
    # plt.plot(s+v1-d);

    # plot the results
    x_axis = np.arange(0, N, 1)
    plt.figure(1)
    plt.plot(x_axis, s + v1, 'r', lw=0.5)
    plt.title(r'Signal $d_n=s_n+v_1(n)$', fontsize=16)

    plt.figure(2)
    plt.plot(x_axis, s + v1 - d, 'r', lw=0.5)
    plt.title(r'Signal $s_n+v_1(n)-\hat d(n)$', fontsize=16)

    plt.show()


if __name__ == '__main__':
    noise_cancelation_4_26()

