# -----------------------------------------------------------------
#  Exercise 4.28
#  An AR estimation task based on Kalman filter.
#  Python3 required packages: numpy, matplotlib, functools
# -----------------------------------------------------------------


import numpy as np
from matplotlib import pyplot as plt
from functools import reduce


def kalman_4_28():
    rseed = 1
    np.random.seed(rseed)

    # Create 500 samples of the AR sequence
    N = 500
    x = np.zeros((N, 1))
    sigma_n = 0.7

    noise = sigma_n * np.random.randn(N, 1)

    a = np.zeros((2, 1))
    x = np.zeros((N, 1))
    a[0] = 0.2  # 0.95   0.8   0.6
    a[1] = 0.1  # 0.9   0.6   0.4
    x[0] = 4
    x[1] = -2
    for n in range(2, N):
        x[n] = -a[0] * x[n - 1] - a[1] * x[n - 2] + noise[n]

    # Create signal y = x + noise
    sigma_v = 0.2
    noise_v = sigma_v * np.random.randn(N, 1)
    y = x + noise_v

    # Kalman Filter
    F = np.array([[-a[0], -a[1]],
                  [1, 0]])
    H = np.array([[1, 0]])
    Q = np.array([[sigma_n ** 2, 0],
                  [0, 0]])
    R = sigma_v ** 2

    # initalization
    x_hat = np.zeros((N, 1))
    x0 = np.array([[0], [0]])
    # %P = ([[x(1)], [x(0)]]-x0)*([[x(1)], [x(0)]]-x0)';
    P = 0.01 * np.array([[1, 0],
                         [0, 1]])

    x_hat[range(1, -1, -1)] = x0

    # Iterations
    for n in range(0, N - 1):  # =1:N-1
        S = reduce(np.dot, [H, P, np.transpose(H)])
        S_inv =(1 / (S + np.spacing(1)))  # S is a 1x1 array, so no need for inv(S).simply use 1/S
        K = reduce(np.dot, [P, np.transpose(H), S_inv])  # np.linalg.inv(S)
        x0 = x0 + np.dot(K, y[n] - np.dot(H, x0))  # x0 + K * (y(n) - H * x0)
        P = P - reduce(np.dot, [K, H, P])
        x0 = np.dot(F, x0)  # F * x0
        P = reduce(np.dot, [F, P, np.transpose(F)]) + Q
        x_hat[range(n+1, n-1, -1)] = x0  # x_hat(n + 1: -1:n) = x0
        #print(x_hat[n+1])

        # S = R + np.dot(np.dot(H, P), np.transpose(H))  # S = R + H*P*H'
        # K = np.dot(P, np.dot(np.transpose(H), S_inv))  # P * H'*inv(S)
        # x0 = x0 + np.dot(K, y[n] - np.dot(H, x0))  # x0 + K * (y(n) - H * x0)
        # P = P - np.dot(np.dot(K, H), P)  # P - K * H * P
        # x0 = np.dot(F, x0)  # F * x0
        # P = np.dot(np.dot(F, P), np.transpose(F)) + Q  # F * P * F' + Q
        # x_hat[range(n+1, n-1, -1)][:] = x0  # x_hat(n + 1: -1:n) = x0

    # end of Kalman Filter

    # print(x_hat)
    # plot the results
    plt.figure(1)
    plt.plot(x[range(0, 51)], 'r', lw=0.75)
    # plt.hold(True)
    plt.plot(x_hat[range(0, 51)], 'k', lw=0.75)
    plt.xlabel(r'$n$')
    plt.ylabel(r'$x_n$')
    #
    plt.figure(2)
    plt.plot(y[range(0, 51)], 'r', lw=0.75)
    plt.xlabel(r'$n$')
    plt.ylabel(r'$y_n$')

    plt.show()


if __name__ == '__main__':
    kalman_4_28()

