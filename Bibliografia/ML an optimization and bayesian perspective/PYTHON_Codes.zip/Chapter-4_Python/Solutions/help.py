
import numpy as np
import math


def py_fspecial_motion(length=None, theta=None):
    """
    Equivalent function to Matlab's fspecial('motion', len, theta).
    :param length: Linear motion of a camera in pixels.
    :param theta: Angle of camera's linear motion in degrees, in a counterclockwise direction.
    :return: A filter which approximates the motion blur on success or None on failure
    """

    length = max(1, length)
    half = (length - 1) / 2

    phi = (theta % 180) / 180 * math.pi

    cosphi = math.cos(phi)
    sinphi = math.sin(phi)
    xsign = np.sign(cosphi)
    linewdt = 1

    # define mesh for the half matrix, eps takes care of the right size for 0 & 90 rotation
    sx = np.fix(half * cosphi + linewdt * xsign - length * np.spacing(1))  # np.spacing(1) --> eps
    sy = np.fix(half * sinphi + linewdt - length * np.spacing(1))

    [x, y] = np.meshgrid(np.r_[0:(sx + 1):xsign], np.r_[0:(sy + 1)])

    # define shortest distance from a pixel to the rotated line
    dist2line = y * cosphi - x * sinphi  # distance perpendicular to the line

    rad = np.sqrt(x ** 2 + y ** 2)
    # find points beyond the line 's end-point but within the line width
    lastpix = np.nonzero((rad >= half) & (abs(dist2line) <= linewdt))
    # distance to the line 's end-point parallel to the line
    x2lastpix = half - abs((x[lastpix] + dist2line[lastpix] * sinphi) / cosphi)

    dist2line[lastpix] = np.sqrt(dist2line[lastpix] ** 2 + x2lastpix ** 2)
    dist2line = linewdt + np.spacing(1) - abs(dist2line)
    dist2line[dist2line < 0] = 0  # zero out anything beyond line width

    # unfold half - matrix to the full size
    h = np.rot90(dist2line, 2)
    h_full = np.zeros(shape=(2 * h.shape[0] - 1, 2 * h.shape[1] - 1))

    h_full[0:h.shape[0], 0:h.shape[1]] = h
    h_full[h.shape[0] - 1:h_full.shape[0], h.shape[1] - 1:h_full.shape[1]] = dist2line
    h_full = h_full / (np.sum(h_full) + np.spacing(1) * length * length)

    if cosphi > 0:
        h_full = np.flipud(h_full)

    return h_full