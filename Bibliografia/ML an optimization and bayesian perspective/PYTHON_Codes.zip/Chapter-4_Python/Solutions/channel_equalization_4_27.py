# -----------------------------------------------------------------
#  Exercise 4.27
#  Channel equalization
#  Python3 required packages: numpy, matplotlib
# -----------------------------------------------------------------

import numpy as np
from matplotlib import pyplot as plt


def channel_equalization_4_27():
    rseed = 1
    np.random.seed(rseed)

    N = 50 + 2

    u = np.zeros((N, 1))
    d = np.zeros((N, 1))

    # Create a set of 50 equiprobable +-1 samples
    s = np.sign(2 * np.random.rand(N, 1) - 1)
    sigma = np.sqrt(np.var(s))

    # create a noise sequence
    sigma_n = 1

    # add the noise to the original sequence
    noise = sigma_n * np.random.randn(N, 1)

    # Solve the normal equations
    S = np.array([[1.25 * sigma ** 2 + sigma_n ** 2, 0.5 * sigma ** 2, 0],
                  [0.5 * sigma ** 2, 1.25 * sigma ** 2 + sigma_n ** 2, 0.5 * sigma ** 2],
                  [0, 0.5 * sigma ** 2, 1.25 * sigma ** 2 + sigma_n ** 2]])
    p = np.array([[sigma ** 2],
                  [0.5 * sigma ** 2],
                  [0]])
    w = np.linalg.solve(S, p)

    # create the reconstructed signal
    u[0] = 0
    u[1] = 0
    d[0] = 0
    d[1] = 0
    for n in range(2, N):
        u[n] = 0.5 * s[n] + s[n - 1] + noise[n]
        d[n - 1] = w[0] * u[n] + w[1] * u[n - 1] + w[2] * u[n - 2]

    # plot the results
    x_axis = np.arange(1, N-1, 1)
    plt.figure(1)
    plt.stem(x_axis, s[range(1, N-1)], 'k', markerfmt='None')

    plt.figure(2)
    plt.stem(x_axis, u[range(1, N-1)], 'k', markerfmt='None')

    errors = sum(abs(np.sign(d[range(1, N-1)]) - s[range(1, N-1)])) / 2

    valids_p = np.sign(d[range(1, N-1)]) == s[range(1, N-1)]
    errors_p = np.sign(d[range(1, N-1)]) != s[range(1, N-1)]

    plt.figure(3)
    # plt.hold(True)

    for n in range(1, N-1):
        if np.sign(d[n]) == int(s[n]):
            plt.stem(np.arange(n, n + 1), np.sign(d[n]), 'r', markerfmt='None')
        else:
            plt.stem(np.arange(n, n + 1), np.sign(d[n]), 'k', markerfmt='None')

    plt.show()


if __name__ == '__main__':
    channel_equalization_4_27()

