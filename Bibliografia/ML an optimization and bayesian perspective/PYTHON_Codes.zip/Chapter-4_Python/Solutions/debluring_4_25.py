# -----------------------------------------------------------------
#  Exercise 4.25
#  Image Debluring
#  Python3 required packages: os, sys, numpy, matplotlib, scipy, skimage
# -----------------------------------------------------------------

import os
import sys
import numpy as np
from matplotlib import pyplot as plt
from scipy.misc import imread
from scipy.signal import convolve2d
from skimage.restoration import wiener
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_4.help import py_fspecial_motion


def debluring_4_25():
    rseed = 1
    np.random.seed(rseed)
    # read grayscale image and rescale to [0,1]
    I = np.array(imread('boat_original.gif') / 255, dtype=np.double)
    # I = I / 255
    [M, N] = np.shape(I)

    # add motion using a Point-Spread Function
    psf = py_fspecial_motion(20, 45)
    J = convolve2d(I, psf, mode='same', boundary='wrap')

    # add noise
    noise_mean = 0
    noise_var = 0.000001
    J1 = J + noise_var * np.random.randn(M, N) + noise_mean

    # compute root mean square error and psnr
    rmse1 = np.sqrt(np.sum((I - J1) ** 2) / M / N)
    psnr1 = 20 * np.log10(1 / rmse1)

    # Wiener filtering (deblurring)
    # you can experiment with the value of nsr
    nsr = 10 ** -2  # 10**-4,   10**-5   10**-6   10**-3   10**-2
    K = wiener(J1, psf, nsr)

    # compute root mean square error and psnr
    # between original and deblurred pictures
    rmse2 = np.sqrt(np.sum((I - K) ** 2) / M / N)
    psnr2 = 20 * np.log10(1 / rmse2)

    # plot results
    plt.figure(1)
    plt.subplot(2, 2, 1)
    plt.imshow(I, cmap='gray')

    plt.subplot(2, 2, 2)
    plt.imshow(J1, cmap='gray')
    plt.title('PSNR = %.2f dB' % psnr1)

    plt.subplot(2, 2, 3)
    plt.imshow(K, cmap='gray')
    plt.title('PSNR = %.2f dB' % psnr2)

    plt.show()


if __name__ == '__main__':
    debluring_4_25()
