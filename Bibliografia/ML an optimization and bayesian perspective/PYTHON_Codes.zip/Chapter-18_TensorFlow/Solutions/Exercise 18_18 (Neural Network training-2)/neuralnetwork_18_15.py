# -----------------------------------------------------------------
#  Exercise 18.15
#  Feedforward Neural Networks
#  Python3 required packages: numpy, matplotlib, scipy
# -----------------------------------------------------------------
import numpy as np
import scipy
import matplotlib.pyplot as plt
import tensorflow as tf
import tensorflow.keras.backend as K

def neuralnetwork_18_15():
    np.random.seed(0)


    # 1. Generate data set X1
    l=2  # Dimensionality
    m1=np.array([[-5, 5], [5, -5]]).conj().T  # centroids
    m2=np.array([[-5, -5], [0, 0], [5, 5]]).conj().T
    [l,c1] = m1.shape # no of gaussians per class
    [l,c2] = m2.shape

    P1 = np.ones(shape=(1, c1))/c1  # weights of the mixture model
    P2 = np.ones(shape=(1, c2))/c2
    s = 6  # variance

    # Generate the training data from the first class
    N1 = 100  # 60; %Number of first class data points
    S1 = np.zeros(shape=(l, l, c1))
    for i in range(0, c1):
        S1[:,:,i]=s*np.eye(l)

    sed = 0  # Random generator seed
    [class1_X,class1_y] = mixt_model(m1,S1,P1,N1,sed)

    # Generate the training data from the second class
    N2 =150  # 80; # Number of second class data points
    S2 = np.zeros(shape=(l, l, c2))
    for i in range(0, c2):
        S2[:, :, i] = s * np.eye(l)

    sed=0
    [class2_X, class2_y] = mixt_model(m2,S2,P2,N2,sed)
    # Form X1
    X1= np.concatenate((class1_X,  class2_X), axis=-1)  # Data vectors
    y1=np.concatenate((np.ones(shape=(1,N1)), np.zeros(shape=(1,N2))), axis=-1)  # Class labels
    plt.figure(1)
    plt.plot(X1[0, np.where(y1== 1) ], X1[1, np.where(y1== 1) ],'r.',
             X1[0, np.where(y1== 0)], X1[1, np.where(y1== 0)],'bx')

    # Generate test set X2

    # Data of the first class
    sed = 100 # Random generator seed. This time we set this value to 100
    [class1_X, class1_y]=mixt_model(m1,S1,P1,N1,sed)

    # Data of the second class
    sed = 100  # Random generator seed
    [class2_X, class2_y]=mixt_model(m2,S2,P2,N2,sed)

    # Production of the unified data set

    X2 = np.concatenate((class1_X, class2_X), axis=-1)  # Data vectors
    y2 =np.concatenate((np.ones(shape=(1, N1)), np.zeros(shape=(1, N2))), axis=-1)  # Class labels


    # Definition and training of the network
    np.random.seed(100)

    iter = 6000  # Number of iterations
    k = 50  # number of hidden layer nodes
    lr = 0.01  # learning rate

    model1 = tf.keras.models.Sequential([
        # tf.keras.layers.Flatten(),
        tf.keras.layers.Dense(2, activation=None, input_dim=2),
        tf.keras.layers.Dense(k, activation=tf.nn.tanh),
        tf.keras.layers.Dense(1, activation=None)
    ])
    ri = 1.05
    rd = 0.7
    c = 1.04

    update_lr_callbak = My_Callback(ri,rd,c)
    opt = tf.keras.optimizers.SGD(lr=lr)
    # set model configurations
    model1.compile(optimizer=opt,
                   loss='binary_crossentropy',
                   metrics=['binary_accuracy'])

    # give test set as validation data if you want to see accuracy and loss for the test set during training
    batch_size = 6
    history = model1.fit(X1.conj().T, y1.conj().T, batch_size=batch_size, epochs=int(iter/batch_size), verbose=2,
                         callbacks=[update_lr_callbak])

    # Test the trained model on the test set. If you passed the test set as validation data during training,
    # test loss & accuracy will be the same to those of the last training epoch for the validation data
    pe_train, accu_train = model1.evaluate(X1.conj().T, y1.conj().T)
    pe_test, accu_test = model1.evaluate(X2.conj().T, y2.conj().T)

    print(pe_train)
    print(accu_train)
    print(pe_test)
    print(accu_test)



    # Plot the data points as well as the decision regions of the FNN
    maxi=np.max([[np.array(X1).conj().T],[np.array(X2).conj().T]])
    mini=np.min([[np.array(X1).conj().T],[np.array(X2).conj().T]])
    bou=[mini, maxi]
    fig_num=2  #  figure handle
    resolu=(bou[1]-bou[0])/100  # figure resolution
    #plot_NN_reg(net,bou,resolu,fig_num); # plot decision region
    plt.figure(fig_num),   # plot training set
    #figure(fig_num), plot(X1(1,y1==1),X1(2,y1==1),'r.', X1(1,y1==-1),X1(2,y1==-1),'bx')
    plt.figure(fig_num)
    plt.plot(X2[0,np.where(y2==1)], X2[1,np.where(y2==1)],'r.',
             X2[0,np.where(y2==0)], X2[1,np.where(y2==0)],'bx')

    # Plot the training error versus the number of iterations
    plt.figure(3)
    train_error_per_epoch = [(1 - x) * (N1+N2) for x in history.history['binary_accuracy']]
    plt.plot(train_error_per_epoch)

    plt.show()

def mixt_model(m, S, P, N, sed):
    # This function only works with 2 classes.
    # For multiple classes, one more loop may be included.
    np.random.seed(sed)
    X1 = np.random.multivariate_normal(np.array(m[:, 0]).conj().T, np.array(S[:, :, 0]),N).conj().T
    X2 = np.random.multivariate_normal(np.array(m[:, 1]).conj().T, np.array(S[:, :, 1]),N).conj().T
    n = np.zeros(shape=(N, 1))
    q = np.zeros(shape=(N, 1))
    X = np.zeros(shape=(X1.shape[0], N))
    for i in range(0, N):
        n[i] = np.random.rand()
        if n[i]<P[:,0]:
            q[i] = 1
            X[:,i] = np.array(X1[:,i])
        else:
            q[i] = 0
            X[:, i] = np.array(X2[:, i])


    y = 1-q

    return X, y


class My_Callback(tf.keras.callbacks.Callback):

    def __init__(self, ri=1.05, rd=0.7, c=1.04):
        super(My_Callback, self).__init__()#ri, rd, c)
        self.current_loss = None
        self.last_loss = None
        self.ri = ri
        self.rd = rd
        self.c = c

    def on_batch_end(self, batch, logs={}):
        self.current_loss = logs.get('loss')
        if self.last_loss is not None:
            lr = self.model.optimizer.lr

            if self.current_loss < self.last_loss:
                self.model.optimizer.lr = lr*self.ri
            elif self.current_loss > (self.c * self.last_loss):
                self.model.optimizer.lr = lr * self.rd
        # print(K.eval(self.model.optimizer.lr))
        self.last_loss = self.current_loss
        return

if __name__ == '__main__':
    neuralnetwork_18_15()