import tensorflow as tf
import csv
import matplotlib.pyplot as plt
from scipy.interpolate import spline
import numpy as np
# define hyperparameters
BATCH_SIZE = 100
TRAINING_EPOCHS = 600
VERBOSE = 2
LEARNING_RATE = 0.01


def mnist(model_type='all', save_curves=False):
    """
    Train and evaluate different feedforward neural networks for the mnist dataset.
    :param model_type: Network to train and evaluate. ('1': no Dropout, '2': Dropout 50% in hidden layers,
    '3': Dropout 50% in hidden layers and 20% in input layer. 'all' for training and evaluating all networks)
    :param save_curves: boolean variable to choose whether to save test error curves in .csv format for re-use.
    :return: 3 test error curves: test_error_per_epoch1, test_error_per_epoch2, test_error_per_epoch3.
    Some of them may be equal to None, depending on 'model_type' option
    """

    test_error_per_epoch1 = None
    test_error_per_epoch2 = None
    test_error_per_epoch3 = None

    # load mnist object from the embedded keras function
    mnist = tf.keras.datasets.mnist

    # load mnist data
    (x_train, y_train), (x_test, y_test) = mnist.load_data()

    # normalize values in [0, 1] range
    x_train, x_test = x_train / 255.0, x_test / 255.0

    if model_type == '1' or model_type == 'all':
        # define model 1: no Dropout
        model1 = tf.keras.models.Sequential([
          tf.keras.layers.Flatten(),
          tf.keras.layers.Dense(784, activation=tf.nn.relu),
          tf.keras.layers.Dense(2000, activation=tf.nn.relu),
          tf.keras.layers.Dense(2000, activation=tf.nn.relu),
          tf.keras.layers.Dense(10, activation=tf.nn.softmax)
        ])
        # set model configurations
        model1.compile(optimizer=tf.train.GradientDescentOptimizer(learning_rate=LEARNING_RATE),
                      loss='sparse_categorical_crossentropy',
                      metrics=['accuracy'])

        # give test set as validation data if you want to see accuracy and loss for the test set during training
        history1 = model1.fit(x_train, y_train, batch_size=BATCH_SIZE, epochs=TRAINING_EPOCHS, verbose=VERBOSE, validation_data=(x_test, y_test))

        # Test the trained model on the test set. If you passed the test set as validation data during training,
        # test loss & accuracy will be the same to those of the last training epoch for the validation data
        test_loss1, test_accuracy1 = model1.evaluate(x_test, y_test)
        print('Model 1: Test loss: %.6f. Test Accuracy: %.6f' % (test_loss1, test_accuracy1))

        # Find number of errors per epoch. 10000 is the number of test data
        test_error_per_epoch1 = [(1-x)*10000 for x in history1.history['val_acc']]

        if save_curves:
            with open('./model1.csv', 'w', newline='') as myfile:
                wr = csv.writer(myfile)
                wr.writerow(test_error_per_epoch1)

        # list all data in history
        # print(history1.history.keys())

    # define model 2: Dropout 50% in hidden layers
    if model_type == '2' or model_type == 'all':
        model2 = tf.keras.models.Sequential([
          tf.keras.layers.Flatten(),
          tf.keras.layers.Dense(784, activation=tf.nn.relu),
          tf.keras.layers.Dense(2000, activation=tf.nn.relu),
          tf.keras.layers.Dropout(0.5),
          tf.keras.layers.Dense(2000, activation=tf.nn.relu),
          tf.keras.layers.Dropout(0.5),
          tf.keras.layers.Dense(10, activation=tf.nn.softmax)
        ])
        # set model configurations
        model2.compile(optimizer=tf.train.GradientDescentOptimizer(learning_rate=LEARNING_RATE),
                      loss='sparse_categorical_crossentropy',
                      metrics=['accuracy'])

        # give test set as validation data if you want to see accuracy and loss for the test set during training
        history2 = model2.fit(x_train, y_train, batch_size=BATCH_SIZE, epochs=TRAINING_EPOCHS, verbose=VERBOSE,
                              validation_data=(x_test, y_test))

        # Test the trained model on the test set. If you passed the test set as validation data during training,
        # test loss & accuracy will be the same to those of the last training epoch for the validation data
        test_loss2, test_accuracy2 = model2.evaluate(x_test, y_test)
        print('Model 2: Test loss: %.6f. Test Accuracy: %.6f' % (test_loss2, test_accuracy2))

        # Find number of errors per epoch. 10000 is the number of test data
        test_error_per_epoch2 = [(1-x)*10000 for x in history2.history['val_acc']]

        if save_curves:
            with open('./model2.csv', 'w', newline='') as myfile:
                wr = csv.writer(myfile)
                wr.writerow(test_error_per_epoch2)
        # list all data in history
        # print(history2.history.keys())

    # define model 3: Dropout 50% in hidden layers and 20% in input layer
    if model_type == '3' or model_type == 'all':
        model3 = tf.keras.models.Sequential([
          tf.keras.layers.Flatten(),
          tf.keras.layers.Dense(784, activation=tf.nn.relu),
          tf.keras.layers.Dropout(0.2),
          tf.keras.layers.Dense(2000, activation=tf.nn.relu),
          tf.keras.layers.Dropout(0.5),
          tf.keras.layers.Dense(2000, activation=tf.nn.relu),
          tf.keras.layers.Dropout(0.5),
          tf.keras.layers.Dense(10, activation=tf.nn.softmax)
        ])
        # set model configurations
        model3.compile(optimizer=tf.train.GradientDescentOptimizer(learning_rate=LEARNING_RATE),
                      loss='sparse_categorical_crossentropy',
                      metrics=['accuracy'])

        # give test set as validation data if you want to see accuracy and loss for the test set during training
        history3 = model3.fit(x_train, y_train, batch_size=BATCH_SIZE, epochs=TRAINING_EPOCHS, verbose=VERBOSE,
                              validation_data=(x_test, y_test))

        # Test the trained model on the test set. If you passed the test set as validation data during training,
        # test loss & accuracy will be the same to those of the last training epoch for the validation data
        test_loss3, test_accuracy3 = model3.evaluate(x_test, y_test)
        print('Model 3: Test loss: %.6f. Test Accuracy: %.6f' % (test_loss3, test_accuracy3))

        # Find number of errors per epoch. 10000 is the number of test data
        test_error_per_epoch3 = [(1-x)*10000 for x in history3.history['val_acc']]

        if save_curves:

            with open('./model3.csv', 'w', newline='') as myfile:
                wr = csv.writer(myfile)
                wr.writerow(test_error_per_epoch3)

        # list all data in history
        # print(history3.history.keys())

    return test_error_per_epoch1, test_error_per_epoch2, test_error_per_epoch3


if __name__ == '__main__':
    # option whether to save error curves in .csv format
    save_curves = True

    # Train and evaluate 3 different mnist models
    test_error1, test_error2, test_error3 = mnist(model_type='all', save_curves=save_curves)

    # comment/uncomment the following sections depending on whether you would like to load test error data from .csv
    # files or use the test_error1, test_error2, test_error3 you've just trained.

    # #############################################################
    # plot curves
    # #############################################################
    smooth_factor = 2
    start_plot_from = 0
    x = np.array(range(0, TRAINING_EPOCHS))
    x_smooth = x[range(0, TRAINING_EPOCHS, smooth_factor)]

    if test_error1 is not None:
        y1 = np.array(test_error1)
        y1_smooth = spline(x, y1, x_smooth)
        plt.plot(x_smooth[start_plot_from:], y1_smooth[start_plot_from:], '--k', linewidth=0.75, markevery=smooth_factor)

    if test_error1 is not None:
        y2 = np.array(test_error2)
        y2_smooth = spline(x, y2, x_smooth)
        plt.plot(x_smooth[start_plot_from:], y2_smooth[start_plot_from:], 'k', linewidth=0.75, markevery=smooth_factor)

    if test_error1 is not None:
        y3 = np.array(test_error3)
        y3_smooth = spline(x, y3, x_smooth)
        plt.plot(x_smooth[start_plot_from:], y3_smooth[start_plot_from:], 'r', linewidth=0.75, markevery=smooth_factor)
    #############################################################


    #############################################################
    # plot curves from .csv files
    #############################################################
    # smooth_factor = 2
    # start_plot_from = 0
    # with open('./model1.csv', 'r') as f:
    #     reader = csv.reader(f, quoting=csv.QUOTE_NONNUMERIC)
    #     y = np.array(list(reader)[0])
    #     x = np.array(range(0, TRAINING_EPOCHS))
    #     x_smooth = x[range(0, TRAINING_EPOCHS, smooth_factor)]
    #     y_smooth = spline(x, y, x_smooth)
    #     plt.plot(x_smooth[start_plot_from:], y_smooth[start_plot_from:], '--k', linewidth=0.75, markevery=smooth_factor)
    #
    # with open('./model2.csv', 'r') as f:
    #     reader = csv.reader(f, quoting=csv.QUOTE_NONNUMERIC)
    #     y = np.array(list(reader)[0])
    #     x = np.array(range(0, TRAINING_EPOCHS))
    #     x_smooth = x[range(0, TRAINING_EPOCHS, smooth_factor)]
    #     y_smooth = spline(x, y, x_smooth)
    #     plt.plot(x_smooth[start_plot_from:], y_smooth[start_plot_from:], 'k', linewidth=0.75, markevery=smooth_factor)
    #
    # with open('./model3.csv', 'r') as f:
    #     reader = csv.reader(f, quoting=csv.QUOTE_NONNUMERIC)
    #     y = np.array(list(reader)[0])
    #     x = np.array(range(0, TRAINING_EPOCHS))
    #     x_smooth = x[range(0, TRAINING_EPOCHS, smooth_factor)]
    #     y_smooth = spline(x, y, x_smooth)
    #     plt.plot(x_smooth[start_plot_from:], y_smooth[start_plot_from:], 'r', linewidth=0.75, markevery=smooth_factor)
    # #############################################################

    # summarize history for accuracy
    plt.title('Test Error')
    plt.ylabel('Number of Errors')
    plt.xlabel('Epochs')
    plt.gca().xaxis.set_label_coords(0.59, -0.05)
    plt.gca().yaxis.set_label_coords(-0.05, 0.666)

    plt.xticks(range(0, TRAINING_EPOCHS+1, 100))
    plt.yticks(range(100, 250+1, 20))
    plt.legend(['no Dropout', 'Dropout 50% in hidden layers', 'Dropout 50% in hidden layers and 20% in input layer'],
               loc='upper right')

    plt.axis([0, 600, 100, 250])

    plt.savefig('./mnist_figure_600.eps', format='eps', dpi=300, bbox_inches='tight')

    plt.show()
