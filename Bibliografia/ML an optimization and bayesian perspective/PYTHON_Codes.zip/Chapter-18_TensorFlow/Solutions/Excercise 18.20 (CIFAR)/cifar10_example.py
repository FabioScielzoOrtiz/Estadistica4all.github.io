import os
import sys

sys.path.append(os.getcwd())
sys.path.append('../')
from cifar10_train import main as main_train
from cifar10_eval import main as main_val


def cifar10_example():

    optimizers = ['adam', 'sgd']
    initial_learning_rates = [0.01, 0.001, 0.0001, 0.00001]
    cnn_models = [1, 2, 3]

    # code for training all models
    for o in range(0, len(optimizers)):
        for l in range(0, len(initial_learning_rates)):
            for c in range(0, len(cnn_models)):

                model_name = optimizers[o]+'_'+str(initial_learning_rates[l])+'_'+str(cnn_models[c])
                # params[model_name] = [optimizers[o], initial_learning_rates[l], cnn_models[c]]

                # train with these parameters
                main_train(model_name, optimizers[o], initial_learning_rates[l], cnn_models[c])


    # code for evaluating all models
    for o in range(0, len(optimizers)):
        for l in range(0, len(initial_learning_rates)):
            for c in range(0, len(cnn_models)):

                model_name = optimizers[o]+'_'+str(initial_learning_rates[l])+'_'+str(cnn_models[c])

                # evaluate with these parameters
                main_val(model_name, cnn_models[c])

if __name__ == '__main__':
    cifar10_example()
