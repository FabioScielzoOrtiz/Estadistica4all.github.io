# ========================================================
# Case Study 14.11: Change Point Detection
# The matlab code has been kindly provided by Taylan Cemgil
# ========================================================

# CMPE58N_CP_POISS        Gibbs sampler for the Coal Mining Data

# Change History :
# Date        Time        Prog    Note
# 24-Mar-2009     7:53 PM    ATC    Created under MATLAB 7.7.0

# ATC = Ali Taylan Cemgil,
# Department of Computer Engineering, Bogazici University
# e-mail : taylan.cemgil@boun.edu.tr


import numpy as np
import matplotlib.pyplot as plt

import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_14.randgen import randgen

def casestudy_14_11():
    np.random.seed(1)

    # Coal mining data
    x=np.array([4, 5, 4, 1, 0, 4, 3, 4, 0, 6, 3, 3, 4, 0, 2, 6, 3, 3, 5, 4, 5, 3, 1, 4, 4, 1, 5, 5, 3, 4, 2, 5, 2, 2,
                3, 4, 2, 1, 3, 2, 2, 1, 1, 1, 1, 3, 0, 0, 1, 0, 1, 1, 0, 0, 3, 1, 0, 3, 2, 2, 0, 1, 1, 1, 0, 1, 0, 1, 0,
                0, 0, 2, 1, 0, 0, 0, 1, 1, 0, 2, 3, 3, 1, 1, 2, 1, 1, 1, 1, 2, 4, 2, 0, 0, 0, 1, 4, 0, 0, 0, 1, 0, 0, 0,
                0, 0, 1, 0, 0, 1, 0, 1])
    M = x.shape[0]

    m = np.ceil(M*np.random.rand())

    a = 2
    b = 1

    # plt.figure(1)
    EP = 1000

    BURN_IN = 200
    verbose = 0

    gibbs_m = np.zeros(shape=(1, EP-BURN_IN))
    gibbs_lambda = np.zeros(shape=(2, EP-BURN_IN))

    lam = np.zeros(shape=(2, 1))
    for e in range(0, EP):

        lam[0] = np.random.gamma(a + np.sum(x[0:int(m)]), 1/(m+b) )
        lam[1] = np.random.gamma(a + np.sum(x[int(m):]), 1/(M-m+b) )

        lp = np.zeros(shape=(1, M))
        for i in range(0, M):
            lp[0, i] = np.sum(x[0:i])*np.log(lam[0]) - (i+1)*lam[0] + np.sum(x[i:M])*np.log(lam[1]) - (M-i-1)*lam[1]

        m = randgen(np.exp(lp-np.max(lp)))

        if verbose:
            plt.subplot(211)
            #line([e e], [lam(1) lam(2)], 'marker', '.', 'lines','n' );
            plt.subplot(212)
            #line([e], [m],  'marker', 'o'  );

        if e > BURN_IN:
            gibbs_lambda[0, e-BURN_IN] = lam[0]
            gibbs_lambda[1, e-BURN_IN] = lam[1]
            gibbs_m[0, e-BURN_IN] = m

    plt.figure(1)

    plt.plot(gibbs_lambda[0, :], gibbs_lambda[1, :], '.')
    plt.xlim(left=0, right=4)
    # plt.ylim(top=0, bottom=4)
    plt.axis('square')
    plt.xlabel('l1')
    plt.ylabel('l2')

    plt.figure(2)
    plt.subplot(211)
    idx = range(1849, 1849+x.shape[0])
    plt.stem(idx, x, basefmt=" ")
    plt.ylabel('xj')
    plt.xlim(left=min(idx), right=max(idx)+1)

    plt.subplot(212)

    hs = np.bincount(np.array(gibbs_m.conj().transpose().flatten(), dtype=np.int))  # accum( a=gibbs_m.transpose(), size=(x.shape[0], 1))
    norm_hs =hs / np.sum(hs)
    plt.bar(range(min(idx), min(idx)+norm_hs.shape[0]), norm_hs)
    plt.xlim(left=min(idx), right=max(idx)+1)

    plt.ylabel('p(tau|x)')
    plt.xlabel('j')

    plt.show()


if __name__ == '__main__':
    casestudy_14_11()