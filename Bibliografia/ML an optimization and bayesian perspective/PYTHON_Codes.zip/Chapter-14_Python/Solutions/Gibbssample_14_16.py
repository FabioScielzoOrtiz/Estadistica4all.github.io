# -----------------------------------------------------------------
#  Exercise 14.16
#  Gibbs sampling
# -----------------------------------------------------------------
import numpy as np
import math
import matplotlib.pyplot as plt


def Gibbssample_14_16():
    np.random.seed(12345)
    n_samples = 10**3

    MeanValue = np.array([0, 0])  # mean vector
    sigma = np.array([0.5, 0.5])  # mean vector

    propSigma = 1 # proposal variance
    minimum = np.array([-4, -4])
    maximum = np.array([4, 4])

    # Samples initialization
    x = np.zeros(shape=(n_samples, 2))
    x[0, 0] = np.random.uniform(minimum[0], maximum[0])
    x[0, 1] = np.random.uniform(minimum[1], maximum[1])

    dimensions = np.array(range(0, 2))

    # Start Gibbs Sampler
    t = 0
    while t < (n_samples-1):
        t = t + 1
        T = [t-1,t]
        for iD in range(0,2):
            # sample update
            nIx = dimensions != iD
            # conditional mean
            ConditionalMean = MeanValue[iD] + sigma[iD]*(x[T[iD], nIx]-MeanValue[nIx])
            # conditional variance
            ConditionalVariance = math.sqrt(1-sigma[iD]**2)
            # sample from conditional pdf
            x[t, iD] = np.random.normal(ConditionalMean, ConditionalVariance)

    # Plot Samples
    plt.figure(1)
    h1 = plt.scatter(x[:,0], x[:,1],c='r', marker='.')
    h2 = plt.plot()
    # Plot Figures
    for t in range(0,10):
        plt.plot([x[t, 0], x[t+1, 0]], [x[t, 1], x[t, 1]], 'k-')
        plt.plot([x[t+1, 0], x[t+1, 0]], [x[t, 1], x[t+1, 1]], 'k-')
        h2 = plt.scatter(x[t+1, 0], x[t+1,1], c='k', marker='o')

    plt.legend(handles=[h1, h2], labels=['Samples', 'First 10 Samples'], loc='best')
    plt.xlabel('x_1')
    plt.ylabel('x_2')
    plt.grid()

    plt.show()


if __name__ == '__main__':
    Gibbssample_14_16()
