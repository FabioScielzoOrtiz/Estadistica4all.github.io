
import numpy as np


def randgen(p=None, m=1, n=1, s=None):
    """
    RANDGEN	Generates discrete random variables given the pdf

    Y = RANDGEN(P, M, N, S)

    Inputs :
    P : Relative likelihoods (or pdf) of symbols
    M : Rows    <Default = 1>
    N : Columns <Default = 1>
    S : Symbols <Default 1:length(P)>
    Change History :
    Date		Time		Prog	Note
    06-Jul-1997	 4:36 PM	ATC	Created under MATLAB 5.0.0.4064

    ATC = Ali Taylan Cemgil,
    Bogazici University, Dept. of Computer Eng. 80815 Bebek Istanbul Turkey
    e-mail : cemgil@boun.edu.tr
    """
    if p is None:
        return np.array([])  # no samples if p is empty (DB)
    if s is None:
        s = np.array(range(0, p.shape[1]))

    c = np.cumsum(p)
    c = c[:].conj().transpose() / c[len(c)-1]
    c = np.reshape(c, newshape=(1, c.shape[0]))
    N = m*n
    u = np.ones(shape=(N, c.shape[0]))
    u[0] = np.random.rand(N, 1)

    y = np.count_nonzero(c[np.zeros(shape=(N, 1), dtype=np.int), :] <
                         u[:, np.zeros(shape=(c.shape[0]), dtype=np.int)])
    y = np.reshape(s[y], newshape=(m, n))

    return y
