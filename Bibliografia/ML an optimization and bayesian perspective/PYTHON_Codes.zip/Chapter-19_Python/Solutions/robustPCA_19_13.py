#---------------------------------------------------------------------------------------------------------------------------------------------------
# Exercise 19_13
# Robuast PCA.
# Download escalator data from http://cvxr.com/tfocs/demos/rpca/escalator_data.mat
# RPCA algorithm can be found here: https://github.com/dganguli/robust-pca
#----------------------------------------------------------------------------------------------------------------------------------------------------
from scipy.io import loadmat
import numpy as np
from matplotlib import pyplot as plt
from scipy.misc import imresize
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_19.help import *


def robustPCA_19_13():
    data = loadmat('escalator_data.mat')
    X = np.array(data['X'], dtype=np.float)
    m = data['m'][0][0]
    n = data['n'][0][0]
    nFrames = X.shape[1]

    # Download approximate proximal gradient method from http://perception.csl.illinois.edu/matrix-rank/sample_code.html
    # and add it in the matlab path


    maxIter =100
    lamda = 0.01

    rpca = R_pca(X, lmbda=lamda)
    LL, SS = rpca.fit(max_iter=maxIter, iter_print=10)

    fig, ax = plt.subplots(nrows=1, ncols=3)
    for k in range(0, nFrames):

        ax[0].imshow(np.reshape(X[:, k], newshape=(m, n), order='F'), cmap='gray')
        ax[1].imshow(np.reshape(LL[:, k], newshape=(m, n), order='F'), cmap='gray')
        ax[2].imshow(np.reshape(SS[:, k], newshape=(m, n), order='F'), cmap='gray')
        plt.show(block=False)
        plt.pause(0.05)

    plt.show()


if __name__ == '__main__':
    robustPCA_19_13()