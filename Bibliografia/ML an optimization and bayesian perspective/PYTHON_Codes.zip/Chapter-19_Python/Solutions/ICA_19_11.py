#-----------------------------------------------------------------------------------------------
# Exercise 19.11
# ICA.
# Required Python packages: numpy, soundfile, sounddevice, scikit-learn
#------------------------------------------------------------------------------------------------

import soundfile as sf
import sounddevice as sd
from sklearn.decomposition import FastICA
import numpy as np
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')

def ICA_19_11():
    [x1, fs] = sf.read('voice1.wav')
    [x2, fs] = sf.read('voice2.wav')
    [x3, fs] = sf.read('music.wav')

    X = np.array([x1.conj().transpose(), x2.conj().transpose(), x3.conj().transpose()])

    # Play Original Audio Signals
    print('Playing original sounds...')
    for i in range(0, 3):
        sig = X[i, :]/np.max(np.abs(X[i, :]))
        sd.play(sig, fs, blocking=True)

    # Make the mixtures
    A = np.abs(np.random.rand(3, 3))
    Y = np.dot(A, X)
    # Play Audio Mixtures
    print('Playing audio mixtures...')
    for i in range(0, 3):
        sig = Y[i, :]/np.max(np.abs(Y[i, :]))
        sd.play(sig, fs, blocking=True)

    # Perform ICA
    f = FastICA(algorithm='deflation', fun='cube', max_iter=1000)
    icasig = f.fit_transform(Y.conj().transpose()).conj().transpose()
    # Play ICA-based recovered Signals
    print('Playing ICA-based recovered Signals...')
    print(icasig.shape)
    for i in range(0, 3):
        sig = icasig[i, :]/np.max(np.abs(icasig[i, :]))
        sd.play(sig, fs, blocking=True)

    # Unmix using PCA
    [U, S, V] = np.linalg.svd(np.dot(Y, Y.conj().transpose()))
    PCAestim = np.dot(U.conj().transpose(), Y)

    # Play PCA-based recovered Signals
    print('Playing PCA-based recovered Signals...')
    for i in range(0, 3):
        sig = PCAestim[i, :]/np.max(np.abs(PCAestim[i, :]))
        sd.play(sig, fs, blocking=True)


if __name__ == '__main__':
    ICA_19_11()
