
#----------------------------------------------------------------------------------------------------------
# Exercise 19.12
# Dictionary learning.
# K-SVD is assumed to be downloaded and properly installed: https://github.com/nel215/ksvd
# Python3 required packages: numpy, ksvd, matplotlib, scikit-learn, scipy, scikit-image
#----------------------------------------------------------------------------------------------------------
import numpy as np
from ksvd import ApproximateKSVD
from matplotlib import pyplot as plt
from scipy.io import loadmat
from skimage import util
from sklearn.feature_extraction import image
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')

def dictionarylearn_19_12():
    x_exact = np.array(loadmat('boats.mat')['boats'])

    sigma = 20
    x_noise = x_exact + np.random.randn(x_exact.shape[0], x_exact.shape[1]) * sigma
    blocksize = 12  # block size
    K = 14 ** 2  # number of atoms in the dictionary

    # Training of the  dictionary
    # data = np.array(X)
    Edata = 0.1
    dictsize = K
    iternum = 100
    Tdata = 5

    img = util.img_as_float(x_noise)
    patch_size = (blocksize, blocksize)
    patches = image.extract_patches_2d(img, patch_size)
    signals = patches.reshape(patches.shape[0], -1)
    mean = np.mean(signals, axis=1)[:, np.newaxis]
    signals -= mean
    aksvd = ApproximateKSVD(n_components=dictsize, max_iter=iternum, tol=Edata, transform_n_nonzero_coefs=Tdata)
    dictionary = aksvd.fit(signals).components_
    gamma = aksvd.transform(signals)
    reduced = gamma.dot(dictionary) + mean
    X_reconst = image.reconstruct_from_patches_2d(
        reduced.reshape(patches.shape), img.shape)

    print(20 * np.log10(255 * np.sqrt(x_exact.shape[0] * x_exact.shape[1]) / np.linalg.norm(x_exact - X_reconst)))

    plt.figure(1)
    plt.subplot(1, 3, 1)
    plt.imshow(x_exact, cmap='gray', vmin=0, vmax=255)
    plt.subplot(1, 3, 2)
    plt.imshow(x_noise, cmap='gray', vmin=0, vmax=255)
    plt.subplot(1, 3, 3)
    plt.imshow(X_reconst, cmap='gray', vmin=0, vmax=255)

    plt.show()


if __name__ == '__main__':
    dictionarylearn_19_12()