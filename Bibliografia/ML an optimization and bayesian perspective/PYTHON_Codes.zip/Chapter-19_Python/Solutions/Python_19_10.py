# -------------------------------------------------------------------------------
# Exercise 19.10
# You must download the images from
# http://cgi.di.uoa.gr/~stheodor/faces.rar
# Required Python packages: numpy, scipy, matplotlib
# --------------------------------------------------------------------------------

import numpy as np
from scipy.misc import imread
import matplotlib.pyplot as plt
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')

def PYTHON_19_10():
    sizeimages = 168

    dirname = './faces/faces/'

    img_count = 0
    sum_of_files = 0
    for root, dirs, files in os.walk(dirname):
        sum_of_files = len(files)

    X = np.zeros(shape=(sizeimages ** 2, sum_of_files))

    for root, dirs, files in os.walk(dirname):
        if not root.endswith('/'):
            root = root + '/'

        while img_count < len(files):
            img = imread(root+files[img_count])
            X[:, img_count] = np.array(img.flatten(), dtype=np.uint8)

            img_count += 1

    N = X.shape[1]
    # choose a face randomly
    pickrandom = np.random.choice(range(0, N), 1)
    testimg = X[:, pickrandom]

    subim = 0
    fig, ax = plt.subplots(nrows=1, ncols=3)

    img = np.reshape(testimg, newshape=(168, 168))  # The mean is added back again in order to display it correctly
    normalized_img = (img - np.min(img)) / (np.max(img) - np.min(img))  # normalize to [0, 1] for plotting
    ax[subim].imshow(normalized_img, cmap='gray', interpolation='none', vmin=0, vmax=1)
    ax[subim].set_title('original')
    subim = subim + 1

    X = np.delete(X, pickrandom, axis=1)
    N = X.shape[1]

    #  Subtract out the means from each parameter
    mX = np.mean(X, axis=1)
    mX = np.reshape(mX, newshape=(mX.shape[0], 1))

    X = X - np.kron(np.ones((1, N)), mX)

    # Effectively compute the eigenvectors based on X'X.
    [S, eigenvalues, vh] = np.linalg.svd(np.dot(X.conj().transpose(), X))

    eigenvectors = np.dot(X, S)

    for i in range(0, X.shape[1]):
        eigenvectors[:, i] = 1/np.sqrt(eigenvalues[i])*eigenvectors[:, i]


    # Reconstruct using different number of eigenvectors
    PP = np.dot(eigenvectors.conj().transpose(), np.array(testimg, dtype=np.float))
    b = np.argsort(np.abs(PP.flatten()))[::-1]

    howmany = 300

    recimg = np.dot(eigenvectors[:, b[0:howmany].flatten()], PP[b[0:howmany].flatten()])+mX
    img = np.reshape(recimg, newshape=(168, 168))
    normalized_img = (img - np.min(img)) / (np.max(img) - np.min(img))  # normalize to [0, 1] for plotting
    ax[subim].imshow(normalized_img, cmap='gray', interpolation='none', vmin=0, vmax=1)
    ax[subim].set_title(str(howmany) + ' eigen')
    subim = subim + 1

    howmany = 1000
    recimg = np.dot(eigenvectors[:, b[0:howmany].flatten()], PP[b[0:howmany].flatten()])+mX
    img = np.reshape(recimg, newshape=(168, 168))
    normalized_img = (img - np.min(img)) / (np.max(img) - np.min(img))  # normalize to [0, 1] for plotting
    ax[subim].imshow(normalized_img, cmap='gray', interpolation='none', vmin=0, vmax=1)
    ax[subim].set_title(str(howmany) + ' eigen')
    subim = subim + 1


    plt.show()

if __name__ == '__main__':
    PYTHON_19_10()