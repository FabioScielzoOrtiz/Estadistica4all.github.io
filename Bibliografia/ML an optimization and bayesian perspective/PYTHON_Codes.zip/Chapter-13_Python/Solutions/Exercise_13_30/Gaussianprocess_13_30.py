#-----------------------------------------------------------------
#  Exercise 13.30
#  Gaussian process regression
#  Python3 required packages: numpy, scipy, matplotlib
#-----------------------------------------------------------------

import numpy as np
import matplotlib.pyplot as plt
import scipy
from scipy import linalg
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')



def frange(x, y, jump):
    values = []
    while x < y:
        values.append(x)
        x += jump

    return values
def Gaussianprocess_13_25():



    np.random.seed(0)
    # generate samples from a GP first
    N = 20
    # input samples
    x = np.random.randn(N,1)

    # plot samples
    # plt.figure()
    # plt.plot(x,np.ones(shape(1,N)),'.')

    # compute the gaussian kernel
    [x1, x2] = np.meshgrid(x, x)

    # length scale parameter
    h = .5
    K = np.exp(- .5 * np.power((x1-x2), 2) / h**2)


    noise_var = 0.1
    # generate data
    # np.linalg.cholesky(K) May not be positive definite
    # so:
    (L, pd) = linalg.lapack.dpotrf(K)
    while pd > 0:
        K = K + np.eye(N) * 0.01
        (L, pd) = scipy.linalg.lapack.dpotrf(K)

    y = np.dot(L.conj().transpose(), np.random.randn(N, 1)) + \
        np.sqrt(noise_var) * np.random.randn(N,1)
    plt.figure(1)
    plt.plot(x, y, '+')

    # prediction points
    D = 100
    xp = np.linspace(-3, 4, D).conj().transpose()

    # Compute the mean and the covariance function of the predictive GP
    Sigma_N = K + noise_var * np.eye(N)
    xk1 = np.kron(np.ones(shape=(1, D)), x)
    xk2 = np.kron(np.ones(shape=(N, 1)), xp.conj().transpose())

    k = np.exp(- .5 * np.power((xk1 - xk2), 2) / h**2 )
    muf = np.zeros(shape=(D, 1))
    sigma_y = np.zeros(shape=(D, 1))
    Ry = np.linalg.solve(Sigma_N, y)
    for d in range(0, D):
        muf[d] = np.dot(k[:,d].conj().transpose(), Ry)
        sigma_y[d] = 1 - np.dot(k[:,d].conj().transpose(), np.linalg.solve(Sigma_N,k[:,d]))

    f = np.concatenate([muf + 2 * np.sqrt(sigma_y), np.flipud(muf-2*np.sqrt(sigma_y))])

    # plot the results
    plt.fill(np.concatenate([xp, np.flipud(xp)]), f, color =(7/8,7/8,7/8))
    plt.figure(2)
    plt.plot(xp, muf, 'r')
    plt.plot(x, y, '+k')
    plt.axis('tight')

    # 2nd version - Compute the mean and the covariance function
    # of the predictive GP using matrix calculations -
    [xxp1,xxp2] = np.meshgrid(x,xp)
    Kxxp = np.exp(- .5 * np.power((xxp1-xxp2), 2) / h**2 )
    [xp1,xp2] = np.meshgrid(xp,xp)
    Kxp = np.exp(- .5 * np.power((xp1-xp2), 2) / h**2 )

    K_f = np.array([[K+noise_var*np.eye(N), Kxxp.conj().transpose()], [Kxxp, Kxp]])
    mu_f = np.dot(Kxxp, np.dot(np.linalg.inv(K+noise_var*np.eye(N)), y))
    Sigma_f = Kxp - np.dot(Kxxp, np.dot(np.linalg.inv(K+noise_var*np.eye(N)), Kxxp.conj().transpose()))
    f = np.concatenate([mu_f + 2 * np.sqrt(np.diag(Sigma_f)), np.flipud(mu_f-2*np.sqrt(np.diag(Sigma_f)))])

    # plot the results

    plt.figure(3)
    plt.fill(np.concatenate([xp, np.flipud(xp)]), f, color =(7/8,7/8,7/8))
    plt.plot(xp, mu_f, 'r')
    plt.plot(x, y, '+k')
    plt.axis('tight')

    plt.show()

if __name__ == '__main__':
    Gaussianprocess_13_25()