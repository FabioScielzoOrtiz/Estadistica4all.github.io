#-----------------------------------------------------------------
#  Exercise 13.31
#  Hyperspectral unmixing
#  Notice that the unmixing process, using the full image,
#  requires a few hours. To shorten the time, part of the image
#  can be used.
#  Python3 required packages: numpy, scipy, matplotlib
#-----------------------------------------------------------------


from scipy.io import loadmat
from matplotlib import pyplot as plt
import numpy as np
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')
sys.path.append('../../')
from PYTHON_13.Exercise_13_27.VCA import vca
from PYTHON_13.Exercise_13_27.mpLaplace_truncatedGaussian_vB import mpLaplace_truncatedGaussian_vB


#-----------------------------------------------------------------
#  Exercise 13.27
#  Hyperspectral unmixing
#  Notice that the unmixing process, using the full image,
#  requires a few hours. To shorten the time, part of the image
#  can be used.
#-----------------------------------------------------------------

def HSIvB():

    # load the hyperspectral image
    data = loadmat('cuprite_ref.mat')
    x = np.array(data['x'])
    Lines = data['Lines'][0][0]
    Columns = data['Columns'][0][0]
    L = data['L'][0][0]


    # number of endmembers
    Nen = 14

    # number of pixels - to shorten computation time, select 100 pixels only
    Np = x.shape[1]

    #extract endmembers using VCA algorithm
    Phi, indice, Yp = vca(Y=x,R=Nen)
    Phi_gram = np.dot(Phi.conj().transpose(), Phi)

    [M,N] = Phi.shape

    const = 1e-10
    MaxIter = 10  # 10000

    w_vb = np.zeros(shape=(N, Np))

    for n in range(0, Np):
        print(n)
        # variational Bayes abundance estimation
        [w, bt] = mpLaplace_truncatedGaussian_vB(Phi, x[:,n], Phi_gram, MaxIter, const)
        w_vb[:, n] = w.reshape(1, -1)


    # reshape variables to display abundance maps
    im = np.zeros(shape=(Lines, Columns, L))
    w_vb_im = np.zeros(shape=(Lines, Columns, Nen))

    for i in range(0, Lines):
        for j in range(0, Columns):
            if (j-1) * Lines + i >= w_vb.shape[1]:
                continue
            im[i, j, :] = x[:, (j-1) * Lines + i]
            w_vb_im[i, j, :] = w_vb[:, (j-1) * Lines + i]

    # display abundance maps
    for i in range(0, Nen):
        plt.figure()
        normalized_img = (w_vb_im[:,:,i] - np.min(w_vb_im[:,:,i])) / (np.max(w_vb_im[:,:,i]) - np.min(w_vb_im[:,:,i]))  # normalize to [0, 1] for plotting
        plt.imshow(normalized_img, cmap='gray', interpolation='none', vmin=0, vmax=1)
        # plt.imshow(w_vb_im[:,:,i], cmap='gray', vmin=0, vmax=255)
        plt.axis('off')

    plt.show()
if __name__ == '__main__':
    HSIvB()