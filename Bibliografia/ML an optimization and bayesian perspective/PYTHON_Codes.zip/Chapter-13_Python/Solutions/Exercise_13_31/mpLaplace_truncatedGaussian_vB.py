
import numpy as np
from scipy.special import erfc
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')


def mpLaplace_truncatedGaussian_vB(Phi, y, Phi_gram, MaxIter, const):
    #  Function
    #  Variational Bayes for linear regression based on a multiparameter
    #  truncated Laplace prior
    #
    #  Input
    #  Phi:      Endmember matrix
    #  y:        Pixel's spectral measurements
    #  Phi_gram: Gramian matrix of Phi, Phi
    # ' * Phi
    #  MaxIter:  Maximum Iterations ~ 1e3
    #  const:    small constant ~ 1e-8
    #
    #  Output
    #  w_vb:     Estimated abundance vector
    #  bt:       Estimated noise precision
    #
    #  Copyright K. Themelis, A. Rontogiannis, K. Koutroumbas


    [M,N] = Phi.shape

    # indexes
    indx = np.zeros(shape=(N-1,N), dtype=np.int)
    for n in range(0, N):
        tmp = list(range(0, N))
        del tmp[n]
        indx[:, n] = np.array(tmp, dtype=np.int)

    alph = np.ones(shape=(N,1))  # initialization
    bn = np.ones(shape=(N,1))
    mu = np.zeros(shape=(N,1))
    mutr = np.zeros(shape=(N,1))
    sgmitr = np.ones(shape=(N,1))

    t = 0
    while 1:
        t = t + 1
        mutr_old = np.array(mutr)

        bt = (2e-6 + N + M ) / (2e-6 + np.sum(np.multiply(alph, (np.power(mutr,2) + sgmitr))) + np.linalg.norm(y-np.dot(Phi, mutr)) + np.dot(sgmitr.conj().transpose(), np.diag(Phi_gram) ))

        # untruncated variance

        sgmi =  np.power((alph + np.diag(Phi_gram).reshape(-1,1) ), -1) / bt
        sgmisd = np.sqrt(sgmi)
        sgmitr = np.array(sgmi)


        for n in range(0, N):
            # untruncated mean
            mu[n] = np.dot(Phi[:, n].conj().transpose().reshape(1,-1), (y.reshape(-1,1) - np.dot(Phi[:,indx[:,n]], mutr[indx[:,n]]))) / (alph[n] + Phi_gram[n, n])

            # truncated mean
            tmp = np.array(1 - .5 * erfc(mu[n] /np.sqrt(2) /sgmisd[n]))[0]
            if tmp > const:
                mutr[n] = mu[n] + sgmisd[n] / np.sqrt(2 * np.pi) * np.exp(-.5 * mu[n]**2 / sgmi[n]) / tmp # truncated mean
                tmp1 = np.exp( - mu[n]**2 / sgmi[n] / 2)  / np.sqrt(2*np.pi)  / tmp
                sgmitr[n] = sgmi[n] * (1 - mu[n] / sgmisd[n] * tmp1 - tmp1**2 )  # truncated variance
            else:
                if mu[n] < 0:
                    mu[n] = 1e-6


        alph = np.sqrt( bn / (bt * (np.power(mutr,2) + sgmitr)))

        bn = (2e-6 + 2) / (2e-6 + 1./alph + 1./bn )

        if ( np.linalg.norm(mutr - mutr_old) < const or t > MaxIter):
            w_vb = np.array(mu)
            break

    return w_vb, bt
