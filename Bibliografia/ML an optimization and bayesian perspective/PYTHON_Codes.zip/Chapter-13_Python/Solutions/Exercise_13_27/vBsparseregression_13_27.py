#-----------------------------------------------------------------
#  Exercise 13.27
#  Variational Bayes Sparse Regression
#  Python3 required packages: numpy, scipy, matplotlib
#-----------------------------------------------------------------
import numpy as np
from scipy import interpolate
import matplotlib.pyplot as plt
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_13.error_ellipse2 import plot_cov_ellipse


def frange(x, y, jump):
    values = []
    while x < y:
        values.append(x)
        x += jump

    return values
def vBsparseregression_13_23():


    np.random.seed(0)

    # #sampling points
    M = 100

    # SNR value
    SNR = 6

    # positions of the non-zero basis
    K = np.array([[22], [64]])

    # generate sampling points
    x = np.linspace(-10, 10, M).conj().transpose()

    # basis matrix
    Phi = np.zeros(shape=(M, M))
    for i in range(0, M):
        Phi[:, i] = np.exp(- .5 * 10 * (x-x[i])**2)

    Phi_cov = np.dot(Phi.conj().transpose(), Phi)

    # original signal
    y_0 = Phi[:, K[0]] + Phi[:, K[1]]

    # add noise
    s_y = np.dot(y_0.conj().transpose(), y_0)/M
    s_n = s_y / 10**(SNR/10)
    n = np.sqrt(s_n) * np.random.randn(M, 1)

    # observations
    y = y_0 + n

    # least squares estimation
    w_LS = np.linalg.solve(Phi_cov, np.dot(Phi.conj().transpose(), y))
    y_LS = np.dot(Phi, w_LS)

    # EM algorithm
    # initialization
    EMiter = 100
    beta = 1e0
    alpha_EM = 1
    Sigma_EM = np.eye(M)
    for i in range(0, EMiter):
        Sigma_EM = np.linalg.inv(beta * (Phi_cov) + alpha_EM * np.eye(M))
        mu_EM = beta * np.dot(Sigma_EM, np.dot(Phi.conj().transpose(), y))

        alpha_EM = M/(np.dot(mu_EM.conj().transpose(), mu_EM) + np.trace(Sigma_EM))

        beta = M / (np.linalg.norm(y - np.dot(Phi, mu_EM))**2 + np.trace(np.dot(Sigma_EM, Phi_cov)))

    # EM estimates
    y_EM = np.dot(Phi, mu_EM)


    # Variational Bayes algorithm
    # initialization
    VBiter = 200
    beta = 1e2
    alpha_VB = 3e5 * np.ones(shape=(M,1))
    hyp_j = 0
    mu_VB = np.zeros(shape=(M, 1))
    for i in range(0, VBiter):
        Sigma_VB = np.linalg.inv(beta * (Phi_cov) + np.diag(np.diag(alpha_VB)))
        mu_VB = beta * np.dot(Sigma_VB, np.dot(Phi.conj().transpose(), y))

        alpha_VB = (hyp_j + .5)/(hyp_j + .5 * (np.power(mu_VB,2) + np.diag(Sigma_VB)) )

        beta = (hyp_j + .5 * M)/(hyp_j + .5 * (np.linalg.norm(y - np.dot(Phi, mu_VB))**2 + np.trace(np.dot(Sigma_VB, Phi_cov))) )
    # variational Bayes estimates
    y_VB = np.dot(Phi, mu_VB)

    # plot the results
    plt.figure()
    xx = np.array(frange(-10, 10.01, 0.01))
    # use spline to smooth curves
    spline = interpolate.splrep(x, y_0, s=0)  # UnivariateSpline(x, y_0)
    y_0p = interpolate.splev(xx, spline, der=0)  # spline(xx)
    spline = interpolate.splrep(x, y_LS, s=0)  # UnivariateSpline(x, y_LS)
    y_LSp = interpolate.splev(xx, spline, der=0)  # spline(xx)
    spline = interpolate.splrep(x, y_EM, s=0)  # UnivariateSpline(x, y_EM)
    y_EMp = interpolate.splev(xx, spline, der=0)  # spline(xx)
    spline = interpolate.splrep(x, y_VB, s=0)  # UnivariateSpline(x, y_VB)
    y_VBp = interpolate.splev(xx, spline, der=0)  # spline( xx)
    plt.plot(np.reshape(x, newshape=(x.shape[0], 1)), y, 'xk')
    plt.plot(xx, y_0p, 'r', xx, y_LSp, '--r', xx, y_EMp, '--k', xx, y_VBp, 'k')
    plt.legend(['Observations', 'Original', 'ML', 'EM', 'Variational'], loc='upper right')

    plt.show()


if __name__ == '__main__':
    vBsparseregression_13_23()