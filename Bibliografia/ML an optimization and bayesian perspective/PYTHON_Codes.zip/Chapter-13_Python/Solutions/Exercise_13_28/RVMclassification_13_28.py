#-----------------------------------------------------------------
#  Exercise 13.28
#  RVM classification
#  Use skrvm Python package
#      found at https://github.com/JamesRitchie/scikit-rvm
# Python3 required packages: numpy, matplotlib, skrvm
#-----------------------------------------------------------------

import numpy as np
import matplotlib.pyplot as plt
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')
from skrvm import RVC


def RVMclassification_13_24():

    np.random.seed(0)
    # data dimension
    l = 2

    # number of data points
    N = 150

    # generate the data
    x1 = 10 * np.random.rand(l,N) - 5
    y1 = np.zeros(shape=(N,1))
    for i in range(0, N):
        t = .05 * (x1[0, i]**3 + x1[0, i]**2 + x1[0, i] + 1)
        if (t + 2*np.random.randn(1)) > x1[1, i]:
            y1[i] = 1
        else:
            y1[i] = 0


    # Plot the training data
    COL_data1	= 0.5*np.ones(shape=(3,))
    COL_data2	= np.array([1, 0, 0])
    COL_boundary25	= 0.5*np.ones(shape=(3,1))
    COL_boundary75	= 0.5*np.ones(shape=(3,1))
    COL_rv = 'k'
    plt.figure(1)

    plt.plot(x1[0, np.argwhere(y1==0)],x1[1, np.argwhere(y1==0)],'.',markersize=5, color=COL_data1)
    plt.plot(x1[0, np.argwhere(y1==1)], x1[1, np.argwhere(y1==1)],'.',markersize=5, color=COL_data2)
    box	= 1.1*np.array([np.min(x1[0,:]), np.max(x1[0,:]), np.min(x1[1,:]), np.max(x1[1,:])])
    plt.axis(box)

    kernel_	= 'rbf'
    # variance of the gaussian kernel
    width		= 3
    # max iterations
    maxIts	= 1000

    # Set up initial hyperparameters - precise settings should not be critical
    initAlpha	= (1/N)**2
    # Set beta to zero for classification
    initBeta = 0
    useBias	= True
    monIts = round(maxIts/10)

    clf = RVC(alpha=initAlpha, beta=initBeta, kernel=kernel_, degree=width, n_iter_posterior=monIts, n_iter=maxIts, bias_used=useBias, verbose=True)
    clf.fit(x1.conj().transpose(), y1.flatten())
    alpha = clf.alpha_
    beta = clf.beta_
    gamma = clf.gamma
    marginal = clf.m_
    used = clf.relevance_
    bias = clf.bias
    weights = clf.m_

    # visualise the results over a grid
    gsteps		= 50
    range1		= np.linspace(box[0], box[1], gsteps)
    range2		= np.linspace(box[2], box[3], gsteps)
    [grid1, grid2]	= np.meshgrid(range1, range2)
    Xgrid	= np.array([grid1.flatten(),grid2.flatten()]).conj().transpose()

    # Evaluate RVM
    y_grid = clf.predict(Xgrid)

    # apply sigmoid for probabilities
    p_grid = 1./(1+np.exp(-y_grid))

    # show decision boundary (p=0.5) and illustrate p=0.25 and 0.75
    plt.contour(range1, range2, np.reshape(p_grid,newshape=grid1.shape), [0.5], colors=COL_rv, linestyles='dashed', linewidths=1)


    # show relevance vectors
    plt.plot(used[:, 0], used[:,1], 'o',linewidth=2, markerfacecolor='none', markersize=10, markeredgecolor='k')


    plt.show()
if __name__ == '__main__':
    RVMclassification_13_24()