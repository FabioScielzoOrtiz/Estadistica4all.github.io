#  -----------------------------------------------------------------
#  MATLAB code for Exercise 7.19
#  Bayesian Classification
#  Python3 required packages: numpy, math, functools, matplotlib
#  -----------------------------------------------------------------

import numpy as np
import math
from functools import reduce
from matplotlib import pyplot as plt


def classification_7_19():
    np.random.seed(0)
    # Definition of mu's and Sigma
    # Mean vectors and covariance matrix
    m1 = np.array([[0], [0]])
    m2 = np.array([[2], [2]])
    S = np.array([[1, .25], [.25, 1]])
    # Number of data points
    n_points_per_class = 500

    # (i) Data point generation
    X = np.concatenate((np.random.multivariate_normal(m1.flatten().conj().T, S, n_points_per_class),
                        np.random.multivariate_normal(m2.flatten().conj().T, S, n_points_per_class)), axis=0).conj().T

    label = np.concatenate((np.ones((1, n_points_per_class)),
                            2 * np.ones((1, n_points_per_class))), axis=1)
    [l, p] = X.shape
    # Plot the data set
    plt.figure(1)
    plt.plot(X[0, np.nonzero(label == 1)], X[1, np.nonzero(label == 1)], '.b')
    plt.plot(X[0, np.nonzero(label == 2)], X[1, np.nonzero(label == 2)], '.r')

    # (ii) Bayes classification of X
    # Estimation of a priori probabilities
    P1 = n_points_per_class/p
    P2 = P1
    p1 = np.zeros(p)
    p2 = np.zeros(p)
    # Estimation of pdf's for each data point
    for i in range(0, p):  # =1:p
        p1[i] = (1/(2*np.pi*np.sqrt(np.linalg.det(S)))) *\
                math.exp(reduce(np.dot, [-(np.array(X[:, i], ndmin=2).conj().T - m1).conj().T, np.linalg.inv(S),
                                         (np.array(X[:, i], ndmin=2).conj().T - m1)]))
        p2[i] = (1/(2*np.pi*np.sqrt(np.linalg.det(S)))) *\
                math.exp(reduce(np.dot, [-(np.array(X[:, i], ndmin=2).conj().T - m2).conj().T, np.linalg.inv(S),
                                         (np.array(X[:, i], ndmin=2).conj().T-m2)]))

    # Classification of the data points
    classes = np.zeros(p)
    for i in range(0, p):  # =1:p
        if P1*p1[i] > P2*p2[i]:
            classes[i] = 1
        else:
            classes[i] = 2

    # (iii) Error probability estimation
    Pe = 0  # Probability of error
    for i in range(0, p):  # =1:p
        if classes[i] != label[0][i]:
            Pe += 1

    Pe /= p
    print('Pe: %f' % Pe)

    # Plot the data set
    plt.figure(2)
    plt.plot(X[0, np.nonzero(classes == 1)], X[1, np.nonzero(classes == 1)], '.b')
    plt.plot(X[0, np.nonzero(classes == 2)], X[1, np.nonzero(classes == 2)], '.r')

    # Definition of the loss matrix
    L = np.array([[0, 1], [.005, 0]])

    # (iv) Classification of data points according to the average risk
    # minimization rule
    # Estimation of pdf's for each data point
    for i in range(0, p):  # =1:p
        p1[i] = (1 / (2 * np.pi * np.sqrt(np.linalg.det(S)))) * \
                math.exp(reduce(np.dot, [-(np.array(X[:, i], ndmin=2).conj().T - m1).conj().T, np.linalg.inv(S),
                                         (np.array(X[:, i], ndmin=2).conj().T - m1)]))
        p2[i] = (1 / (2 * np.pi * np.sqrt(np.linalg.det(S)))) * \
                math.exp(reduce(np.dot, [-(np.array(X[:, i], ndmin=2).conj().T - m2).conj().T, np.linalg.inv(S),
                                         (np.array(X[:, i], ndmin=2).conj().T - m2)]))

    # Classification of the data points
    classes_loss = np.zeros(p)
    for i in range(0, p):  # =1:p
        if L[0][1] * P1 * p1[i] > L[1][0] * P2 * p2[i]:
            classes_loss[i] = 1
        else:
            classes_loss[i] = 2

    # (v) Error probability estimation
    Ar = 0  # Average risk
    for i in range(0, p):  # =1:p
        if classes_loss[i] != label[0][i]:
            if label[0][i] == 1:
                Ar = Ar + L[0, 1]
            else:
                Ar = Ar + L[1, 0]
    Ar /= p
    print('Ar: %f' % Ar)

    # Plot the data set
    plt.figure(3)
    plt.plot(X[0, np.nonzero(classes_loss == 1)], X[1, np.nonzero(classes_loss == 1)], '.b')
    plt.plot(X[0, np.nonzero(classes_loss == 2)], X[1, np.nonzero(classes_loss == 2)], '.r')

    plt.show()


if __name__ == '__main__':
    classification_7_19()


# The average risk minimization rule leads to smaller value of the average risk compared to the
# probability of error obtained by the classic Bayes classification rule.
# In the former case the classification rule decides for almost all the
# overapping region between the two classes, in favor of \omega_1. This is
# due to the fact that a classification error on data steming from \omega_2 is ``cheap'',
# compared to an opposite classification error.

