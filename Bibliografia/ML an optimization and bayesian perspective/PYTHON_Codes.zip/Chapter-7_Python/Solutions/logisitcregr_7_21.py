#  -----------------------------------------------------------------
#  MATLAB code for Exercise 7.21
#  Logistic Regression
#  Python3 required packages: numpy, math, functools, matplotlib
#  -----------------------------------------------------------------

import numpy as np
import math
from functools import reduce
from matplotlib import pyplot as plt

def logisitcregr_7_21():
    np.random.seed(0)

    # Definition of mu's and Sigma
    # Mean vectors and covariance matrix
    m1 = np.array([[0], [2]])
    m2 = np.array([[0], [0]])
    S1 = np.array([[4, 1.8], [1.8, 1]])
    S2 = np.array([[4, -1.8], [-1.8, 1]])

    # Number of data points
    n_points_per_class = 1500

    # (i) Data point generation
    # Training set
    X = np.concatenate((np.random.multivariate_normal(m1.flatten().conj().T, S1, n_points_per_class),
                        np.random.multivariate_normal(m2.flatten().conj().T, S2, n_points_per_class)), axis=0).conj().T

    y = np.concatenate((0 * np.ones((1, n_points_per_class)),
                            1 * np.ones((1, n_points_per_class))), axis=1)
    [l, p] = X.shape
    # Plot the data set
    plt.figure(1)
    plt.plot(X[0, np.nonzero(y == 0)], X[1, np.nonzero(y == 0)], '.b')
    plt.plot(X[0, np.nonzero(y == 1)], X[1, np.nonzero(y == 1)], '.r')

    # Test set
    X_test = np.concatenate((np.random.multivariate_normal(m1.flatten().conj().T, S1, n_points_per_class),
                        np.random.multivariate_normal(m2.flatten().conj().T, S2, n_points_per_class)), axis=0).conj().T

    y_test = np.concatenate((0 * np.ones((1, n_points_per_class)),
                        1 * np.ones((1, n_points_per_class))), axis=1)
    [l, p] = X_test.shape
    # Plot the data set
    plt.figure(2)
    plt.plot(X_test[0, np.nonzero(y_test == 0)], X_test[1, np.nonzero(y_test == 0)], '.b')
    plt.plot(X_test[0, np.nonzero(y_test == 1)], X_test[1, np.nonzero(y_test == 1)], '.r')

    # (ii) Bayes classification of X_test
    # Estimation of a priori probabilities
    P1 = n_points_per_class / p
    P2 = P1
    p1 = np.zeros(p)
    p2 = np.zeros(p)
    # Estimation of pdf's for each data point
    for i in range(0, p):  # =1:p
        p1[i] = (1 / (2 * np.pi * np.sqrt(np.linalg.det(S1)))) * \
                math.exp(reduce(np.dot, [-(np.array(X_test[:, i], ndmin=2).conj().T - m1).conj().T, np.linalg.inv(S1),
                                         (np.array(X_test[:, i], ndmin=2).conj().T - m1)]))
        p2[i] = (1 / (2 * np.pi * np.sqrt(np.linalg.det(S2)))) * \
                math.exp(reduce(np.dot, [-(np.array(X_test[:, i], ndmin=2).conj().T - m2).conj().T, np.linalg.inv(S2),
                                         (np.array(X_test[:, i], ndmin=2).conj().T - m2)]))

    # Classification of the data points
    classes_test = np.zeros(p)
    for i in range(0, p):  # =1:p
        if P1 * p1[i] > P2 * p2[i]:
            classes_test[i] = 0
        else:
            classes_test[i] = 1

    # (iii) Error probability estimation
    Pe = 0  # Probability of error
    for i in range(0, p):  # =1:p
        if classes_test[i] != y_test[0][i]:
            Pe += 1

    Pe /= p
    print('Pe: %f' % Pe)

    # (iii) Applying logistic regression, using a gradient descent scheme
    X = np.concatenate((X, np.ones((1, p))), axis=0)
    [l, p] = X.shape

    X_test = np.concatenate((X_test, np.ones((1, p))), axis=0)
    [l, p_test] = X_test.shape

    rho = 0.001

    theta_ini = np.array([-2, -1, 1]).conj().T  # rand(l,1)
    theta = theta_ini
    e_thres = 10e-4  # threshold for the termination of the algorithm
    iter =0   # Iteration counter
    e = 1  # The difference between the previous and the current estimate of theta
    while e>e_thres:
        iter +=1  # Increment the iteration counter
        theta_old = theta  # Store the current theta
        s = 1 / (1+np.exp(-np.dot(theta.conj().T, X))) # Computation of the vector 's\'
        theta = theta - rho * np.dot(X, (s-y).conj().T)  # Updating of the vector 'theta'
        e = np.sum(np.abs(theta-theta_old))  # Absolute difference between the current and the previous values of 'theta'

    # Evaluating the performance of the logistic regression
    s_test = 1 / (1+np.exp(-np.dot(theta.conj().T, X_test)))
    Pe_log = 0
    for i in range(0, p_test):
        if ((s_test[0][i] > 0.5) & (y_test[0][i] != 1)) | ((s_test[0][i] < 0.5) & (y_test[0][i] != 0)):
            Pe_log += 1

    Pe_log /= p_test
    print('Pe_log: %f' % Pe_log)

    plt.show()


if __name__ == '__main__':
    logisitcregr_7_21()

