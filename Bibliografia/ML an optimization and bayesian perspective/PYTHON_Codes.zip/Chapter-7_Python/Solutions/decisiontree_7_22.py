#  -----------------------------------------------------------------
#  MATLAB code for Exercise 7.22
#  Decision Trees
#  Python3 required packages: numpy, matplotlib, scikit-learn
#  -----------------------------------------------------------------


import numpy as np
import os
import sys
from matplotlib import pyplot as plt
sys.path.append(os.getcwd())
sys.path.append('../')
from sklearn import tree
from PYTHON_7.help import view_tree


def decisiontree_7_22():
    # Generating the training date set
    np.random.seed(0)
    m11 = np.array([[0], [3]])
    m12 = np.array([[11], [-2]])
    m21 = np.array([[3], [-2]])
    m22 = np.array([[7.5], [4]])
    m3 = np.array([[7], [2]])
    S11 = np.array([[0.2, 0], [0, 2]])
    S12 = np.array([[3, 0], [0, 0.5]])
    S21 = np.array([[5, 0], [0, 0.5]])
    S22 = np.array([[7, 0], [0, 0.5]])
    S3 = np.array([[8, 0], [0, 0.5]])
    n_of_points_per_group = 500

    X = np.concatenate((np.random.multivariate_normal(m11.flatten().conj().T, S11, n_of_points_per_group),
                        np.random.multivariate_normal(m12.flatten().conj().T, S12, n_of_points_per_group),
                        np.random.multivariate_normal(m21.flatten().conj().T, S21, n_of_points_per_group),
                        np.random.multivariate_normal(m22.flatten().conj().T, S22, n_of_points_per_group),
                        np.random.multivariate_normal(m3.flatten().conj().T, S3, n_of_points_per_group)),
                       axis=0).conj().T

    label = np.concatenate((np.ones((1, n_of_points_per_group)),
                           np.ones((1, n_of_points_per_group)),
                           2 * np.ones((1, n_of_points_per_group)),
                           2 * np.ones((1, n_of_points_per_group)),
                           3 * np.ones((1, n_of_points_per_group))), axis=1)

    [l, p] = X.shape

    # Plot the training data set
    plt.figure(1)
    plt.plot(X[0, np.nonzero(label == 1)], X[1, np.nonzero(label == 1)], '.b')
    plt.plot(X[0, np.nonzero(label == 2)], X[1, np.nonzero(label == 2)], '.r')
    plt.plot(X[0, np.nonzero(label == 3)], X[1, np.nonzero(label == 3)], '.g')

    # Generating the training date set
    np.random.seed(100)
    n_of_points_per_group = 500

    X_test = np.concatenate((np.random.multivariate_normal(m11.flatten().conj().T, S11, n_of_points_per_group),
                             np.random.multivariate_normal(m12.flatten().conj().T, S12, n_of_points_per_group),
                             np.random.multivariate_normal(m21.flatten().conj().T, S21, n_of_points_per_group),
                             np.random.multivariate_normal(m22.flatten().conj().T, S22, n_of_points_per_group),
                             np.random.multivariate_normal(m3.flatten().conj().T, S3, n_of_points_per_group)),
                            axis=0).conj().T

    label_test = np.concatenate((np.ones((1, n_of_points_per_group)),
                            np.ones((1, n_of_points_per_group)),
                            2 * np.ones((1, n_of_points_per_group)),
                            2 * np.ones((1, n_of_points_per_group)),
                            3 * np.ones((1, n_of_points_per_group))), axis=1)

    [l, p] = X_test.shape

    # Plot the test data set
    plt.figure(2)
    plt.plot(X_test[0, np.nonzero(label_test == 1)], X_test[1, np.nonzero(label_test == 1)], '.b')
    plt.plot(X_test[0, np.nonzero(label_test == 2)], X_test[1, np.nonzero(label_test == 2)], '.r')
    plt.plot(X_test[0, np.nonzero(label_test == 3)], X_test[1, np.nonzero(label_test == 3)], '.g')

    ordinal = lambda n: "%d%s" % (n, "tsnrhtdd"[(n / 10 % 10 != 1) * (n % 10 < 4) * n % 10::4])

    y = np.array(label, dtype=np.str)
    for i in range(0, label.shape[1]):
        y[0][i] = ordinal(int(label[0][i]))

    y_test = np.array(label_test, dtype=np.str)
    for i in range(0, label_test.shape[1]):
        y_test[0][i] = ordinal(int(label_test[0][i]))


    t = tree.DecisionTreeClassifier()
    t.fit(X.conj().T, y.flatten())
    label_tree = t.predict(X.conj().T)
    view_tree(t)

    Pe = np.zeros(shape=(20, 1))
    for k in range(0, 20):  # =0:1:20
        if k == 0:
            t2 = t  # no pruning
        else:
            # TODO: prune t at depth k!
            t2 = tree.DecisionTreeClassifier(max_depth=k)  # Cut the decision tree at level k
            t2.fit(X.conj().T, y.flatten())
        label_tree = t2.predict(X_test.conj().T)  # Evaluating the performance of the decision tree

        # Computation of the probability of error
        Pe[k] = 1-t2.score(X_test.conj().T, y_test.flatten())

    plt.figure(4)
    plt.plot(range(0, 20), Pe)

    plt.show()



if __name__ == '__main__':
    decisiontree_7_22()


