# This is for theodoridis book. Boosting example FOR THE TEXT

#  Python3 required packages: numpy, math, functools, matplotlib, sklearn

import numpy as np
import math
from matplotlib import pyplot as plt
from sklearn.ensemble import AdaBoostClassifier
from sklearn.metrics import zero_one_loss
from sklearn.tree import DecisionTreeClassifier



def boostingexample_7_5():
    # Generating the training date set
    np.random.seed(0)
    l = 20
    m11 = np.concatenate((0*np.ones((1, int(l/2))), 0*np.ones((1, int(l/2)))), axis=1).conj().T
    m12 = np.concatenate((1*np.ones((1, int(l/2))), 1*np.ones((1, int(l/2)))), axis=1).conj().T
    m21 = np.concatenate((0*np.ones((1, int(l/2))), 1*np.ones((1, int(l/2)))), axis=1).conj().T
    m22 = np.concatenate((3*np.ones((1, int(l/2))), 0*np.ones((1, int(l/2)))), axis=1).conj().T

    S11 = 1*np.eye(l)
    S12 = 1*np.eye(l)
    S21 = 1*np.eye(l)
    n_of_points_per_group = 100

    X = np.concatenate((np.random.multivariate_normal(m11.flatten().conj().T, S11, n_of_points_per_group),
                       np.random.multivariate_normal(m12.flatten().conj().T, S12, n_of_points_per_group),
                       np.random.multivariate_normal(m21.flatten().conj().T, S21, n_of_points_per_group)), axis=0).conj().T

    label = np.concatenate((np.ones((1,n_of_points_per_group)),
                            np.ones((1,n_of_points_per_group)),
                            2*np.ones((1, n_of_points_per_group))), axis=1)
    l = X.shape[0]
    p = X.shape[1]


    # Plot the training data set
    # plt.figure(1)
    # plt.plot(X[0, np.nonzero(label == 1)], X[1, np.nonzero(label == 1)],'.b')
    # plt.plot(X[0, np.nonzero(label == 2)], X[1, np.nonzero(label == 2)],'.r')


    # Generating the training date set
    np.random.seed(100)
    n_of_points_per_group = 100

    X_test = np.concatenate((np.random.multivariate_normal(m11.flatten().conj().T, S11, n_of_points_per_group),
                            np.random.multivariate_normal(m12.flatten().conj().T, S12, n_of_points_per_group),
                            np.random.multivariate_normal(m21.flatten().conj().T, S21, n_of_points_per_group)),
                            axis=0).conj().T

    label_test = np.concatenate((np.ones((1,n_of_points_per_group)),
                            np.ones((1,n_of_points_per_group)),
                            2*np.ones((1, n_of_points_per_group))), axis=1)

    l = X.shape[0]
    p = X.shape[1]

    # Plot the test data set
    # plt.figure(2)
    # plt.plot(X_test[0, np.nonzero(label == 1)], X_test[1, np.nonzero(label == 1)],'.b')
    # plt.plot(X_test[0, np.nonzero(label == 2)], X_test[1, np.nonzero(label == 2)],'.r')
    # plt.show()
    ordinal = lambda n: "%d%s" % (n, "tsnrhtdd"[(math.floor(n / 10) % 10 != 1) * (n % 10 < 4) * n % 10::4])

    y = []
    for i in range(0, label.shape[1]):
        y.append(ordinal(int(label[0,i])))  # Converting the 'label' to ordinal values
    y = np.reshape(np.asarray(y), newshape=label.shape)

    y_test = []
    for i in range(0, label_test.shape[1]):
        y_test.append(ordinal(int(label_test[0, i])))  # Converting the 'label_test' to ordinal values
    y_test = np.reshape(np.asarray(y_test), newshape=label_test.shape)

    no_of_base_classifiers = 2000

    clf = AdaBoostClassifier(base_estimator=DecisionTreeClassifier(max_depth=1),
                             n_estimators=no_of_base_classifiers,
                             algorithm='SAMME')

    clf.fit(X=X.conj().T, y=y.flatten())
    print(clf.get_params())

    L = np.zeros((no_of_base_classifiers,))
    for i, y_pred in enumerate(clf.staged_predict(X.conj().T)):
        L[i] = zero_one_loss(y.flatten(), y_pred)

    L_test = np.zeros((no_of_base_classifiers,))
    for i, y_pred in enumerate(clf.staged_predict(X_test.conj().T)):
        L_test[i] = zero_one_loss(y_test.flatten(), y_pred)

    plt.figure(3)
    plt.plot(range(1, no_of_base_classifiers+1), L, 'r', linewidth=0.5)
    plt.plot(range(1, no_of_base_classifiers+1), L_test, 'b', linewidth=0.5)
    plt.xlabel('Number of base classifiers')
    plt.ylabel('Error')
    # plt.ylim(0)
    # plt.xlim(0)


    plt.show()


if __name__ == '__main__':
    boostingexample_7_5()
