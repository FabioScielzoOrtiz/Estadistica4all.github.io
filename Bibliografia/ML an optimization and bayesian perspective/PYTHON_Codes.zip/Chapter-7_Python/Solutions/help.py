from matplotlib import pyplot as plt
from subprocess import call
from sklearn import tree

def view_tree(dtree):
    def zoom_factory(ax, base_scale=1.1):
        def zoom_fun(event):
            if not event.inaxes:
                return
            # get the current x and y limits
            cur_xlim = ax.get_xlim()
            cur_ylim = ax.get_ylim()
            # print(cur_xlim, cur_ylim)
            cur_xrange = (cur_xlim[1] - cur_xlim[0]) * .5
            cur_yrange = (cur_ylim[1] - cur_ylim[0]) * .5
            xdata = event.xdata  # get event x location
            ydata = event.ydata  # get event y location
            if event.button == 'up':
                # deal with zoom in
                scale_factor = 1 / base_scale
            elif event.button == 'down':
                # deal with zoom out
                scale_factor = base_scale
            else:
                # deal with something that should never happen
                scale_factor = 1

            x_left = xdata - cur_xlim[0]
            x_right = cur_xlim[1] - xdata
            y_top = ydata - cur_ylim[0]
            y_bottom = cur_ylim[1] - ydata

            ax.set_xlim([xdata - x_left * scale_factor,
                         xdata + x_right * scale_factor])
            ax.set_ylim([ydata - y_top * scale_factor,
                         ydata + y_bottom * scale_factor])

            plt.draw()  # force re-draw

        fig = ax.get_figure()  # get the figure of interest
        # attach the call back
        fig.canvas.mpl_connect('scroll_event', zoom_fun)

        # return the function
        return zoom_fun

    with open("./dtree.dot", 'w') as dotfile:
        tree.export_graphviz(dtree, out_file=dotfile)
        dotfile.close()

    call(['dot', '-Tpng', './dtree.dot', '-o', './dtree.png', '-Gdpi=100'])

    fig, ax = plt.subplots(nrows=1)
    zoom_factory(ax, base_scale=1.1)
    plt.imshow(plt.imread('./dtree.png'))
    # plt.show()