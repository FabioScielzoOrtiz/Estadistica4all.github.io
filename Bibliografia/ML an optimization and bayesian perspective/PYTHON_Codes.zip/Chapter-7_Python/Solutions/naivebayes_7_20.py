#  -----------------------------------------------------------------
#  MATLAB code for Exercise 7.20
#  Naive Bayes Classifier
#  Python3 required packages: numpy, math, functools, matplotlib
#  -----------------------------------------------------------------

import numpy as np
import math
from functools import reduce
from matplotlib import pyplot as plt


def naivebayes_7_20():
    np.random.seed(0)
    # Definition of mu's and Sigma
    # Mean vectors and covariance matrix
    m1 = np.array([[0], [2]])
    m2 = np.array([[0], [0]])
    S1 = np.array([[4, 0], [0, 1]])
    S2 = np.array([[4, 0], [0, 1]])
    # S1 = np.array([[4, 1.8], [1.8, 1]])
    # S2 = np.array([[4, 1.2], [1.2, 1]])

    # Number of data points
    n_points_per_class = 5000

    # (i) Data point generation
    X = np.concatenate((np.random.multivariate_normal(m1.flatten().conj().T, S1, n_points_per_class),
                        np.random.multivariate_normal(m2.flatten().conj().T, S2, n_points_per_class)), axis=0).conj().T

    label = np.concatenate((np.ones((1, n_points_per_class)),
                            2 * np.ones((1, n_points_per_class))), axis=1)
    [l, p] = X.shape
    # Plot the data set
    plt.figure(1)
    plt.plot(X[0, np.nonzero(label == 1)], X[1, np.nonzero(label == 1)], '.b')
    plt.plot(X[0, np.nonzero(label == 2)], X[1, np.nonzero(label == 2)], '.r')

    # (ii) Bayes classification of X
    # Estimation of a priori probabilities
    P1 = n_points_per_class / p
    P2 = P1
    p1 = np.zeros(p)
    p2 = np.zeros(p)
    # Estimation of pdf's for each data point
    for i in range(0, p):  # =1:p
        p1[i] = (1 / (2 * np.pi * np.sqrt(np.linalg.det(S1)))) * \
                math.exp(reduce(np.dot, [-(np.array(X[:, i], ndmin=2).conj().T - m1).conj().T, np.linalg.inv(S1),
                                         (np.array(X[:, i], ndmin=2).conj().T - m1)]))
        p2[i] = (1 / (2 * np.pi * np.sqrt(np.linalg.det(S2)))) * \
                math.exp(reduce(np.dot, [-(np.array(X[:, i], ndmin=2).conj().T - m2).conj().T, np.linalg.inv(S2),
                                         (np.array(X[:, i], ndmin=2).conj().T - m2)]))

    # Classification of the data points
    classes = np.zeros(p)
    for i in range(0, p):  # =1:p
        if P1 * p1[i] > P2 * p2[i]:
            classes[i] = 1
        else:
            classes[i] = 2

    # (iii) Error probability estimation
    Pe = 0  # Probability of error
    for i in range(0, p):  # =1:p
        if classes[i] != label[0][i]:
            Pe += 1

    Pe /= p
    print('Pe: %f' % Pe)

    # Plot the data set
    plt.figure(2)
    plt.plot(X[0, np.nonzero(classes == 1)], X[1, np.nonzero(classes == 1)], '.b')
    plt.plot(X[0, np.nonzero(classes == 2)], X[1, np.nonzero(classes == 2)], '.r')

    # (iv) Estimation of pdf's for each data point
    p1_naive = np.zeros(p)
    p2_naive = np.zeros(p)
    for i in range(0, p):
        p1_naive[i] = ((1 / (np.sqrt(2 * np.pi * S1[0, 0]))) *
                       math.exp(-np.dot((X[0, i] - m1[0]).conj().T, (X[0, i] - m1[0])) / (2 * S1[0, 0]))) * \
                      ((1 / (np.sqrt(2 * np.pi * S1[1, 1]))) *
                       math.exp(-np.dot((X[1, i] - m1[1]).conj().T, (X[1, i] - m1[1])) / (2 * S1[1, 1])))
        p2_naive[i] = ((1 / (np.sqrt(2 * np.pi * S2[0, 0]))) *
                       math.exp(-np.dot((X[0, i] - m2[0]).conj().T, (X[0, i] - m2[0])) / (2 * S2[0, 0]))) * \
                      ((1 / (np.sqrt(2 * np.pi * S2[1, 1]))) *
                       math.exp(-np.dot((X[1, i] - m2[1]).conj().T, (X[1, i] - m2[1])) / (2 * S2[1, 1])))


    # Classification of the data points
    class_naive = np.zeros(p)
    for i in range(0, p):
        if P1 * p1_naive[i] > P2*p2_naive[i]:
            class_naive[i] = 1
        else:
            class_naive[i] = 2

    # (v) Error probability estimation
    Pe_naive = 0  # Probability of error
    for i in range(0, p):
        if class_naive[i] != label[0][i]:
            Pe_naive = Pe_naive + 1

    Pe_naive /= p
    print('Pe_naive: %f' % Pe_naive)

    # Plot the data set
    plt.figure(3)
    plt.plot(X[0, np.nonzero(class_naive == 1)], X[1, np.nonzero(class_naive == 1)], '.b')
    plt.plot(X[0, np.nonzero(class_naive == 2)], X[1, np.nonzero(class_naive == 2)], '.r')

    plt.show()


if __name__ == '__main__':
    naivebayes_7_20()
