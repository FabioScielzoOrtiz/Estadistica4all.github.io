import numpy as np
import sys
from skimage.util import view_as_windows as viewW


def py_dctmtx(size):
    """
    Calculate the square DCT transform matrix. Results are
    equivalent to Matlab dctmtx(n) with 64 bit precision.
    """

    DCTmx = np.array(range(size), np.float64).repeat(size).reshape(size, size)
    DCTmxT = np.pi * (DCTmx.transpose()+0.5) / size
    DCTmxT = (1.0/np.sqrt(size / 2.0)) * np.cos(DCTmx * DCTmxT)
    DCTmxT[0] = DCTmxT[0] * (np.sqrt(2.0)/2.0)
    return DCTmxT



def OMP(X, y, k):
    theta =None
    residual = y
    S = np.zeros((k, 1))
    normx = np.array(np.sqrt(np.sum(X ** 2, axis=0)).conj().T, ndmin=2).conj().T
    for i in range(0, k):
        proj = X.conj().T @ residual
        proj = proj / normx
        pos = np.argmax(np.abs(proj))
        S[i] = pos
        indices = np.array(S[0:(i + 1)][:], dtype=np.int).flatten()
        theta_ = np.linalg.pinv(np.array(X[:, indices], ndmin=2)) @ y
        theta = np.zeros((X.shape[1], 1))

        theta[indices] = np.reshape(theta_, newshape=(theta_.shape[0],1))
        residual = y - X @ theta

        # residual=y-X(:,indx(1:i))*theta_; %a faster implementation
        # theta = zeros(size(X,2),1);
        # theta(indx) = theta_;
    return theta