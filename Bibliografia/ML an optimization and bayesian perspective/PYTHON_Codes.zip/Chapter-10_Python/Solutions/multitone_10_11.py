# -------------------------------------------------------------------------
# Exercise 10.11
# Python3 required packages: numpy, matplotlib, scikit-learn, scipy
# -------------------------------------------------------------------------


import numpy as np
from scipy.fftpack import dct, idct
import math
from matplotlib import pyplot as plt
from sklearn.linear_model import Lasso, LassoLars
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_10.help import OMP, py_dctmtx


def multitone_10_11():
    """
    You can use LassoLars solver

    However, to facilitate the demonstration of this test, a sparse coding algorithm (the OMP that you are asked to
    develope in excercise 10_12) is included at the end of this .m file.
    """

    # signal length
    l = 2**8

    # number of nonzero frequency components
    k = 3

    # number of observations to make
    N = 30


    posK = np.array([4,10,30])

    a = np.array([0.3, 1, 0.75])

    n = np.array(range(0, l))
    n = np.reshape(n, newshape=(1, n.shape[0]))
    theta = np.zeros(shape=(l, 1))

    # Construct the multitone signal
    for i in range(0, k):
       theta += a[i]*np.cos((np.pi*(2*posK[i]-1)*n.conj().transpose())/(2*l))

    # question (a)

    X = idct(theta, norm='ortho', axis=0)

    # Instead of using idct, you can work with the DCT matrix as follows
    # Phi = py_dctmtx(l);
    # X = np.dot(Phi.conj().transpose(), theta)

    plt.figure(1)
    plt.subplot(1, 2, 1)
    plt.plot(theta)
    plt.title('Signal')
    plt.subplot(1, 2, 2)
    plt.stem(X, basefmt=' ')
    plt.title('DCT domain')

    # Question (b)
    # Construct the sensing matrix with variance N(0,1/N)
    A = np.random.randn(N, l)*math.sqrt(1/N)
    y = A @ theta

    # Since it is sparse in the IDCT domain, i.e. A*theta = A*Phi*X = AF*X,
    # where X sparse,  AF = A*Phi and Phi is the DCT matrix, Phi = dctmtx(l);.
    # Equivalently, using idct (for faster computation than with the DCT matrix), AF is computed as:
    AF = idct(A.conj().transpose(), norm='ortho', axis=0).conj().transpose()

    solsA = OMP(AF, y, 3)
    # Take the IDCT (i.e. the DCT) in order to compute the estimated signal.
    theta_hat = dct(solsA, norm='ortho', axis=0)

    plt.figure(2)
    plt.subplot(1,2,1)
    plt.plot(theta)
    plt.title('Original')
    plt.subplot(1,2,2)
    plt.plot(theta_hat)
    plt.title('Estimated (random sensing matrix)')

    # Construct the sensing matrix of question (c)
    # Question (c)
    positions = np.random.choice(l, N, replace=False)
    B = np.zeros(shape=(N, l))
    for i in range(0, N):
        B[i, positions[i]] = 1

    y = B @ theta

    plt.figure(3)
    plt.plot(theta)
    plt.plot(positions, y, 'r.')
    plt.title('Samples taken')

    # Since it is sparse in the IDCT domain, i.e. B*theta = B*Phi*X = BF*X,
    # where X sparse,  BF = B*Phi; and Phi is the DCT matrix, Phi = dctmtx(l);.
    # Equivalently, using idct (for faster computation than with the DCT matrix), AF is computed as:
    BF = idct(B.conj().transpose(), norm='ortho', axis=0).conj().transpose()

    # Use LassoLars
    # solsB = LassoLars(alpha=0.0005, fit_intercept=False, normalize=False,  max_iter=1e6).fit(BF, y).coef_
    # or
    # use OMP.m with the sparsity level, i.e. 3, given as input.
    solsB = OMP(BF, y, 3)

    # Take the inverse IDCT (i.e. the DCT) in order to compute the estimated signal.
    theta_hat = dct(solsB, norm='ortho', axis=0)

    plt.figure(4)
    plt.subplot(1, 2, 1)
    plt.plot(theta)
    plt.title('Original')
    plt.subplot(1, 2, 2)
    plt.plot(theta_hat)
    plt.title('Estimated (using randomly picked samples)')

    plt.show()


if __name__ == '__main__':

    multitone_10_11()