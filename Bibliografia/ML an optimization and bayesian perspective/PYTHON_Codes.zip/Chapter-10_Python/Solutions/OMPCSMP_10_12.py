# -----------------------------------------------------------------
# Exercise 10.12
# Implements the OMP and CSMP algorithms.
# Python3 required packages: numpy, matplotlib
# -----------------------------------------------------------------

import numpy as np
from matplotlib import pyplot as plt
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')


def omp_csmp_10_12():
    # Chooze a fixed signal length.
    l = 100

    alpha = 0.2  # set alpha equal to 0.8 for question (b)
    N = round(alpha * l)
    error = np.zeros(shape=(2, 10))
    beta = np.array(range(1, 11)) / 10  # 0.1:0.1:1;

    X = np.random.randn(N, l) * np.sqrt(1/N)
    for count in range(0, 10):
        k = int(np.round(beta[count]*N))
        t = 2 * k

        # Make the unknown sparse vector
        theta = np.zeros(shape=(l, 1))
        theta[np.random.choice(l, k, replace=False)] = np.random.randn(k, 1)

        y = np.dot(X, theta)

        #  Uncomment the next 4 lines in order to add some noise (question (c))
        #  SNR = 20
        #  varnoise = (k/N)/(10 ** (SNR/10))
        #  noise = np.random.randn(y.shape[0], y.shape[1]) * np.sqrt(varnoise)
        #  y = y + noise

        # Run OMP
        theta_OMP = OMP(X, y, k)
        error[0, count] = np.linalg.norm(theta - theta_OMP)

        # Run CSMP
        theta_CSMP = CSMP(X, y, k, t)
        error[1, count] = np.linalg.norm(theta - theta_CSMP)

    plt.figure(1)
    plt.plot(beta, error[0, :], label='OMP')
    plt.plot(beta, error[1, :], label='CSMP')
    plt.legend(loc='upper right')
    plt.show()


def CSMP(X, y, k, t):

    l = X.shape[1]
    if t > l: # check if t is larger than l
        t = l

    theta = np.zeros(shape=(l, 1))
    residual = y
    # normx = sqrt(sum(X.^2,1))';
    for i in range(0, 20):
        b1 = theta.ravel().nonzero()[0]
        b1 = np.reshape(b1, newshape=(b1.shape[0], 1))
        proxy = np.dot(X.conj().T, residual)
        b2 = np.sort(np.abs(proxy))

        S = np.unique(np.vstack(np.vstack((b1, b2[0:t]))))

        theta_ = np.dot(np.linalg.pinv(np.array(X[:, np.array(S, dtype=np.int).flatten()], ndmin=2)), y)

        theta = np.zeros(shape=(X.shape[1], 1))
        theta[np.array(S, dtype=np.int).flatten()] = theta_
        b = np.sort(np.abs(theta))
        theta[np.array(b[k+1:], dtype=np.int)] = 0
        residual = y - np.dot(X, theta)

    return theta


def OMP(X, y, k):
    theta =None
    residual = y
    S = np.zeros((k, 1))
    normx = np.array(np.sqrt(np.sum(X ** 2, axis=0)).conj().T, ndmin=2).conj().T
    for i in range(0, k):
        proj = X.conj().T @ residual
        proj = proj / normx
        pos = np.argmax(np.abs(proj))
        S[i] = pos
        indices = np.array(S[0:(i + 1)][:], dtype=np.int).flatten()
        theta_ = np.linalg.pinv(np.array(X[:, indices], ndmin=2)) @ y
        theta = np.zeros((X.shape[1], 1))

        theta[indices] = np.reshape(theta_, newshape=(theta_.shape[0],1))
        residual = y - X @ theta

        # residual=y-X(:,indx(1:i))*theta_; %a faster implementation
        # theta = zeros(size(X,2),1);
        # theta(indx) = theta_;
    return theta

if __name__ == '__main__':

    omp_csmp_10_12()
