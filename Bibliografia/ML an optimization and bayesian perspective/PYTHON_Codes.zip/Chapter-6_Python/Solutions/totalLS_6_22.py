#  -----------------------------------------------------------------
# Exercise 6.22
# This function generates the model and the data and
# runs the Total Least Squares
# and the Least Squares algorithms.
# Python3 required packages: numpy, scipy
# -----------------------------------------------------------------

import os
import sys
import numpy as np
from scipy import linalg
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_6.help import tls


def totalLS_6_22():
    N = 150  # Number of observations
    l = 90  # problem size
    sv = 0.01  # Variance of the additive noise
    sv2 = 0.2
    Iter = 100

    #sx = sv.shape

    t1 = np.zeros((l, 1))
    t2 = np.zeros((l, 1))
    t3 = np.zeros((l, 1))
    t4 = np.zeros((l, 1))
    theta = np.random.randn(l,1)

    for i in range(0, Iter):  #=1:Iter
        A = np.random.randn(N, l)
        noise = np.sqrt(sv) * np.random.randn(N, 1)
        y = np.dot(A, theta)

        y1 = y + noise
        A1 = A
        that = np.dot(np.linalg.inv(np.dot(A1.conj().T, A1)), np.dot(A1.conj().T, y1))
        t1 = t1 + that

        #########ADD SOME NOISE ON THE INPUT#########
        E = sv2 * np.random.randn(N, l)
        A2 = A + E

        that2 = np.dot(np.linalg.inv(np.dot(A2.conj().T, A2)), np.dot(A2.conj().T, y1)) # Compute the classical Least Squares

        t2 = t2 + that2

        #########TOTAL LEAST SQUARES #########
        Ahatext = np.concatenate((A2, y1), axis=1)
        [U, S, V] = linalg.svd(Ahatext, lapack_driver='gesvd')  # Compute the SVD of the Matrix

        sl1 = min(S[np.nonzero(S != 0)])  # Find the smallest eigenvalue not equal to zero.
        that3 = np.dot(np.linalg.inv(np.dot(A2.conj().T, A2) - (sl1 ** 2)*np.eye(l)),  np.dot(A2.conj().T, y1))
        t3 = t3 + that3

        Ahatext = np.concatenate((A2, y1), axis=1)
        that4 = tls(A2, y1, np.spacing(1))
        t4 = t4 + that4

    print(np.linalg.norm(t1 / Iter - theta))
    print(np.linalg.norm(t2 / Iter - theta))
    print(np.linalg.norm(t3 / Iter - theta))
    print(np.linalg.norm(t4 / Iter - theta))



if __name__ == '__main__':
    totalLS_6_22()

