# -----------------------------------------------------------------
# Exercise 6.20
# This function generates the model, the data and runs the RLS, the NLMS
# and the APA algorithms.
# Python3 required packages: numpy, matplotlib
# -----------------------------------------------------------------

import os
import sys
import numpy as np
from matplotlib import pyplot as plt
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_6.help import py_convmtx


def RLS():
    L = 200  # Dimension of the unknown vector
    N = 3500  # Number of Data
    theta = np.random.randn(L, 1)  # Unknown parameter

    IterNo = 100
    MSE1 = np.zeros((N, IterNo))
    MSE2 = np.zeros((N, IterNo))
    MSE3 = np.zeros((N, IterNo))

    noisevar = 0.01
    epsilon = np.sqrt(2) * noisevar

    X = np.random.randn(L, N)
    inputvec = lambda n: np.array([X[:, n].copy()])  # .conj().T

    noise = np.random.randn(N, 1) * np.sqrt(noisevar)

    y = np.zeros((N, 1))
    y[0:N] = np.dot(X[:, 0:N].conj().T, theta)
    y = y + noise

    for It in range(0, IterNo):  # =1:IterNo
        print('It = %d' % (It+1))
        xcorrel = np.random.randn(N+L-1)  # ,1);
        xcorrel = xcorrel / np.std(xcorrel)

        X = py_convmtx(xcorrel, L)
        X = np.delete(X, (range(0, L - 1)), axis=1)

        inputvec = lambda n: np.array([X[:, n].copy()]).conj().T
        noise = np.random.randn(N, 1) * np.sqrt(noisevar)

        y = np.zeros((N, 1))
        y[0:N] = np.dot(X[:, 0:N].conj().T, theta)
        y = y + noise
        w = np.zeros((L, 1))
        mu = 0.2
        delta = 0.001
        q = 30  # Number of window used for the APA
        for i in range(0, N):
            if i > q:
                qq = range(i, i - q, -1)  # qq=i:-1:i-q+1;

                yvec = y[qq]
                Xq = inputvec(qq)
                Xq = np.reshape(Xq, newshape=(Xq.shape[0], Xq.shape[1]))
                e = yvec - np.dot(Xq, w)
                eins = y[i] - np.dot(w.conj().T, inputvec(i))
                w = w + mu * np.dot(np.dot(Xq.conj().T, np.linalg.inv(delta*np.eye(q)+np.dot(Xq, Xq.conj().T))), e)
                MSE1[i, It] = eins ** 2

        # w = np.zeros((L,1))
        w = np.zeros((L,1))  # RLS recursion
        delta = 0.001
        P = (1/delta) * np.eye(L)
        for i in range(0, N):

            gamma = 1/(1+np.dot(inputvec(i).conj().T, np.dot(P, inputvec(i))))
            gi = np.dot(P, inputvec(i)) * gamma
            e = y[i] - np.dot(w.conj().T, inputvec(i))
            w = w + gi * e
            P = P - np.dot(gi, gi.conj().T)/gamma
            MSE2[i, It] = e ** 2

        w = np.zeros((L, 1))  # NLMS Recursion
        delta = 0.001
        mu = 1.2
        for i in range(0, N):

            # mu=1;%/(i^0.5);
            e = y[i] - np.dot(w.conj().T, inputvec(i))
            mun = mu / (delta+np.dot(inputvec(i).conj().T, inputvec(i)))
            w = w + mun * e * inputvec(i)
            MSE3[i, It] = e ** 2

    MSEav1 = sum(MSE1.conj().T) / IterNo
    MSEav2 = sum(MSE2.conj().T) / IterNo
    MSEav3 = sum(MSE3.conj().T) / IterNo

    plt.plot(10 * np.log10(MSEav1), 'r', lw=0.5)
    plt.plot(10 * np.log10(MSEav2), 'g', lw=0.5)
    plt.plot(10 * np.log10(MSEav3), 'b', lw=0.5)

    plt.show()


if __name__ == '__main__':
    RLS()

