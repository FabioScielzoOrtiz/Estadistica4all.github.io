# -----------------------------------------------------------------
# Exercise 6.21
# Time-varying parameter estimation using the RLS and the
# NLMS.
# Python3 required packages: numpy, matplotlib, functools
# -----------------------------------------------------------------

import numpy as np
from functools import reduce
from matplotlib import pyplot as plt


def RLStrack():

    L = 5  # Dimension of the unknown vector
    N = 1000  # Number of Data
    theta = np.zeros((L, N))  # Unknown parameter

    IterNo = 200

    MSE1 = np.zeros((N, IterNo))
    MSE2 = np.zeros((N, IterNo))

    ara = 0.97
    qqm = 0.1  # Parameters for the time varying channel

    noisevar = 0.001
    epsilon = np.sqrt(2) * noisevar

    for It in range(0, IterNo):
        print('It = %d' % (It+1))

        theta = np.zeros((L, N))
        theta[:, 1] = np.random.randn(L, 1)[:, 0]
        for ii in range(1, N):  # =2:N   # Generate the time varying channel
            theta[:, ii] = ara * theta[:, ii-1] + qqm * np.random.randn(L, 1)[:, 0]

        xcorrel = np.random.randn(N+L-1)  # ,1)
        xcorrel /=  np.std(xcorrel)

        X = np.random.randn(L, N)
        inputvec = lambda n: np.array([X[:, n].copy()]).conj().T
        noise = np.random.randn(N, 1) * np.sqrt(noisevar)

        y = np.zeros((N, 1))

        for ii in range(0, N):  # =1:N

            y[ii] = np.dot(X[:, ii].conj().T, theta[:, ii])

        y = y + noise
        w = np. zeros((L, 1))
        delta = 0.001
        l = 0.995
        P = (1/delta) * np.eye(L)
        for i in range(0, N):  # =1:N
            a = reduce(np.dot, [P, inputvec(i), inputvec(i).conj().T, P])
            b = reduce(np.dot, [inputvec(i).conj().T, P, inputvec(i)])
            P = (1/l) * (P - ((1/l) * a)/(1+(1/l) * b))
            e = y[i] - np.dot(w.conj().T, inputvec(i))
            w = w + np.dot(P, inputvec(i)) * e
            MSE1[i, It] = e ** 2

        w = np.zeros((L, 1))
        delta = 0.001
        mu = 0.5
        for i in range(0, N):
            e = y[i] - np.dot(w.conj().T, inputvec(i))
            mun = mu / (delta + np.dot(inputvec(i).conj().T, inputvec(i)))
            w = w + mun * e * inputvec(i)
            MSE2[i, It] = e ** 2

    MSEav1 = sum(MSE1.conj().T) / IterNo
    MSEav2 = sum(MSE2.conj().T) / IterNo

    plt.plot(10 * np.log10(MSEav1), 'b', lw=0.5)
    plt.plot(10 * np.log10(MSEav2), 'k', lw=0.5)

    plt.show()


if __name__ == '__main__':
    RLStrack()


