# -----------------------------------------------------------------
#  Exercise 17.9
#  SIR particle filtering for various time instances.
# Python3 required packages: numpy, matplotlib
# -----------------------------------------------------------------


import numpy as np
import matplotlib.pyplot as plt

def SIR_17_9():

    # Initialization of Variables
    N = 200  # particle streams
    x = np.zeros(shape=(1, N))
    y = np.zeros(shape=(1, N))

    # State Model
    x[0, 0] = 1
    for i in range(1, N):
        x[0, i] = x[0, i-1]+np.random.randn(1)
        y[0, i] = np.random.randn(1)+x[0, i]

    # Plot of State Model
    plt.figure(1)
    plt.plot(np.array(range(0, N)), x[0, :], 'r')
    plt.plot(np.array(range(0, N)), y[0, :], 'g')

    # Initialize Variables
    par = 200  # Number of Particles
    ParPos = np.zeros(shape=(N, par))  # Positions of Particles
    weights = np.array(ParPos)   # Weights of Particles

    ParPos[0, :] = np.random.randn(1, par)  # Generate random positions for particles
    weights[0, :] = 1/par  # weights of particles (initially uniformly distributed)
    Xc = np.zeros(shape=(1, par))  # Vector to store Resampling Positions

    Predict = np.zeros(shape=(1, N))  # Prediction Vector
    Predict[0, 0] = np.dot(ParPos[0, :], weights[0, :].conj().transpose())


    # SIR algorithm
    for i in range(1, N):
        for j in range(0, par):
            ParPos[i, j] = np.random.normal(x[0, i]-ParPos[i-1, j], 1)  # Position Update
            weights[i, j] = weights[i-1, j]*np.exp(-((y[0, i]-ParPos[i, j])**2)/2)  # weight update

        weights[i, :] = weights[i, :]/np.sum(weights[i, :])  # Normalization of Weights
        Meff = 1/np.dot(weights[i, :], weights[i, :].conj().transpose())  # effective Particle Size
        Predict[:, i] = np.dot(ParPos[i, :], weights[i,:].conj().transpose())  # Prediction
        # Resampling
        if Meff < (par/2):
            # Xc = np.zeros(shape=(par,))
            for d in range(0, par):
                km = np.random.multinomial(1, weights[i, :], 1)  # Drawing from a multivariable distribution
                Xc[0, d] = np.dot(ParPos[i, :], km.conj().transpose())  # Select the Position that is drawn

            # Update Positions and Weights
            ParPos[i, :] = Xc
            weights[i, :] = 1/par

    for fig in [1, 2, 3, 29, N-1]:
        plt.figure(fig+1)
        plt.stem(np.array(range(0, par)), weights[fig, :], basefmt=' ')

    plt.figure(N+1)
    plt.plot(np.array(range(0, N)), Predict[0, :], '--k')
    plt.show()


if __name__ == '__main__':
    SIR_17_9()