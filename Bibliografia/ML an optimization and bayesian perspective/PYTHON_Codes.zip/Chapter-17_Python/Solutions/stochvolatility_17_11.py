#-----------------------------------------------------------------
#  Exercise 17.11
#  Stochastic volatility model.
#  Python3 required packages: numpy, matplotlib, scipy
# -----------------------------------------------------------------


import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import norm

def stochvolatility_17_11():

    # Initialization of Variables
    N = 50  # time instances
    x = np.zeros(shape=(1, N))
    y = np.zeros(shape=(1, N))

    # Stochastic Volatility Model
    a = 0.97
    b = 0.69
    sigma_h = np.sqrt(0.178)
    sigma_v = 1
    x[0, 0] = 1
    y[0, 0] = b*(sigma_v*np.random.randn(1))*np.exp(x[0, 0]/2)
    for i in range(1, N):
        x[0, i] = a*x[0, i-1]+(sigma_h*np.random.randn(1))
        y[0, i] = b*(sigma_v*np.random.randn(1))*np.exp(x[0, i]/2)

    # Plot Figures of Input and Output Sequences
    plt.figure(1)
    # plt.plot(np.array(range(0, N)), x[0, :], 'g')
    plt.plot(np.array(range(0, N)), y[0, :], 'r')

    # APF Algorithm
    par = 1000  # Number of Particles
    ParPos = np.zeros(shape=(N, par))  # Positions of Particles
    weights = np.array(ParPos)  # Weights of Particles
    ParPos[0, :] = np.random.randn(1, par)+x[0, 0]
    weights[0, :] = 1/par
    xHat = np.zeros(shape=(1, par))
    kweights = np.zeros(shape=(1, par))
    xHat2 = np.array(xHat)

    Prediction = np.zeros(shape=(1, N))
    Prediction[0, 0] = np.dot(ParPos[0, :], weights[0, :].conj().transpose())

    # Main APF algorithm
    for i in range(1, N):
        xHat = x[0, i]-ParPos[i-1, :]  # Expectation of x_n given previous particles
        kweights[0, 0:par] = weights[i-1, :] * norm.pdf(y[0, i] - xHat)
        kweights = kweights/np.sum(kweights)
        for j in range(0, par):
            Km = np.random.multinomial(1, kweights[0, :], 1)
            ParPos[i, j] = np.random.randn(1)+x[0, i]-np.dot(ParPos[i-1,:], Km.conj().transpose())
            xHat2[0, j] = np.dot(xHat, Km.conj().transpose())

        weights[i, :] = norm.pdf(y[0, i] - ParPos[i, :]) / norm.pdf(y[0, i] - xHat2)
        weights[i, :] = weights[i, :]/np.sum(weights[i, :])  # Normalization of Weights
        Prediction[:, i] = np.dot(ParPos[i, :], weights[i, :].conj().transpose())  # Prediction

    plt.figure(1)
    plt.plot(np.array(range(0, N)), Prediction[0, :], '--k')
    plt.grid(True)

    plt.show()

if __name__ == '__main__':
    stochvolatility_17_11()