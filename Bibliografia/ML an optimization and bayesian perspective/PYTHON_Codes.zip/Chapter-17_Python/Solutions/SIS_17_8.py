# -----------------------------------------------------------------
# Exercise 17.8
# SIS particle filtering algorithm
# Python3 required packages: numpy, matplotlib
# -----------------------------------------------------------------

import numpy as np
import matplotlib.pyplot as plt

def SIS_17_8():

    # Initialization of Variables
    N = 90  # stream of particles
    x = np.zeros(shape=(1, N))
    y = np.array(x)

    # State Model
    x[0, 0] = 1
    y[0, 0] = x[0, 0]+np.random.randn(1)

    for i in range(1, N):
        x[0, i] = x[0, i-1]+np.random.randn(1)
        y[0, i] = x[0, i]+np.random.randn(1)

    # Figures of State Model
    plt.figure(1)
    plt.plot(np.array(range(0, N)), x[0, :])
    plt.figure(2)
    plt.plot(np.array(range(0, N)), y[0, :])

    # Main Algorithm
    par = 1000
    ParPos = np.random.randn(par, 1)
    weights = np.ones(shape=(par, 1))
    weights /= par

    # uncomment to plot the initial weights
    # plt.figure(3)
    # plt.stem(ParPos, weights, basefmt=' ')

    # Plot of weights for different time snapshots
    for i in [1, 2, 3, 9, 29]: # % change i to see the weights for the
        # desired time instances.
        for j in range(0, par):
            ParPos[j] = np.abs(x[0, i]-ParPos[j])+np.random.randn(1)
            weights[j] = weights[j]*np.exp(-((y[0, i]-ParPos[j])**2)/2)

        weights /= np.sum(weights)
        plt.figure(3+i)  # generate a figure for each shanpshot of the algorithm
        plt.stem(ParPos, weights, basefmt=' ')

    plt.show()

if __name__ == '__main__':
    SIS_17_8()
