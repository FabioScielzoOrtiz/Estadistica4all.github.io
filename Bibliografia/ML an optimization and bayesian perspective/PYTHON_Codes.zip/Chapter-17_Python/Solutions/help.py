import numpy as np
import math

def frange(x, y, jump):
    values = []
    while x < y:
        values.append(x)
        x += jump

    return values

# Plot a white circle onto an image with black background
# r the circle radius
# i0, j0 the circle center
# DIM the size of the rectangular image
def plotCircle(r, i0, j0, DIM):

    t = np.array(frange(0, 2*math.pi, 0.1))

    i = np.round(r * np.cos(t) + i0)
    j = np.round(r * np.sin(t) + j0)
    outimage = np.zeros(shape=(DIM, DIM))

    points = []

    for ii, jj in list(zip(i, j)):
        if 0 < ii < DIM and 0 < jj < DIM:
            outimage[int(ii), int(jj)] = 1

    return outimage

# Calculate likelihood p(y_n|x_n) of a particle based on the distance from the real center
# i0, j0 (x_n) the circle center coordinates
# i, j (y_n) the particle coordinates
def calculateObservationLikelihood(i0, j0, i, j):
    a = 2  # decay factor

    d = np.sqrt((i - i0) ** 2 + (j - j0) ** 2)

    f = np.exp(-a * d)
    return f


# Do sampling given the weight function w
def performSampling(w):
    x = np.random.rand(1)
    acc = 0
    i = 0

    while 1:

        acc = acc + w[0, i]
        if acc > x:
            break

        i = i + 1

    out = i

    return out