# -----------------------------------------------------------------
#   Exercise 15.11
#   Visual Tracking
#   Use particle filter for tracking a circle moving according to
#   a random uniform model in the image.
#
#   Includes functions for circle plotting, likelihood estimation
#   and particle sampling.
#
#   Writing to a video file can be activated by activating the
#   related commented code
#   Python3 required packages: numpy, matplotlib, scikit-video
# -----------------------------------------------------------------


import numpy as np
import math
import matplotlib.pyplot as plt
import skvideo.io
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_17.help import frange, performSampling, plotCircle, calculateObservationLikelihood

def tracking_17_12():
    DIM = 300  # image size (DIM x DIM)

    CYCLES = 120  # the number of cycles

    r = 10  # the radius of the circle to track

    C = 5  # coefficient for the noise covariance bigger C => higher dispersion of particles

    # initial position of the circle at the image center
    i0 = math.floor(DIM/2)
    j0 = math.floor(DIM/2)

    # mean and variance for the noise model
    M = np.array([0, 0]).conj().transpose()
    V = C*np.array([[2, 0.5], [0.5, 2]])

    N = 50  # number of particles

    # initialize particles
    particle = np.random.multivariate_normal(M, V, size=N) + np.kron(np.ones((N, 1)), np.array([i0, j0]))
    y = np.zeros(shape=particle.shape)

    # initialize particle weights to the same value
    w = np.ones(shape=(1, N)) / N

    # activate commented line to write into a video file
    # writer = skvideo.io.FFmpegWriter("./particlefilter.avi")



    for k in range(0, CYCLES):

        # the circle moves randomly following a uniform
        # motion model in the interval [-10 10] for each dimension
        eta = np.floor(20*np.random.rand(2, 1)-10)
        i0 = eta[0] + i0
        j0 = eta[1] + j0

        # the real circle image
        target_image = plotCircle(r,i0,j0, DIM)

        # add noise to image
        # target_image = imnoise(target_image,'salt & pepper', 0.04);

        # get the likelihood for each particle
        for c in range(0, N):
            w[0, c] = calculateObservationLikelihood(i0, j0, particle[c, 0], particle[c, 1])

        # weight normalization
        if np.sum(w) == 0:
            break

        w = w/np.sum(w)

        # create image for plotting
        particle_image = np.zeros(shape=(DIM,DIM))

        # Draw all particles into an RGB image with red color
        for c in range(0, N):
            particle_image = particle_image + plotCircle(r, particle[c, 0], particle[c, 1], DIM)

        # do resampling based on the weights
        for c in range(0, N):
            s = performSampling(w)
            M1 = np.array([[particle[s, 0]], [particle[s, 1]]])
            y[c, :] = np.array(M1 + np.random.multivariate_normal(M, V, size=1).conj().transpose())[:, 0]  # generate observations

        particle = np.array(y)

        rgb_image = np.ones(shape=(DIM, DIM, 3))

        # paint red the particles
        rgb_image[:, :, 1] = np.multiply(rgb_image[:, :, 0], np.array(1 - particle_image, dtype=np.float))
        rgb_image[:, :, 2] = rgb_image[:, :, 1]

        # paint black the target
        rgb_image[:, :, 0] = np.multiply(rgb_image[:, :, 0], np.array(1 - target_image, dtype=np.float))
        rgb_image[:, :, 1] = np.multiply(rgb_image[:, :, 1], np.array(1 - target_image, dtype=np.float))
        rgb_image[:, :, 2] = rgb_image[:, :, 1]

        plt.imshow(np.array(255*rgb_image, dtype=np.uint8))
        plt.show(block=False)
        plt.pause(0.25)  # delay for display purposes

        # activate commented line to write into a video file
        # writer.writeFrame(np.array(255*rgb_image, dtype=np.uint8))

    # activate commented line to write into a video file
    # writer.close()

    plt.show()


if __name__ == '__main__':
    tracking_17_12()