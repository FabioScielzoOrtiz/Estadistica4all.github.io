# --------------------------------------------------------------------
# Exercise 9.22
# Python3 required packages: numpy, scikit-learn, scipy, matplotlib
# ------------------------------------------------------------------------

import numpy as np
from sklearn.linear_model import  Lasso
import math
from matplotlib import pyplot as plt
from scipy.io import loadmat
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')

from PYTHON_9.help import OMP, waitbar, im2col


def denoising_9_22():


    x_exact = np.array(loadmat('boats.mat')['boats'])

    sigma = 20
    x_noise = x_exact + np.random.randn(x_exact.shape[0], x_exact.shape[1])*sigma
    blocksize = 12  # block size
    K = 14**2  # number of atoms in the dictionary

    X = im2col(x_noise, BSZ=(blocksize, blocksize))

    # Question (a)
    # use fixed dictionary
    n = np.array(range(0, blocksize))
    DCT = np.zeros(shape=(blocksize, int(math.sqrt(K))))
    for k in range(0, int(math.sqrt(K))):
       V = np.cos(n.conj().transpose()*k*np.pi/math.sqrt(K))
       DCT[:, k] = V/np.linalg.norm(V)

    # Question (b)
    DCT = np.kron(DCT, DCT)
    Dict_fixed = DCT
    for k in range(0, Dict_fixed.shape[1]):
       Dict_fixed[:, k] = Dict_fixed[:, k]/np.linalg.norm(Dict_fixed[:, k])

    # denoising with DCT

    X_reconst = np.zeros(shape=X.shape)
    subproblems = X.shape[1]
    waitbar(0, 100, 'Please wait...')
    for i in range(0, X.shape[1]):
        if i % 100 == 0:
            waitbar(i/subproblems, 100, 'Please wait...')

        G = Lasso(fit_intercept=False, normalize=False).fit(Dict_fixed, X[:, i])
        X_reconst[:, i] = np.dot(Dict_fixed, G.coef_)
        # It will be faster using OMP (check
        # http://www.cs.technion.ac.il/~ronrubin/Software/ompbox10.zip for a fast
        # implementation)
        # G = omp(Dict_fixed,X(:,i),[],5);
        # or use the OMP you will write in Python exercise 10.12
        # G = OMP(Dict_fixed, X[:, i], 5)
        # X_reconst[:, i] = np.dot(Dict_fixed, G[:, 0])

    sys.stdout.flush()
    print('')

    # ========================================================
    # this is a Python implementation of the code contained in Chapter_15_CoreInpaining1.m of Elad's book
    # "Sparse and Redundant Representations: From Theory to Applications in Signal and Image Processing" ,
    # Springer, 2010
    # ========================================================
    N = x_exact.shape[0]
    n = blocksize
    yout = np.zeros(shape=(N, N))
    Weight = np.zeros(shape=(N, N))
    i = 0
    j = 0
    for k in range(0, (N-n+1)**2):
        patch = np.reshape(X_reconst[:, k], newshape=(n, n))
        yout[i:(i+n), j:(j+n)] += patch
        Weight[i:(i+n), j:(j+n)] += 1
        if j < (N-n):
            j += 1
        else:
            j = 0
            i += 1

    recovered_boat_dct = np.divide(yout, Weight)

    print(20*np.log10(255 * np.sqrt(x_exact.shape[0]*x_exact.shape[1]) / np.linalg.norm(x_exact-x_noise)))
    print(20*np.log10(255 * np.sqrt(x_exact.shape[0]*x_exact.shape[1]) / np.linalg.norm(x_exact-recovered_boat_dct)))

    plt.figure(1)
    plt.subplot(1, 3, 1)
    plt.imshow(x_exact, cmap='gray', vmin=0, vmax=255)
    plt.subplot(1, 3, 2)
    plt.imshow(x_noise, cmap='gray', vmin=0, vmax=255)
    plt.subplot(1, 3, 3)
    plt.imshow(recovered_boat_dct, cmap='gray', vmin=0, vmax=255)

    plt.show()


if __name__ == '__main__':

    denoising_9_22()
