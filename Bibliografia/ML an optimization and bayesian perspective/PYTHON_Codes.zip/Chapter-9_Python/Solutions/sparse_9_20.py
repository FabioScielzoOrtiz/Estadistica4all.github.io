# -----------------------------------------------------------------
# Exercise 9.20
# Python3 required packages: numpy, functools
# -----------------------------------------------------------------


import numpy as np
from functools import reduce


def sparse_9_20():
    A = np.array([[0.5, 2, 1.5], [1.5, 2.3, 3.5]])
    x = np.array([2.5, 0, 0], ndmin=2).conj().T
    y = np.dot(A, x)

    # L2 norm minimized olution
    theta2 = reduce(np.dot, (A.conj().T, np.linalg.inv(np.dot(A, A.conj().T)), y))
    error_L2 = np.linalg.norm(y-np.dot(A, theta2))  # Check that theta2 is a solution
    print('L2 norm minimization solution:')
    print(theta2)  # Note that theta2 is not one-sparse

    print('Error achieved with L2 norm minimization: %.20f' % error_L2)
    print('------------------------')
    # Exhaustive search of all combinations
    print('Start checking for potential 1-sparse solutions')
    print('Check solution [x,0,0]')
    subA = np.array(A[:, 0], ndmin=2).conj().T
    xx1 = np.zeros((3, 1))
    xx1[0] = reduce(np.dot, (np.linalg.inv(np.dot(subA.conj().T, subA)), subA.conj().T, y))
    print('Result:')
    print(xx1)
    error1 = np.linalg.norm(y-np.dot(A, xx1))  # Check that xx1 is a solution
    print('Achieved error: %.20f '% error1)
    print('------------------------')

    print('Check solution [0,x,0]')
    subA = np.array(A[:, 1], ndmin=2).conj().T
    xx2 = np.zeros((3, 1))
    xx2[1] = reduce(np.dot, (np.linalg.inv(np.dot(subA.conj().T, subA)), subA.conj().T, y))
    print('Result:')
    print(xx2)
    error2 = np.linalg.norm(y - np.dot(A, xx2))  # Check that xx2 is a solution
    print('Achieved error: %f ' % error2)
    print('------------------------')

    print('Check solution [0,0,x]')
    subA = np.array(A[:, 2], ndmin=2).conj().T
    xx3 = np.zeros((3, 1))
    xx3[2] = reduce(np.dot, (np.linalg.inv(np.dot(subA.conj().T, subA)), subA.conj().T, y))
    print('Result:')
    print(xx3)
    error3 = np.linalg.norm(y - np.dot(A, xx3))  # Check that xx3 is a solution
    print('Achieved error: %f ' % error2)
    print('------------------------')

    print('So, the vector ')
    print(xx1)
    print('is a solution so no reason to search for 2-sparse solutions')
    theta0 = xx1

    print('------------------------')
    print('Check the L2 norms of the L2 and L0 minimization solutions')
    print('L2 minimization: %f' % np.linalg.norm(theta2))
    print('L0 minimization: %f' % np.linalg.norm(theta0))

if __name__ == '__main__':

    sparse_9_20()

