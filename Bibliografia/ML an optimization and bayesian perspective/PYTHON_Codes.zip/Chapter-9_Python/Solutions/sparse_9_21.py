# --------------------------------------------------------------------------
# Exercise 9.21
# Python3 required packages: numpy, scikit-learn

# -------------------------------------------------------------------------


import numpy as np
import math
from sklearn.linear_model import Lasso, LassoLars
import spams
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')

from PYTHON_9.help import py_dctmtx

def sparse_9_21():

        np.random.seed(0)
        N = 30
        K = 5
        l = 100
        rep = 500

        theta = np.zeros(shape=(l, 1))
        theta[0:K] = np.random.randn(K, 1)
        X = np.random.randn(N, l)*(1/math.sqrt(N))
        y = np.dot(X, theta)

        # Question (a)
        model = Lasso(alpha=0.0001, fit_intercept=False, normalize=False, max_iter=1e6)
        model.fit(X, y)
        values = model.coef_
        print(values)

        # exit(0)
        # sols = spams.lasso(np.asfortranarray(X), np.asfortranarray(y), return_reg_path=False, L=K, numThreads=-1,
        #                         lambda1=0.0005, mode=2)
        # values = sols.todense()
        error = np.linalg.norm(np.reshape(np.array(values), newshape=theta.shape)-theta)
        print('Question (a): '+ str(error))
        exit(0)
        # Question (b)
        Err = np.zeros(shape=(rep, 1))
        for epan in range(0, rep):

            X = np.random.randn(N, l) * (1/np.sqrt(N))
            y = np.dot(X, theta)

            model = Lasso(alpha=0.0001, fit_intercept=False, normalize=False, max_iter=1e6)
            model.fit(X, y)
            values = model.coef_
            # sols = spams.lasso(np.asfortranarray(X), np.asfortranarray(y), return_reg_path=False, L=K, numThreads=-1,
            #                    lambda1=0.0005, mode=2)
            # values = sols.todense()

            errorX = np.linalg.norm(np.reshape(np.array(values), newshape=theta.shape)-theta)
            if errorX < 10**(-8):
                Err[epan] = 1
            else:
                Err[epan] = 0

        probrandn = np.sum(Err)/rep
        print('Question (b): Random Sensing Mtx: '+ str(probrandn))

        # Question (c)
        Err = np.zeros(shape=(rep, 1))
        for epan in range(0, rep):

            # Construct DCT based sensing matrix
            X = np.array(py_dctmtx(l))
            X = X[np.random.choice(l, N, replace=False), :]

            y = np.dot(X, theta)

            model = Lasso(alpha=0.0001, fit_intercept=False, normalize=False, max_iter=1e6)
            model.fit(X, y)
            values = model.coef_
            # sols = spams.lasso(np.asfortranarray(X), np.asfortranarray(y), return_reg_path=False, L=K, numThreads=-1,
            #                    lambda1=0.0005, mode=2)
            # values = sols.todense()

            errorX = np.linalg.norm(np.reshape(np.array(values), newshape=theta.shape)-theta)

            if errorX < 10**(-8):
                Err[epan] = 1
            else:
                Err[epan] = 0

        probDCT = np.sum(Err)/rep
        print('Question (c): DCT Sensing Mtx: '+ str(probDCT))

        # Question (d)
        p = [1, 9, 25, 36, 64]
        Err = np.zeros(shape=(rep, 1))
        for pval in p:
            for epan in range(0, rep):

                # Construct sparse sensing matrix
                OK = False
                while not OK is True:
                    kk = np.zeros(shape=(N*l, 1))
                    P = np.random.permutation(N*l)
                    numofzeros = int(np.around(N*l*(1-1/math.sqrt(pval))))
                    P[(N*l-numofzeros):] = 0
                    kk[P] = np.sqrt((math.sqrt(pval)/N))*np.multiply(np.ones(shape=(len(P), 1)), np.sign(np.random.randn(len(P), 1)))
                    X = np.zeros(shape=(N, l))

                    X[0:(l*N)] = np.reshape(kk, newshape=(N,l))

                    # Check if it is full rank
                    if np.linalg.matrix_rank(X) == N:
                        OK = True
                    else:
                        OK = False


                y = np.dot(X, theta)

                model = Lasso(alpha=0.0001, fit_intercept=False, normalize=False, max_iter=1e6)
                model.fit(X, y)
                values = model.coef_
                # sols = spams.lasso(np.asfortranarray(X), np.asfortranarray(y), return_reg_path=False, L=K, numThreads=-1,
                #                    lambda1=0.0005, mode=2)
                # values = sols.todense()
                errorX = np.linalg.norm(np.reshape(np.array(values), newshape=theta.shape)-theta)

                if errorX < 10 ** (-8):
                    Err[epan] = 1
                else:
                    Err[epan] = 0

            probsparse = np.sum(Err)/rep
            print('Question (d): Sparse Sensing Mtx, p='+str(pval)+': '+str(probsparse))




        print('')




if __name__ == '__main__':

    sparse_9_21()