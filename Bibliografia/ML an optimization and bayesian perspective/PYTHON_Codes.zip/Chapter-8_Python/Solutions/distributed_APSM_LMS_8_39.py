# -----------------------------------------------------------------
# Exercise 8.39.
# It generates the network, produces the data
# and calls the ATC, CTA and non--cooperative LMS functions.
# Running it, it may take some time.
# Python3 required packages: numpy, matplotlib
# -----------------------------------------------------------------

import sys
import os
import numpy as np
from matplotlib import pyplot as plt

sys.path.append(os.getcwd())
sys.path.append('../')

from PYTHON_8.LMS_distrib_ATC import LMS_distrib_sparse_ATC
from PYTHON_8.LMS_distrib_CTA import LMS_distrib_sparse_CTA
from PYTHON_8.APSM_distrib import APSM_distrib_sparse
from PYTHON_8.makenetwork import makenetwork
from PYTHON_8.help import LMS_param_struct, APSM_param_struct


def distributed_LMS_5_24():

    err = []
    leg = []
    N = 2000

    resultsfolder = './results_timevar/'
    # rng(123,'twister')
    plots = 0

    # Make unknown vector
    L = 60

    np.random.seed(12)
    nodes = 10
    connections = 32

    # Make the network
    distributed = 1
    if distributed:
        ruleweights = 'metropolis'  # Combination Coefficients
        # ruleweights = 'noncoperation'
        [Nmat, C, connected] = makenetwork(nodes, connections, ruleweights, 100, 0)

        if not connected:
            print('I did not manage to build a connected network')
            return
    else:
        C = np.eye(nodes)
        connections = 0

    totalrep = 100  # Total number of iterations for averaging
    errlms = []
    for inod in range(0, nodes):
        errlms.append(np.zeros((1, N)))
    errlms = np.array(errlms)

    totalerr1 = np.zeros((1, N))
    totalerr2 = np.zeros((1, N))
    totalerr3 = np.zeros((1, N))
    totalerr4 = np.zeros((1, N))
    fullmatinput = 0

    X = np.empty(shape=(nodes, L, N))
    if fullmatinput == 1:
        X = np.empty(shape=(1, nodes))

    X = np.array(X)
    namelms = ['LMS', 'L', str(L), '_Nd', str(nodes), '_Cn', str(connections)]

    # Start ensemble averages
    for rep in range(0, totalrep):  # =1:totalrep
        print(rep)
        namelms = ['LMS', '_r', str(rep), '_L', str(L), '_Nd', str(nodes), '_Cn', str(connections)]

        np.random.seed(rep)  # rng(rep,'twister')
        h1 = np.random.randn(L, 1)
        h2 = h1  # To create a suddent change in the channel substitute this line with h2=randn(L,1);
        changepoint = round(N/2)
        h = np.zeros(shape=(2, L, 1))
        h[0] = h1
        h[1] = h2

        hh = lambda i: h[(i > changepoint)+1, :, :]

        for j in range(0, nodes):
            X[j] = np.random.randn(L, N)

        if fullmatinput == 0:
            inputvec = lambda node, k: X[node][:, k]
        else:
            inputvec = lambda node, i: X[node][:, i]

        # Tune the noise variance in order to have a certain SNR in the first section
        # (which has \norm{x}^2 input energy)
        sigmaxsqr = (100 ** 2) / L  # The input vectors have normalized norm equal to 100
        SNR_high = 25
        SNR_low = 20
        SNR = np.linspace(SNR_low, SNR_high, nodes)

        noisevec = np.empty(shape=(nodes, N))
        noisevar = np.empty(shape=(nodes, 1))
        for inode in range(0, nodes):
            noisevar[inode] = (np.var(h1)*sigmaxsqr)/10 ** (SNR[inode]/10)
            # st = randomstate.prng.mlfg_1279_861.RandomState(nodes+inode)
            noisevec[inode] = np.random.randn(N)*np.sqrt(noisevar[inode])

        normh1 = np.linalg.norm(h1)
        normh2 = normh1
        # Determine how to compute the error
        errfun = lambda i, h_hat: comperr(h_hat, i, changepoint, h1, normh1, h2, normh2)

        y_noise = np.empty(shape=(nodes, N, 1))
        y_clean = np.empty(shape=(nodes, N, 1))

        for i in range(0, nodes):  # =1:nodes:
            if not callable(hh):
                y_clean[i] = np.dot(X[i].conj().transpose(), hh)
            else:
                y_clean[i] = np.dot(X[i].conj().transpose(), hh(i))

            y_noise[i] = y_clean[i] + noisevec[inod][i]

        playLMS = 1
        if playLMS == 1:

            mu = 0.01
            LMS_param = LMS_param_struct()
            # The following struct contains the parameters used for the the LMS.
            LMS_param.mu = 0.03
            LMS_param.normalized = 0.0
            LMS_param.gamma = 0  # 0.25*10^(-3);
            LMS_param.L = L
            LMS_param.N = N
            LMS_param.h = hh
            LMS_param.C = C
            LMS_param.nodes = nodes
            LMS_param.dataexchange = 0  # if it excanges data with its neighbors

            APSM_param = APSM_param_struct()
            APSM_param.mu = 1
            APSM_param.L = L
            APSM_param.q = 20
            APSM_param.epsilon = 0.5
            APSM_param.N = N
            APSM_param.h = h
            APSM_param.C = C
            APSM_param.nodes = nodes

        else:
            LMS_param = None
            APSM_param = None

        [err1, x] = LMS_distrib_sparse_ATC(inputvec, y_noise, LMS_param, errfun)  # Adapt then Combine LMS
        [err2, x] = LMS_distrib_sparse_CTA(inputvec, y_noise, LMS_param, errfun)  # Combine then Adapt LMS
        errmeanlms1 = np.zeros((1, N))
        errmeanlms2 = np.zeros((1, N))
        errmeanlms3 = np.zeros((1, N))
        errmeanlms4 = np.zeros((1, N))

        LMS_param.C = np.eye(nodes)  # Here is the nondistributed case
        [err3, x] = LMS_distrib_sparse_ATC(inputvec, y_noise, LMS_param, errfun)
        [err4, x] = APSM_distrib_sparse(inputvec, y_noise, APSM_param, errfun)



        for inod in range(0, nodes):  # =1:nodes:
            errmeanlms1 = errmeanlms1 + err1[inod]
        for inod in range(0, nodes):  # =1:nodes:
            errmeanlms2 = errmeanlms2 + err2[inod]
        for inod in range(0, nodes):  # =1:nodes:
            errmeanlms3 = errmeanlms3 + err3[inod]
        for inod in range(0, nodes):  # =1:nodes:
            errmeanlms4 = errmeanlms4 + err4[inod]

        errmeanlms1 = errmeanlms1/nodes
        errmeanlms2 = errmeanlms2/nodes
        errmeanlms3 = errmeanlms3/nodes
        errmeanlms4 = errmeanlms4/nodes

        totalerr1 = totalerr1+errmeanlms1
        totalerr2 = totalerr2+errmeanlms2
        totalerr3 = totalerr3+errmeanlms3
        totalerr4 = totalerr4+errmeanlms4

    # end if playLMS==1

    totalerr1 = totalerr1 / totalrep
    totalerr2 = totalerr2 / totalrep
    totalerr3 = totalerr3 / totalrep
    totalerr4 = totalerr4 / totalrep

    # the average of all the nodes.
    # end
    plt.figure(1)
    plt.plot(range(1, N+1), totalerr1.flatten(), 'r')
    plt.plot(range(1, N+1), totalerr2.flatten(), 'g')
    plt.plot(range(1, N+1), totalerr3.flatten(), 'k')
    plt.plot(range(1, N+1), totalerr4.flatten(), 'm')

    plt.show()


def comperr(h_hat, i, change_i, h1, normh1, h2, normh2):

    if i <= change_i:
        # err = 20 * log10(np.linalg.norm(h1 - h_hat) / normh1);
        err = 20 * np.log10(np.linalg.norm(h1 - h_hat))
    else:
        # err = 20 * log10(np.linalg.norm(h2 - h_hat) / normh2);
        err = 20 * np.log10(np.linalg.norm(h2 - h_hat))

    return err


if __name__ == '__main__':
    distributed_LMS_5_24()
