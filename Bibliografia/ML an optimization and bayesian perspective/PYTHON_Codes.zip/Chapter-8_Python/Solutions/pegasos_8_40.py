# -----------------------------------------------------------------
# Exercise 8.40
# Implementation of the Pegasos Algorithm.
# Dataset: https://archive.ics.uci.edu/ml/datasets/banknote+authentication
# Python3 required packages: numpy, math
# -----------------------------------------------------------------

import numpy as np
import math
import os
import sys

def split_set(file, train_percentage=0.9):

    XY1 = []
    XY2 = []
    X = []
    Y = []
    X_test = []
    Y_test = []
    with open(file, "r") as filestream:
        for line in filestream:
            currentline = line.split(",")
            currentline[len(currentline) - 1] = currentline[len(currentline)-1].replace('\n','')
            values = np.array(currentline[0:(len(currentline))]).astype(np.float32)
            label = np.array(currentline[(len(currentline)-1)]).astype(np.int)
            if label == 0:
                XY1.append(values)
            else:
                XY2.append(values)

    XY1 = np.array(XY1)
    indices1 = np.random.permutation(XY1.shape[0])
    training_idx1, test_idx1 = indices1[:int(train_percentage*XY1.shape[0])], indices1[int(train_percentage*XY1.shape[0]):]
    training1, test1 = XY1[training_idx1, :], XY1[test_idx1, :]

    XY2 = np.array(XY2)
    indices2 = np.random.permutation(XY2.shape[0])
    training_idx2, test_idx2 = indices2[:int(train_percentage*XY2.shape[0])], indices2[int(train_percentage*XY2.shape[0]):]
    training2, test2 = XY2[training_idx2, :], XY2[test_idx2, :]

    for element in training1:
        X.append(list(element[0:(len(element)-1)]))
        Y.append(int(-1))#element[len(element)-1]))

    for element in training2:
        X.append(list(element[0:(len(element)-1)]))
        Y.append(int(element[len(element)-1]))

    for element in test1:
        X_test.append(list(element[0:(len(element)-1)]))
        Y_test.append(int(-1))#element[len(element)-1]))

    for element in test2:
        X_test.append(list(element[0:(len(element)-1)]))
        Y_test.append(int(element[len(element)-1]))

    return np.array(X), np.array(Y), np.array(X_test), np.array(Y_test)

def pegasos_train(X, Y, lamda=None, k=None, maxIter=None, Tolerance=None):
    # X imput matrix
    # Y labels
    # lamda stepsize parameter of pegasos
    # k data processed per iteration step
    # maxIter the maximum number of iterations
    # Tolerance Error Tolerance

    [N, d] = X.shape

    if Y.shape[0] != N:
        print('\nError: Number of elements in X and Y must same\nSee pegasos usage for further help\n')
        return None, None

    if np.count_nonzero(Y == 1) + np.count_nonzero(Y == -1) <= 0:
        print('\nError: Y must be 1 or -1\nSee pegasos usage for further help\n')
        return None, None

    if lamda is None:
        lamda = 1.0
    if maxIter is None:
        maxIter = 10000
    if k is None:
        k = math.ceil(0.1 * N)
    if Tolerance is None:
        Tolerance = 10**-6

    w = np.random.rand(maxIter, X.shape[1])
    w = (w / (np.sqrt(lamda)) * np.linalg.norm(w)) # Initialization

    count = 1
    for t in range(0, maxIter):
        #count = t + 1
        b = np.mean(Y - X @ w[t, :].conj().transpose())
        idx = np.random.randint(size=(k,1),low=0, high=X.shape[0])
        At = X[idx[:,0],:]
        yt = Y[idx[:,0],:]
        idx1 = ((At @ w[t,:].conj().transpose()+b) * yt) < 1
        etat = 1/(lamda*(t+1))

        w1 = (1-etat*lamda)*w[t, :]+(etat/k)*np.sum(At[idx1[:,0],:] * np.kron(np.ones(shape=(1, At.shape[1])), yt[idx1[:,0]]), axis=0)

        if (t+1)<maxIter:
            w[t + 1, :] = (np.minimum(1.0, 1.0 / (
                        np.sqrt(lamda) * np.linalg.norm(w1))) * w1)  # Updated estimate for the PEGASOS algorithm
            count += 1
            if np.linalg.norm(w[t+1, :] - w[t, :]) < Tolerance:
                break



    if count < maxIter:
        print('\nW converged in %d iterations.' % count)
    else:
        print('\nW not converged in %d iterations.' % (maxIter+1))

    wT = np.mean(w, axis=0)
    wT = np.reshape(wT, newshape=(wT.shape[0],1))
    b = np.mean(Y - np.dot(X, wT))

    Tr = np.count_nonzero(np.sign(np.dot(X,wT) + b) == Y)
    F = X.shape[0] - Tr
    TrainAccuracy = 100 * Tr/ (Tr + F)
    print('\nPegasos Accuracy on Training set = %.4f %%\n' % TrainAccuracy)

    return wT, b


def pegasos_main():


    X, Y, X_test, Y_test = split_set('./data_banknote_authentication.txt')


    Y = np.reshape(Y, newshape=(Y.shape[0],1))
    Y_test = np.reshape(Y_test, newshape=(Y_test.shape[0],1))

    lamda = 0.1
    m = [1, 10, 30]
    maxIter = 10000
    tolerance = 10 ** -6


    for mm in range(0, len(m)):
        wT, b = pegasos_train(X=X, Y=Y, lamda=lamda, k=m[mm], maxIter=maxIter, Tolerance=tolerance)

        Tr = np.count_nonzero(np.sign(np.dot(X_test, wT) + b) == Y_test)
        F = X_test.shape[0] - Tr
        TestAccuracy = 100 * Tr / (Tr + F)
        print('\nPegasos Accuracy on Test set = %.4f for m= %d\n' % (TestAccuracy, m[mm]))

    pass

if __name__ == '__main__':

    pegasos_main()

