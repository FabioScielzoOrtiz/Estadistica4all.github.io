# -----------------------------------------------------------------
# Exercise 8.38
# This script generates the model, the data and runs
# the APSM, the RLS, the APA and the NLMS algorithms.
# Python3 required packages: numpy, matplotlib
# -----------------------------------------------------------------

import numpy as np
from matplotlib import pyplot as plt
import os
import sys
sys.path.append(os.getcwd())
sys.path.append('../')
from PYTHON_8.help import py_convmtx

def APSM():
    L = 200  # Dimension of the unknown vector
    N = 3500  # Number of Data
    theta = np.random.randn(L, 1)  # Unknown parameter

    IterNo = 100
    MSE1 = np.zeros((N, IterNo))
    MSE2 = np.zeros((N, IterNo))
    MSE3 = np.zeros((N, IterNo))
    MSE4 = np.zeros((N, IterNo))

    noisevar = 0.01  # For the high noise scenario set this value equal to 0.3
    epsilon = np.sqrt(2) * np.sqrt(noisevar)  # Epsilon parameter used in the APSM

    X = np.random.randn(L, N)
    inputvec = lambda n: np.array([X[:, n].copy()])  # .conj().T
    noise = np.random.randn(N, 1) * np.sqrt(noisevar)
    y = np.zeros((N, 1))
    y[0:N] = np.dot(X[:, 0:N].conj().T, theta)
    y = y + noise

    for It in range(0, IterNo):  # =1:IterNo
        print('It = %d' % (It + 1))
        xcorrel = np.random.randn(N+L-1)  # ,1);
        xcorrel = xcorrel / np.std(xcorrel)

        X = py_convmtx(xcorrel, L)  # ';%Generate noise process
        X = np.delete(X, (range(0, L - 1)), axis=1)

        inputvec = lambda n: np.array([X[:, n].copy()]).conj().T
        noise = np.random.randn(N, 1) * np.sqrt(noisevar)
        y = np.zeros((N, 1))
        y[0:N] = np.dot(X[:, 0:N].conj().T, theta)
        y = y + noise

        w = np.zeros((L,1))  # Estimate vector
        mu = 0.2
        delta = 0.001
        q = 30  # Number of window used for the APA and the APSM.
        for i in range(0, N):
            if i > q:
                qq = range(i, i - q, -1)  # qq=i:-1:i-q+1;
                yvec = y[qq]
                Xq = inputvec(qq)
                Xq = np.reshape(Xq, newshape=(Xq.shape[0], Xq.shape[1]))
                e = yvec - np.dot(Xq, w)
                eins = y[i] - np.dot(w.conj().T, inputvec(i))
                # APA update
                w = w + mu * np.dot(np.dot(Xq.conj().T, np.linalg.inv(delta * np.eye(q) + np.dot(Xq, Xq.conj().T))), e)
                MSE1[i, It] = eins ** 2

        w = np.zeros((L, 1))
        for i in range(0,N):
            if i > q:
                qq = range(i, i - q, -1)  # qq=i:-1:i-q+1;
                yvec = y[qq]
                Xq = inputvec(qq)
                Xq = np.reshape(Xq, newshape=(Xq.shape[0], Xq.shape[1]))
                sum1 = np.zeros((L, 1))
                sum2 = 0

                for jj in range(0, q):  # =1:q
                    # Compute projection onto hyperslab
                    p = projection(np.array(yvec[jj], ndmin=2), np.array(Xq[jj, :], ndmin=2), w, epsilon)

                    sum1 = sum1 + (1/q) * p
                    sum2 = sum2 + (1/q) * (np.dot((p-w).conj().T, (p-w)))

                if np.array_equal(sum1, w):  # Extrapolation Parameter Computation
                    Mn = 1
                else:
                    Mn = sum2 / np.dot((sum1-w).conj().T, (sum1-w))

                eins = y[i] - np.dot(w.conj().T, inputvec(i))
                w = w + Mn * 0.5 * (sum1-w)  # APSM update
                MSE2[i, It] = eins ** 2

        w = np.zeros((L, 1))  # RLS recursion
        delta = 0.001
        Pi = delta * np.eye(L)
        P = (1 / delta) * np.eye(L)
        for i in range(0, N):

            gamma = 1/(1+np.dot(inputvec(i).conj().T, np.dot(P, inputvec(i))))
            gi = np.dot(P, inputvec(i)) * gamma
            e = y[i] - np.dot(w.conj().T, inputvec(i))
            w = w + gi * (e)
            P = P - np.dot(gi, gi.conj().T)/gamma
            MSE3[i, It] = e ** 2

        w = np.zeros((L, 1))  # NLMS Recursion
        delta = 0.001
        mu = 1.2
        for i in range(0, N):
            # mu=1;%/(i^0.5);
            e = y[i] - np.dot(w.conj().T, inputvec(i))
            mun = mu / (delta + np.dot(inputvec(i).conj().T, inputvec(i)))
            w = w + mun * e * inputvec(i)
            MSE4[i, It] = e ** 2

    MSEav1 = sum(MSE1.conj().T) / IterNo
    MSEav2 = sum(MSE2.conj().T) / IterNo
    MSEav3 = sum(MSE3.conj().T) / IterNo
    MSEav4 = sum(MSE4.conj().T) / IterNo

    plt.plot(10 * np.log10(MSEav1), 'r', lw=0.5)
    plt.plot(10 * np.log10(MSEav2), 'g', lw=0.5)
    plt.plot(10 * np.log10(MSEav3), 'b', lw=0.5)
    plt.plot(10 * np.log10(MSEav4), 'k', lw=0.5)

    plt.show()


def projection(y, x, f, epsilon):  # Projection onto the hyperslab function
    x = x.conj().T
    inner = np.dot(f.conj().T, x)
    if inner-y < -epsilon:
        fnew = f + ((y-inner-epsilon) / (np.dot(x.conj().T, x))) * x
    elif inner-y > epsilon:
        fnew = f + ((y-inner+epsilon) / (np.dot(x.conj().T, x))) * x
    else:
        fnew = f

    return fnew


if __name__ == '__main__':
    APSM()
