
# -----------------------------------------------------------------
# Exercise 11.14
# Kernel Ridge Regression
# on an audio sequence corrupted by
# Gaussian noise and outliers


# You need a .wav file to run the experiment...
# Python3 required packages: numpy, soundfile, matplotlib
# -----------------------------------------------------------------


import numpy as np
import math
import soundfile as sf
import matplotlib.pyplot as plt
import sys
import os
sys.path.append(os.getcwd())
sys.path.append('../../')

from PYTHON_11.Exercise_11_19_Kernel_Ridge_Regression.kernel_regression_l2_l2_biased import kernel_regression_l2_l2_biased
from PYTHON_11.Exercise_11_19_Kernel_Ridge_Regression.kernel_regression_l2_l2_unbiased import kernel_regression_l2_l2_unbiased
from PYTHON_11.Exercise_11_19_Kernel_Ridge_Regression.kappa import kappa


def kernelridge_11_19():
    np.random.seed(0)

    # --------------------------------------------------------------------
    # Reading wav file. x corresponds to time instances (is., x_i in [0,1])
    # fs is the sampling frequency
    # Replace the name "BladeRunner.wav" with the name of the file
    # you intend to use.
    # --------------------------------------------------------------------

    N = 100
    samples = 1000
    indices = range(0, samples,int(samples/N))
    start = 100000
    [data, fs] = sf.read('BladeRunner.wav')
    sound = np.array(data[start:(start+samples+1), :], dtype=np.float32)
    y = np.reshape(sound[indices, 0], newshape=(len(indices), 1))
    Ts = 1/fs  # h periodos deigmatolipsias
    x = np.array(range(0, samples)).conj().transpose()*Ts  # oi xronikes stigmes tis deigmatolipsias
    x = x[indices]
    x = np.reshape(x, newshape=(x.shape[0], 1))

    # -------------------------------------------------------

    # Add white Gaussian noise
    snr = 15  # dB
    y = py_awgn(y, snr)

    # add outliers
    O = 0.8*np.max(np.abs(y))
    percent = 0.1
    M = int(math.floor(percent*N))
    out_ind = np.random.choice(N, M, replace=False)
    outs = np.sign(np.random.randn(M, 1))*O
    y[out_ind] = y[out_ind] + outs

    M = len(y)

    # ----------Code for unbiased L2 Kernel Ridge Regression (KRR-L2)-----------
    C = 0.0001
    kernel_type = 'gaus'
    kernel_params = 0.004
    sol = kernel_regression_l2_l2_unbiased(x.conj().transpose(), y, [C], kernel_type, kernel_params)
    a0 = sol[0:N]

    # Generate regressor
    t = np.array([range(0, samples+1)]).conj().transpose()*Ts
    M2 = len(t)
    z0 = np.zeros(shape=(M2, 1))
    for k in range(0, M2):
        z0[k] = 0
        for l in range(0, N):
            z0[k] = z0[k] + a0[l]*kappa(x[l], t[k], kernel_type, [kernel_params])

    # ------------------end unbiased KRR-L2-------------------------------------

    # -----------Code for biased L2 Kernel Ridge Regression (KRR-L2)------------
    C = 0.0001
    kernel_type = 'gaus'
    kernel_params = 0.004
    sol = kernel_regression_l2_l2_biased(x.conj().transpose(), y, [C], kernel_type, kernel_params)
    a1 = sol[0:N]
    b1 = sol[N]

    # Generate regressor
    t = np.array([range(0, samples+1)]).conj().transpose()*Ts
    M2 = len(t)
    z1 = np.zeros(shape=(M2, 1))
    for k in range(0, M2):
        z1[k] = 0
        for l in range(0, N):
            z1[k] = z1[k] + a1[l]*kappa(x[l], t[k], kernel_type, [kernel_params])

        z1[k] = z1[k] + b1

    # ------------------end biased KRR-L2---------------------------------------

    # For unbiased KRR-L2
    plt.figure(1)
    # plot(x,y);
    plt.xlabel('time in sec')
    plt.ylabel('amplitude')

    plt.plot(t, z0, 'r', lw=1)
    plt.plot(x, y, '.', markeredgecolor=[0.3, 0.3, 0.3], markersize=5)

    title = 'unbiased KRR-L2  C= %s' % str(C)
    plt.title(title)

    # For biased KRR-L2
    plt.figure(2)
    # plot(x,y);
    plt.xlabel('time in sec')
    plt.ylabel('amplitude')

    plt.plot(t, z1, 'r', lw=1)

    plt.plot(x, y, '.', markeredgecolor=[0.3, 0.3, 0.3], markersize=5)

    title = 'biased KRR-L2  C= %s' % str(C)
    plt.title(title)

    plt.show()


def py_awgn(input_signal, snr_dB, rate=1.0):
    """ Addditive White Gaussian Noise (AWGN) Channel.

    Parameters
    __________
    input_signal : 1D ndarray of floats
        Input signal to the channel.

    snr_dB : float
        Output SNR required in dB.

    rate : float
        Rate of the a FEC code used if any, otherwise 1.

    Returns
    _______
    output_signal : 1D ndarray of floats
        Output signal from the channel with the specified SNR.
    """

    avg_energy = np.sum(np.dot(input_signal.conj().T, input_signal)) / input_signal.shape[0]
    snr_linear = 10 ** (snr_dB / 10.0)
    noise_variance = avg_energy / (2 * rate * snr_linear)

    if input_signal.dtype is np.complex:
        noise = np.array([np.sqrt(noise_variance) * np.random.randn(input_signal.shape[0]) * (1 + 1j)], ndmin=2)
    else:
        noise = np.array([np.sqrt(2 * noise_variance) * np.random.randn(input_signal.shape[0])], ndmin=2)

    output_signal = input_signal + noise.conj().T

    return output_signal


if __name__ == '__main__':
    kernelridge_11_19()
