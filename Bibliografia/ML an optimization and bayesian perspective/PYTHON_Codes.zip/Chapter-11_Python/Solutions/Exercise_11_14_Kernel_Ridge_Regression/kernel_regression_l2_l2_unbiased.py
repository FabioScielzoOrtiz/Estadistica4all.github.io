
# This function solves the optimization problem
# min_{a,b}    1/N �(y_n - f(x_n))^2 + �/2 �� a_n a_m �(x_n,x_m)
# where  f(x) = � a_n �(x_n,x) + b

# --------------------------------------
# Inputs
# X:               d x N matrix containing the N training points
#                  x_1, x_2, ..., x_N
# y:               N x 1 vector containing the N training points
#                  y_1, y_2, ..., y_N
# params           a matrix containg the problem parameters, i.e., �
# kernel_type      the type of the kernel. this is passed to the kappa
#                  function
# kernel_params    the parameters used to compute the kernel function. These
#                  are passed to the kappa function
# --------------------------------------
# Outputs
# sol              (N) x 1 vector containing the parameters a_n and the

#  Python3 required packages: numpy


import numpy as np
import sys
import os
sys.path.append(os.getcwd())
from PYTHON_11.Exercise_11_19_Kernel_Ridge_Regression.kappa import kappa


def kernel_regression_l2_l2_unbiased(X, y, params, kernel_type, kernel_params):

    lmbda = params[0]
    # build kernel matrix
    [d, N] = X.shape
    # for n=1:N
    #     for m=1:N
    #         K(n,m) = kappa(X(:,n), X(:,m), kernel_type, kernel_params);
    #     end;
    # end;
    if kernel_type == 'gaus':
        par = kernel_params
        norms = np.zeros(shape=(N, N))
        for i in range(0, N):
            T = X - X[:, i]  # bsxfun(@minus,X,X(:,i))
            norms[i, :] = np.sum(T**2, axis=0)

        K = np.exp(-norms/(par**2))
    elif kernel_type == 'gaus_c':
        par = kernel_params
        norms = np.zeros(shape=(N, N))
        for i in range(0, N):
            T = X - X[:, i].conj()  # bsxfun(@minus,X,conj(X(:,i)))
            norms[i, :] = np.sum(T**2, axis=0)

        K = 2*np.real(np.exp(-norms/(par**2)))
    else:
        K = np.zeros(shape=(N, N))
        for i in range(0, N):
            for j in range(0, N):
                K[i, j] = kappa(X[:, i], X[:, j], kernel_type, kernel_params)

    # A = [ (lmbda*K + 2/N*K*transpose(K))    2/N*K*ones(N,1);
    #       2/N*ones(1,N)*transpose(K)  2];
    # c = [2/N*K*y;
    #      2/N*transpose(y)*ones(N,1)];
    # Solve A*x=c
    # sol = pinv(A)*c;

    I = np.eye(N)
    A = lmbda*I+K/N
    c = y/N

    # Solve A*x=c
    sol = np.linalg.solve(A, c)
    return sol
