
#---------------------------------------------------------------------
# Excercise 11.16
# Support Vector Machine classification
#
# This file uses a simple SMO implementation to train the SVM.
# Python3 required packages: numpy, matplotlib

#---------------------------------------------------------------------
import numpy as np
import math
import matplotlib.pyplot as plt
import sys
import os
import time
sys.path.append(os.getcwd())
sys.path.append('../../')

from PYTHON_11.Exercise_11_21_Support_Vector_Machines.kappa import kappa
from PYTHON_11.Exercise_11_21_Support_Vector_Machines.SMO_classification import SMO_classification


def frange(x, y, jump):
    values = []
    while x < y:
        values.append(x)
        x += jump
    return values
def supportvectormachine_11_21():

    np.random.seed(0)


    print('Starting')
    N=150

    t = time.time()

    # ---------Generate Samples-------------------------
    f = lambda x: (0.05*x**3 + 0.05*x**2 + 0.05*x + 0.05)

    X_ = 10*np.random.rand(2,N) - 5
    x_ = X_[0,:]
    y_ = X_[1,:]
    fx = f(x_)



    C1=[]
    C2=[]
    y_training = np.zeros(shape=(N, 1))
    for i in range(0, N):
        if y_[i] < (fx[i] + 2*np.random.randn(1)):
            C1.append(i)
            y_training[i] = +1
        else:
            C2.append(i)
            y_training[i] = -1

    C1 = np.array(C1).conj().transpose()
    C2 = np.array(C2).conj().transpose()


    x_training = np.array([[x_], [y_]]).conj().transpose()
    x_training = np.reshape(x_training, newshape=(x_training.shape[0], x_training.shape[2]))
    #-----------------------------------------------------


    #FOR N = 150
    #Experiment1 C = 20
    #Experiment2 C = 1

    #FOR N=500
    #Experiment1  C=1
    #Experiment1  C=20


    #-----Training---------
    C = 1
    epsilon=0.01
    kernel_type = 'gaus'
    kernel_params = math.sqrt(100)

    [a, b] = SMO_classification(x_training, y_training, C, epsilon, kernel_type, kernel_params)
    #-----------------------

    #classifier
    PP = 1.1
    leftX = PP*np.min(x_)
    rightX = PP*np.max(x_)
    leftY = PP*np.min(y_)
    rightY = PP*np.max(y_)

    step = 0.5
    [X, Y] = np.meshgrid(frange(leftX, rightX, step), frange(leftY, rightY, step))
    [K, L] = X.shape
    Z = np.zeros(shape=(K, L))
    for i in range(0, K):
        for j in range(0, L):
            sum = 0
            for n in range(0, N):
                #print(np.array(X[i, j]))
                sum = sum + a[n]*y_training[n]*kappa(np.array(x_training[n, :]), np.array([X[i, j], Y[i, j]]), kernel_type, [kernel_params])
            Z[i, j] = sum-b

    # norm of solution
    norm=0
    for n in range(0, N):
        for m in range(0, N):
            norm = norm + a[n]*a[m]*y_training[n]*y_training[m]*kappa(np.array(x_training[n, :]), np.array(x_training[m, :]), kernel_type, [kernel_params])

    # find support vectors
    SV = []
    for n in range(0, N):
        if np.abs(a[n]) > 0.001:
            SV.append(n)

    SV1 = np.intersect1d(C1, SV)
    SV2 = np.intersect1d(C2, SV)

    # plot classifier
    plt.figure(1)
    v = [-1, 0, 1]
    plt.contour(X, Y, Z, v, colors='k', linestyles='dashed', linewidths=0.8)
    # step = 1/norm
    # v = frange(-1*step, 1*step, step)
    v = [0]
    plt.contour(X, Y, Z, v,  colors='k', linestyles='solid', linewidths=0.8)

    plt.plot(x_[C1], y_[C1], '.', markersize=4, c=[1, 0, 0])
    plt.plot(x_[C2], y_[C2], '.', markersize=4, c=[0.5, 0.5,0.5])
    # [sx,I] = sort(x_);
    # plot(sx',fx(I)');
    box = PP*np.array([np.min(x_), np.max(x_), np.min(y_), np.max(y_)])
    plt.axis(box)


    # plot Support Vectors
    plt.plot(x_[SV1], y_[SV1], 'o', markerfacecolor='none', markersize=6, markeredgecolor=[1, 0, 0])
    plt.plot(x_[SV2], y_[SV2], 'o',  markerfacecolor='none', markersize=6, markeredgecolor=[0.5, 0.5, 0.5])

    plt.title('C= ' + str(C) + ', ' + 'Number of SVs: ' + str(len(SV)))

    plt.show()


if __name__ == '__main__':
    supportvectormachine_11_21()
