
# -----------------------------------------------------------------
# Exercise 11.15
# Support Vector Regression experiment
# on an audio sequence corrupted by
# Gaussian noise and outliers
#
# This file uses an SMO implementation to train the SVM plus other
# subroutines for the various kernel methods.
#
#
# You need a .wav file to run the experiment...
# Python3 required packages: numpy, soundfile, matplotlib

# -----------------------------------------------------------------
import numpy as np
import math
import soundfile as sf
import matplotlib.pyplot as plt
import sys
import os
import time
sys.path.append(os.getcwd())
sys.path.append('../../')


from PYTHON_11.Exercise_11_20_Suport_Vector_Regression.kappa import kappa
from PYTHON_11.Exercise_11_20_Suport_Vector_Regression.SMO_regression import SMO_regression


def supportvectorregresion_11_20():
    # global a1_g, a2_g, b_g, u_g, KKT_g, NB_g, a1i_new, a1j_new, a2i_new, a2j_new
    np.random.seed(0)

    # --------------------------------------------------------------------
    # Reading wav file. x corresponds to time instances (is., x_i in [0,1])
    # fs is the sampling frequency
    # Replace the name "BladeRunner.wav" in wavread wuth the name of the file
    # you intend to use.
    # --------------------------------------------------------------------
    N = 100
    samples = 1000
    indices = np.array(range(0, samples, int(samples / N)))
    start = 100000
    [data, fs] = sf.read('BladeRunner.wav')
    sound = np.array(data[start:(start + samples + 1), :])
    y = np.reshape(sound[indices, 0], newshape=(len(indices), 1))
    Ts = 1 / fs  # h periodos deigmatolipsias
    x = np.array(range(0, samples)).conj().transpose() * Ts  # oi xronikes stigmes tis deigmatolipsias
    x = np.array(x[indices])
    x = np.reshape(x, newshape=(x.shape[0], 1))

    # -------------------------------------------------------

    # Add white Gaussian noise
    snr = 15  # dB
    y = np.array(py_awgn(y, snr))

    # add outliers
    O = 0.8 * np.max(np.abs(y))

    percent = 0.1
    M = int(math.floor(percent * N))
    out_ind = np.random.choice(N, M, replace=False)
    outs = np.sign(np.random.randn(M, 1)) * O
    y[out_ind] = y[out_ind] + outs



    M = y.shape[0]

    # ---------------------Code for SVR-------------------------------------
    C = 1
    epsilon = 0.003
    kernel_type = 'gaus'
    kernel_params = 0.004
    print('-----------------------')
    print('SMO starting...')
    tm = time.time()


    [a1, a2, b, KKT, rmse] = SMO_regression2(x, y, C, epsilon, kernel_type, kernel_params)
    elapsed = time.time() - tm
    print('Elapsed time is: %s seconds' % elapsed)


    print('SMO completed')

    # Generate regressor

    t = np.array([range(0, samples + 1)]).conj().transpose() * Ts

    M2 = t.shape[0]
    z = np.zeros(shape=(M2, 1))
    for k in range(0, M2):
        z[k] = 0
        for l in range(0, M):
            z[k] = z[k] + (a1[l] - a2[l]) * kappa(x[l], t[k], kernel_type, [kernel_params])

        z[k] = z[k] + b

    # find support vectors
    SV = []
    for n in range(0, N):  # =1:N
        if (np.abs(a1[n]) > 0.001) or (np.abs(a2[n]) > 0.001):
            SV.append(n)  # SV = [SV, n]

    # ---end SVR----------------------------------------------------------------

    # plot Output
    # For SVR
    plt.figure(1)
    # plot(x,y)
    plt.xlabel('time in sec')
    plt.ylabel('amplitude')
    plt.plot(t, z, 'r', lw=1)
    #plt.plot(t,z+epsilon,'-.', color='k', lw=1.4);
    #plt.plot(t,z-epsilon,'-.', color='k', lw=1.4);
    plt.plot(x, y, '.', markeredgecolor=[0.3, 0.3, 0.3], markersize=2)

    plt.plot(x[SV], y[SV], 'ko', mfc='none', markersize=5)

    title = 'SVR output C= %s, Number of SVs: %s' % (str(C), str(len(SV)))
    plt.title(title)

    plt.show()


def py_awgn(input_signal, snr_dB, rate=1.0):
    """ Addditive White Gaussian Noise (AWGN) Channel.

    Parameters
    __________
    input_signal : 1D ndarray of floats
        Input signal to the channel.

    snr_dB : float
        Output SNR required in dB.

    rate : float
        Rate of the a FEC code used if any, otherwise 1.

    Returns
    _______
    output_signal : 1D ndarray of floats
        Output signal from the channel with the specified SNR.
    """

    avg_energy = np.sum(np.dot(input_signal.conj().T, input_signal)) / input_signal.shape[0]
    snr_linear = 10 ** (snr_dB / 10.0)
    noise_variance = avg_energy / (2 * rate * snr_linear)

    if input_signal.dtype is np.complex:
        noise = np.array([np.sqrt(noise_variance) * np.random.randn(input_signal.shape[0]) * (1 + 1j)], ndmin=2)
    else:
        noise = np.array([np.sqrt(2 * noise_variance) * np.random.randn(input_signal.shape[0])], ndmin=2)

    output_signal = np.array(input_signal + noise.conj().T)

    return output_signal


if __name__ == '__main__':
    supportvectorregresion_11_20()
