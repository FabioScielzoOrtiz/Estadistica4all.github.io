# *******************************************************************
# SMO algorithm for regression.
# started: 22/10/2010
# ended: 22/10/2010
# ------------------------------------------------------------------
# Description
#
# u_i = �(x_i) = � y_n a_n K(x_i,x_n) + b
#
# The Algorithm computes the parameters a_k, of the expansion of the
# solution w = Sum a_n*K(. , x_n) and the parameter b.
# -------------------------------------------------------------------
# input variables
#
# x:              a M x N matrix. It contains the input vectors x_i (each one in
#                   every row.
# y:              a vector of size M. The class of each input vector
# C:              the trade-off parameter of the SVM model
# kernel_type:    The type of the kernel, usually this ['gaus', 'poly']
# kernel_params   The parameters for the kernel (i.e. sigma, e.t.c.)
# -----------------------------------------------------------------
#
# -----------------------------------------------------------------
# output variables
#
# a  :          a vector of size m. These are the support vectors
#
# b  :          a real number. This is the offset of the support vector
#                   expansion.

import numpy as np
import sys
import os
sys.path.append(os.getcwd())
from PYTHON_11.Exercise_11_20_Suport_Vector_Regression.kappa import kappa

global a1_g, a2_g, b_g, u_g, KKT_g, NB_g, a1i_new, a1j_new, a2i_new, a2j_new


def SMO_regression2(x, y, C, epsilon, kernel_type, kernel_params):
    global a1_g, a2_g, b_g, u_g, KKT_g, NB_g, a1i_new, a1j_new, a2i_new, a2j_new

    tol = 0.001

    [M, N]= x.shape
    # a1_g = np.zeros(shape=(M,1))
    # a2_g = np.zeros(shape=(M,1))
    # u_g = np.zeros(shape=(M,1))
    # KKT_g = np.zeros(shape=(M,1))
    # NB_g = np.zeros(shape=(M,1))

    Kernel_matrix = np.zeros(shape=(M, M))

    if kernel_type == 'gaus':
        par = kernel_params
        norms = np.zeros(shape=(M, M))
        for i in range(0, M):

            T = x - x[i, :]  # bsxfun(@minus,x,x(i,:))
            norms[i, :] = np.sum(T**2, axis=1)

        Kernel_matrix = np.exp(-norms/(par**2))

    elif kernel_type == 'gaus_c':
        par = kernel_params
        norms = np.zeros(shape=(M, M))
        for i in range(0, M):
            T = x - x[i, :].conj()  # bsxfun(@minus,x,conj(x(i,:)))
            norms[i, :] = np.sum(T**2, axis=1)
        
        Kernel_matrix[:, :] = 2*np.real(np.exp(-norms/(par**2)))
    else:
        for i in range(0, M):
            for j in range(0, M):
                Kernel_matrix[i, j] = kappa(x[i, :], x[j, :], kernel_type, kernel_params)

    # initialize the support vectors
    a1_g = np.zeros(shape=(M))
    a2_g = np.zeros(shape=(M))

    # initialize the threshold
    b_g = 0

    # u contains the values of the sv expansion for each input
    u_g = b_g*np.ones(shape=(M))

    # KKT[i] is 1 if the i-th sv (a[i]) satisfies the KKT conditions
    # KKT[i] is 0 otherwise
    KKT_g = np.zeros(shape=(M))
    # Update KKT conditions
    update_KKT(x, y, C, epsilon)

    # NB[i] is 1 if the sv a[i] is non bound, i.e. 0<a[i]<C
    # NB[i] is 0 otherwise.
    NB_g = np.zeros(shape=(M))

    numChanged = 0
    examineAll = 1
    LoopCounter = 0
    while (numChanged > 0) or (examineAll == 1):
        LoopCounter += 1
        numChanged = 0
        if examineAll == 1:
            # loop over all training examples
            for i in range(0, M):
                numChanged += examineExample(i, x, y, C, epsilon, Kernel_matrix)
        else:

            # loop over all training examples, where a[i] is non-bound
            for i in range(0, M):
                if NB_g[i] == 1:
                    numChanged += examineExample(i, x, y, C, epsilon, Kernel_matrix)

        if LoopCounter % 2 == 0:
            MinimumNumChanged = np.maximum(1.0, 0.1*M)

        else:
            MinimumNumChanged = 1
        
        if examineAll == 1:
            examineAll = 0
        elif numChanged < MinimumNumChanged:
                examineAll = 1


    a1 = np.array(a1_g)
    a2 = np.array(a2_g)
    b = np.array(b_g)
    KKT = np.array(KKT_g)

    rmse = np.sqrt(np.mean((u_g - y)**2))

    return a1, a2, b, KKT, rmse


def examineExample(j, x, y, C, epsilon, Kernel_matrix):
    global KKT_g, NB_g
    M = y.shape[0]
    if KKT_g[j] == 0:
        if np.sum(NB_g) > 1:
            # find the i - second choice heurestic
            i = second_choice_heurestic(j, x, y, epsilon)
            if takeStep(i, j,  x, y, C, epsilon, 1, Kernel_matrix):
                ret = 1
                return ret

        # loop over all non-bound a's starting at a random point
        i0 = np.random.randint(low=0, high=M)  # choose from 0,...,M-1

        for i in range(i0, i0+M):
            if NB_g[(i) % (M)] == 1:
                if takeStep((i) % (M), j,  x, y, C, epsilon, 0, Kernel_matrix):
                    ret = 1
                    return ret

        # loop over all possible a's starting at a random point
        i0 = np.random.randint(low=0, high=M)
        for i in range(i0, i0+M):
            if takeStep((i) % (M), j,  x, y, C, epsilon, 0, Kernel_matrix) == 1:
                ret = 1
                return ret

    ret = 0

    return ret


def takeStep(i, j, x, y, C, epsilon, chosen, Kernel_matrix):
    global a1_g, a2_g, b_g, u_g, KKT_g, NB_g #,a1i_new, a1j_new, a2i_new, a2j_new
    #global a1i_new, a1j_new, a2i_new, a2j_new

    tol = 0.001

    if i == j:
        ret = 0
        return ret

    E_i = y[i] - u_g[i]
    E_j = y[j] - u_g[j]
    gamma = a1_g[i] + a1_g[j] - a2_g[i] - a2_g[j]

    kii = Kernel_matrix[i, i]
    # kii = kappa(x[i,:], x[i,:], kernel_type, [kernel_params])
    kij = Kernel_matrix[i, j]
    # kij = kappa(x[i,:], x[j,:], kernel_type, [kernel_params])
    kjj = Kernel_matrix[j,j]
    # kjj = kappa(x[j,:], x[j,:], kernel_type, [kernel_params])
    eta = -2*kij + kii + kjj

    case1 = 0
    case2 = 0
    case3 = 0
    case4 = 0
    finished = 0
    a1i_old = a1_g[i]
    a2i_old = a2_g[i]
    a1j_old = a1_g[j]
    a2j_old = a2_g[j]

    while finished == 0:
        if (case1 == 0) and ((a1_g[i] > 0) or ((a2_g[i] == 0) and ((E_i-E_j) > 0))) and ((a1_g[j] > 0) or (a2_g[j] == 0 and (E_i-E_j) < 0)):
            L = np.maximum(0, gamma-C)
            H = np.minimum(gamma, C)
            if L < H:
                a2 = a1_g[j] - (E_i-E_j)/eta
                a2 = np.minimum(a2, H)
                a2 = np.maximum(L, a2)
                a1 = a1_g[i] - (a2 - a1_g[j])
                if (np.abs(a1_g[i] - a1) + np.abs(a1_g[j] - a2)) > tol:
                    a1_g[i] = a1
                    a1_g[j] = a2
            else:
                finished = 1
            case1 = 1
        elif (case2 == 0) and ((a1_g[i] > 0) or ((a2_g[i] == 0) and ((E_i-E_j) > 2*epsilon))) and ((a2_g[j] > 0) or ((a1_g[j] == 0) and ((E_i-E_j) > 2*epsilon))):
            L = np.maximum(0, -gamma)
            H = np.minimum(C, C-gamma)
            if L < H:
                a2 = a2_g[j] + (E_i-E_j-2*epsilon)/eta
                a2 = np.minimum(a2, H)
                a2 = np.maximum(L, a2)
                a1 = a1_g[i] + (a2-a2_g[j])
                if (np.abs(a1_g[i] - a1) + np.abs(a2_g[j] - a2)) > tol:
                    a1_g[i] = a1
                    a2_g[j] = a2
                
            else:
                finished = 1
            
            case2 = 1
        elif (case3 == 0) and ((a2_g[i] > 0)or((a1_g[i] == 0)and((E_i-E_j) < -2*epsilon))) and ((a1_g[j] > 0)or((a2_g[j]==0)and((E_i-E_j)<-2*epsilon))):
            L = np.maximum(0, gamma)
            H = np.minimum(gamma+C, C)
            if (L<H):
                a2 = a1_g[j] - (E_i-E_j+2*epsilon)/eta
                a2=np.minimum(a2,H)
                a2=np.maximum(L,a2)
                a1 = a2_g[i] + (a2 - a1_g[j])
                if (np.abs(a2_g[i] - a1) + np.abs(a1_g[j] - a2)) > tol:
                    a2_g[i] = a1
                    a1_g[j] = a2
                
            else:
                finished = 1
            
            case3 = 1
        elif (case4 == 0) and ((a2_g[i] > 0)or((a1_g[i] == 0) and (E_i - E_j) < 0)) and ((a2_g[j] > 0) or ((a1_g[j] == 0) and ((E_i-E_j) > 0))):
            L = np.maximum(0, -gamma-C)
            H = np.minimum(-gamma ,C)
            if (L < H):
                a2 = a2_g[j] + (E_i-E_j)/eta
                a2 = np.minimum(a2, H)
                a2 = np.maximum(L, a2)
                a1 = a2_g[i] - (a2 - a2_g[j])
                if (np.abs(a2_g[i] - a1) + np.abs(a2_g[j] - a2)) > tol:
                    a2_g[i] = a1
                    a2_g[j] = a2
                
            else:
                finished = 1
            
            case4 = 1
        else:

            finished = 1

        #update errors
        E_i = E_i - ((a1_g[i] - a2_g[i]) - (a1i_old - a2i_old))*Kernel_matrix[i, i] - ((a1_g[j] - a2_g[j]) - (a1j_old - a2j_old))*Kernel_matrix[i, j]
        E_j = E_j - ((a1_g[i] - a2_g[i]) - (a1i_old - a2i_old))*Kernel_matrix[j, i] - ((a1_g[j] - a2_g[j]) - (a1j_old - a2j_old))*Kernel_matrix[j, j]

    # orio = (np.abs(a1_g[i]-a1i_old) + np.abs(a1_g[j]-a1j_old) + np.abs(a2_g[i]-a2i_old) + np.abs(a2_g[j]-a2j_old))
    # print(np.sum(orio))
    if (np.abs(a1_g[i]-a1i_old) + np.abs(a1_g[j]-a1j_old) + np.abs(a2_g[i]-a2i_old) + np.abs(a2_g[j]-a2j_old)) < tol:
        ret = 0
        return ret
    
    ret = 1

    # update b
    M = y.shape[0]
    b_old = b_g
    b1 = 0
    b2 = 0
    N1 = 0
    N2 = 0
    for k in range(0, M):
        if (a1_g[k] > 0) and (a1_g[k] < C):
            # b = y_i - <w,x_i> - e
            in_prod = 0
            for l in range(0, M):
                in_prod += (a1_g[l] - a2_g[l])*Kernel_matrix[l, k]
            
            b1 += y[k] - in_prod - epsilon
            N1 += 1
            # break

        if (a2_g[k] > 0) and (a2_g[k] < C):
            # b = y_i - <w,x_i> + e
            in_prod = 0
            for l in range(0, M):
                in_prod += (a1_g[l] - a2_g[l])*Kernel_matrix[l, k]
            
            b2 += y[k] - in_prod + epsilon
            N2 += 1
            # break

    if (N1 > 0) and (N2 > 0):
        b_g = (b1/N1 + b2/N2)/2
    elif N1 > 0:
        b_g = b1/N1
    elif N2 > 0:
        b_g = b2/N2
    else:
        k = M-1
        b1 = 0
        in_prod = 0
        for l in range(0, M):
            in_prod += (a1_g[l] - a2_g[l])*Kernel_matrix[l, k]
        b1 = b1 + y[k] - in_prod
        N1 += 1
        b_g = b1/N1

    # Update u vector
    M = y.shape[0]
    for k in range(0, M):
        # u_g[k] = 0
        u_g[k] = u_g[k] - b_old + b_g + (a1_g[i] - a2_g[i] - a1i_old + a2i_old)*Kernel_matrix[k, i] + (a1_g[j] - a2_g[j] - a1j_old + a2j_old)*Kernel_matrix[k, j]
        # for l in range(0, M):
        #     u_g[k] = u_g[k] + (a1_g[l] - a2_g([l])*kappa(x[k,:], x[l,:])
        # u_g[k] = u_g[k] + b_g

    # Update KKT conditions
    update_KKT(x, y, C, epsilon)

    # Update NB vector
    for k in range(0, M):
        if ( (a1_g[k]>0) and (a1_g[k]<C) ) or ( (a2_g[k]>0) and (a2_g[k]<C) ):
           NB_g[k] = 1  # Non Bound example
        else:
            NB_g[k] = 0  # Bound example
    return ret


def second_choice_heurestic(j,x,y,epsilon):
    global u_g
    M = y.shape[0]

    E_1 = y[0] - u_g[0]
    E_j = y[j] - u_g[j]
    max1 = abs(E_1 - E_j)
    i1 = 0
    for k in range(1, M):
        E_k = y[k] - u_g[k]
        if abs(E_k - E_j) > max1:
            max1 = abs(E_k - E_j)
            i1 = k

    max2 = abs(E_j - E_1 + 2*epsilon)
    i2 = 0
    for k in range(1, M):
        E_k = y[k] - u_g[k]
        if abs(E_j - E_k + 2*epsilon) > max2:
            max2 = abs( E_j - E_k + 2*epsilon)
            i2 = k

    max3 = abs(E_1 - E_j + 2*epsilon)
    i3 = 0
    for k in range(1, M):
        E_k = y[k] - u_g[k]
        if abs( E_k - E_j + 2*epsilon ) > max3:
            max3 = abs( E_k - E_j + 2*epsilon )
            i3 = k

    max4 = abs(E_j - E_1)
    i4 = 0
    for k in range(1, M):
        E_k = y[k] - u_g[k]
        if abs(E_j - E_k) > max4:
            max4 = abs(E_j - E_k)
            i4 = k

    i = i1
    maximum = max1
    if max2 > maximum:
        maximum = max2
        i = i2

    if max3 > maximum:
        maximum = max3
        i = i3

    if max4 > maximum:
        maximum = max4
        i = i4

    return i


def update_KKT(x, y, C, epsilon):
    global a1_g, a2_g, u_g, KKT_g

    M = y.shape[0]
    tol = 0.01

    for i in range(0, M):
        E_i = u_g[i] - y[i]
        if ( (E_i>=epsilon) and (a2_g[i]<C) ) or ( (E_i<epsilon) and (a2_g[i]>0) ) or ( (-E_i>=epsilon) and (a1_g[i]<C) ) or ( (-E_i<epsilon) and (a1_g[i]>0) ):
            KKT_g[i] = 0
        else:
            KKT_g[i] = 1









