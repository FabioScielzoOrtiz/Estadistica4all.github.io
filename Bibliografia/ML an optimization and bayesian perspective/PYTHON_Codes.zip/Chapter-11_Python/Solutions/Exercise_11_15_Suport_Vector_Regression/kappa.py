
#  Python3 required packages: numpy

import numpy as np


def kappa(x, y, kernel_type, kernel_params):
    value = None
    if kernel_type == 'gaus':
        sigma = kernel_params[0]
        N = x.shape[0]
        norm = np.sum((x-y)**2)
        value = np.exp(-norm/(sigma**2))
    elif kernel_type == 'gaus_c':
        sigma = kernel_params[0]
        N = len(x)
        exponent = sum( (x-y.conj())**2 )
        # value = 2*(math.exp( -np.real(exponent)/(sigma**2) ))
        value = 2*np.real(np.exp(-exponent/(sigma**2)))
    elif kernel_type == 'linear':
        value = 0
        N = len(x)
        for i in range(0, N):
            value = value + x[i]*y[i].conj()
    elif kernel_type == 'poly':
        d = kernel_params[0]
        value = (1 + np.dot(x, y.conj().transpose()))**d
        # value = ( (1 + x*y.transpose())/( math.sqrt(np.real(x*x.transpose()) * np.real(y*y.transpose()) ) ) )**d;
    elif kernel_type == 'poly_c':
        d = kernel_params[0]
        value = 2*np.real((1 + np.dot(x, y.conj().transpose()))**d)
        # value = 2*np.real( ( (1 + x*y.transpose())/( math.sqrt(np.real(x*x.transpose()) * np.real(y*y.transpose()) ) ) )**d )

    return value
